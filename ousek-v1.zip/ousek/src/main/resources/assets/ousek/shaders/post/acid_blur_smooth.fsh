#version 150

uniform sampler2D InSampler;
uniform sampler2D PrevSampler;

layout(std140) uniform BlurConfig {
    float Strength;
};

in vec2 texCoord;
out vec4 fragColor;

void main() {
    vec2 px = 1.0 / vec2(textureSize(PrevSampler, 0));
    vec3 cur = texture(InSampler, texCoord).rgb;
    vec3 prev = texture(PrevSampler, texCoord).rgb * 0.5
        + texture(PrevSampler, texCoord + vec2(px.x, 0.0)).rgb * 0.125
        + texture(PrevSampler, texCoord - vec2(px.x, 0.0)).rgb * 0.125
        + texture(PrevSampler, texCoord + vec2(0.0, px.y)).rgb * 0.125
        + texture(PrevSampler, texCoord - vec2(0.0, px.y)).rgb * 0.125;
    fragColor = vec4(mix(cur, prev, Strength), 1.0);
}
