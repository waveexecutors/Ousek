#version 150

uniform sampler2D InSampler;
uniform sampler2D PrevSampler;

layout(std140) uniform BlurConfig {
    float Strength;
};

in vec2 texCoord;
out vec4 fragColor;

void main() {
    vec3 cur = texture(InSampler, texCoord).rgb;
    vec3 prev = texture(PrevSampler, texCoord).rgb * Strength;
    fragColor = vec4(max(cur, prev), 1.0);
}
