#version 150

uniform sampler2D InSampler;
uniform sampler2D InDepthSampler;

layout(std140) uniform GlowConfig {
    vec4 Color;
    float Radius;
    float Intensity;
};

in vec2 texCoord;
out vec4 fragColor;

// After the hand is drawn the depth buffer is cleared everywhere except on the hand and held item,
// so "depth < 0.985" is a mask of exactly those pixels.
bool isHand(vec2 uv) {
    return texture(InDepthSampler, uv).r < 0.985;
}

const vec2 DIRS[8] = vec2[8](vec2(1, 0), vec2(-1, 0), vec2(0, 1), vec2(0, -1),
    vec2(0.7071, 0.7071), vec2(-0.7071, 0.7071), vec2(0.7071, -0.7071), vec2(-0.7071, -0.7071));

void main() {
    vec4 base = texture(InSampler, texCoord);
    fragColor = isHand(texCoord) ? vec4(Color.rgb, 1.0) : vec4(base.rgb, 1.0);
}
