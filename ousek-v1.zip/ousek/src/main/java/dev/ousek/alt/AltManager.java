package dev.ousek.alt;

import dev.ousek.mixin.MinecraftClientAccessor;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.session.Session;

import java.lang.reflect.Constructor;
import java.nio.charset.StandardCharsets;
import java.util.ArrayList;
import java.util.List;
import java.util.Optional;
import java.util.Random;
import java.util.UUID;

/**
 * Offline ("cracked") account switcher. Accounts are just a name plus an optional
 * password that the AuthMe helper modules can send to servers you play on.
 */
public final class AltManager {
	public static final List<Alt> alts = new ArrayList<>();
	private static final Random RNG = new Random();
	private static final String[] A = {"Swift", "Quiet", "Brave", "Lazy", "Neon", "Frost", "Misty", "Pixel", "Solar", "Rusty"};
	private static final String[] B = {"Fox", "Owl", "Wolf", "Moth", "Crab", "Hawk", "Bear", "Lynx", "Otter", "Crow"};

	private AltManager() {
	}

	public static class Alt {
		public String name;
		public String password;

		public Alt(String name, String password) {
			this.name = name;
			this.password = password == null ? "" : password;
		}
	}

	public static String currentName() {
		return MinecraftClient.getInstance().getSession().getUsername();
	}

	public static String currentPassword() {
		String n = currentName();
		for (Alt a : alts) if (a.name.equalsIgnoreCase(n)) return a.password;
		return "";
	}

	public static String randomName() {
		String s = A[RNG.nextInt(A.length)] + B[RNG.nextInt(B.length)] + RNG.nextInt(100);
		return s.length() > 16 ? s.substring(0, 16) : s;
	}

	public static boolean validName(String n) {
		return n != null && n.matches("[A-Za-z0-9_]{3,16}");
	}

	public static void add(String name, String password) {
		for (Alt a : alts) {
			if (a.name.equalsIgnoreCase(name)) {
				a.password = password == null ? "" : password;
				return;
			}
		}
		alts.add(new Alt(name, password));
	}

	public static boolean login(Alt alt) {
		try {
			UUID id = UUID.nameUUIDFromBytes(("OfflinePlayer:" + alt.name).getBytes(StandardCharsets.UTF_8));
			Session s = build(alt.name, id);
			if (s == null) return false;
			((MinecraftClientAccessor) MinecraftClient.getInstance()).ousek$setSession(s);
			return true;
		} catch (Throwable t) {
			return false;
		}
	}

	// Built reflectively so it keeps working if Mojang tweaks the Session constructor.
	private static Session build(String name, UUID id) throws Exception {
		for (Constructor<?> c : Session.class.getDeclaredConstructors()) {
			Class<?>[] p = c.getParameterTypes();
			Object[] args = new Object[p.length];
			boolean ok = true;
			int strings = 0;
			for (int i = 0; i < p.length && ok; i++) {
				if (p[i] == String.class) args[i] = strings++ == 0 ? name : "";
				else if (p[i] == UUID.class) args[i] = id;
				else if (p[i] == Optional.class) args[i] = Optional.empty();
				else if (p[i].isEnum()) {
					Object[] consts = p[i].getEnumConstants();
					Object pick = consts[0];
					for (Object o : consts) if (o.toString().equals("LEGACY")) pick = o;
					args[i] = pick;
				} else ok = false;
			}
			if (ok) {
				c.setAccessible(true);
				return (Session) c.newInstance(args);
			}
		}
		return null;
	}
}
