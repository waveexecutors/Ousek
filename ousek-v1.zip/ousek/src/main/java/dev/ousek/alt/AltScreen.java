package dev.ousek.alt;

import dev.ousek.config.Config;
import dev.ousek.gui.Theme;
import net.minecraft.client.gui.DrawContext;
import net.minecraft.client.gui.screen.Screen;
import net.minecraft.client.gui.widget.ButtonWidget;
import net.minecraft.client.gui.widget.TextFieldWidget;
import net.minecraft.text.Text;

public class AltScreen extends Screen {
	private final Screen parent;
	private TextFieldWidget nameField;
	private TextFieldWidget passField;
	private int page;
	private String status = "";
	private int statusColor = 0xFF9A9AA6;

	public AltScreen(Screen parent) {
		super(Text.literal("Alt Manager"));
		this.parent = parent;
	}

	private int perPage() {
		return Math.max(1, (height - 116 - 36) / 24);
	}

	@Override
	protected void init() {
		int cx = width / 2;

		String oldName = nameField == null ? "" : nameField.getText();
		String oldPass = passField == null ? "" : passField.getText();

		nameField = new TextFieldWidget(textRenderer, cx - 100, 36, 200, 20, Text.literal("Username"));
		nameField.setMaxLength(16);
		nameField.setPlaceholder(Text.literal("Username"));
		nameField.setText(oldName);
		addDrawableChild(nameField);

		passField = new TextFieldWidget(textRenderer, cx - 100, 60, 200, 20, Text.literal("Password"));
		passField.setMaxLength(64);
		passField.setPlaceholder(Text.literal("Password for AuthMe (optional)"));
		passField.setText(oldPass);
		addDrawableChild(passField);

		addDrawableChild(ButtonWidget.builder(Text.literal("Add"), b -> add(false))
				.dimensions(cx - 100, 86, 64, 20).build());
		addDrawableChild(ButtonWidget.builder(Text.literal("Add + Login"), b -> add(true))
				.dimensions(cx - 32, 86, 64, 20).build());
		addDrawableChild(ButtonWidget.builder(Text.literal("Random"), b -> nameField.setText(AltManager.randomName()))
				.dimensions(cx + 36, 86, 64, 20).build());

		int per = perPage();
		int pages = Math.max(1, (AltManager.alts.size() + per - 1) / per);
		page = Math.max(0, Math.min(page, pages - 1));
		int start = page * per;
		for (int i = start; i < Math.min(AltManager.alts.size(), start + per); i++) {
			AltManager.Alt alt = AltManager.alts.get(i);
			int y = 116 + (i - start) * 24;
			boolean current = alt.name.equalsIgnoreCase(AltManager.currentName());
			String label = (current ? "> " : "") + alt.name + (alt.password.isEmpty() ? "" : "  (pw)");
			addDrawableChild(ButtonWidget.builder(Text.literal(label), b -> login(alt))
					.dimensions(cx - 100, y, 160, 20).build());
			addDrawableChild(ButtonWidget.builder(Text.literal("Del"), b -> {
				AltManager.alts.remove(alt);
				Config.save();
				clearAndInit();
			}).dimensions(cx + 64, y, 36, 20).build());
		}

		addDrawableChild(ButtonWidget.builder(Text.literal("<"), b -> {
			page--;
			clearAndInit();
		}).dimensions(cx - 100, height - 28, 40, 20).build());
		addDrawableChild(ButtonWidget.builder(Text.literal("Back"), b -> close())
				.dimensions(cx - 50, height - 28, 100, 20).build());
		addDrawableChild(ButtonWidget.builder(Text.literal(">"), b -> {
			page++;
			clearAndInit();
		}).dimensions(cx + 60, height - 28, 40, 20).build());
	}

	private void add(boolean login) {
		String n = nameField.getText().trim();
		if (!AltManager.validName(n)) {
			setStatus("Name must be 3-16 letters, numbers or underscores.", 0xFFFF5A6A);
			return;
		}
		AltManager.add(n, passField.getText());
		Config.save();
		nameField.setText("");
		passField.setText("");
		if (login) {
			for (AltManager.Alt a : AltManager.alts) if (a.name.equalsIgnoreCase(n)) login(a);
		} else {
			setStatus("Saved " + n, 0xFF4BE08A);
		}
		clearAndInit();
	}

	private void login(AltManager.Alt alt) {
		if (AltManager.login(alt)) setStatus("Now playing as " + alt.name, 0xFF4BE08A);
		else setStatus("Could not switch account.", 0xFFFF5A6A);
		clearAndInit();
	}

	private void setStatus(String s, int c) {
		status = s;
		statusColor = c;
	}

	@Override
	public void renderBackground(DrawContext ctx, int mouseX, int mouseY, float delta) {
		ctx.fill(0, 0, width, height, 0xFF0A0A0E);
	}

	@Override
	public void render(DrawContext ctx, int mouseX, int mouseY, float delta) {
		ctx.fill(0, 0, width, height, 0xFF0A0A0E);
		super.render(ctx, mouseX, mouseY, delta);
		String title = "Alt Manager";
		ctx.drawText(textRenderer, title, width / 2 - textRenderer.getWidth(title) / 2, 12, Theme.accent(), true);
		String user = "Current: " + AltManager.currentName();
		ctx.drawText(textRenderer, user, width / 2 - textRenderer.getWidth(user) / 2, 24, 0xFFFFFFFF, false);
		if (!status.isEmpty()) {
			ctx.drawText(textRenderer, status, width / 2 - textRenderer.getWidth(status) / 2, height - 42, statusColor, false);
		}
	}

	@Override
	public void close() {
		Config.save();
		if (client != null) client.setScreen(parent);
	}
}
