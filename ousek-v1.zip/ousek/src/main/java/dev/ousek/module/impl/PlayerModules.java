package dev.ousek.module.impl;

import dev.ousek.mixin.InteractionManagerAccessor;
import dev.ousek.mixin.MinecraftClientAccessor;
import dev.ousek.module.Category;
import dev.ousek.module.Module;
import dev.ousek.setting.Setting;
import net.minecraft.block.BlockState;
import net.minecraft.client.gui.screen.DeathScreen;
import net.minecraft.client.gui.screen.ingame.GenericContainerScreen;
import net.minecraft.component.DataComponentTypes;
import net.minecraft.item.BlockItem;
import net.minecraft.item.ItemStack;
import net.minecraft.screen.GenericContainerScreenHandler;
import net.minecraft.screen.slot.SlotActionType;
import net.minecraft.util.Hand;
import net.minecraft.util.hit.BlockHitResult;
import net.minecraft.util.math.BlockPos;
import net.minecraft.util.math.Direction;
import net.minecraft.util.math.Vec3d;

import java.util.List;
import java.util.Random;

public final class PlayerModules {
	private PlayerModules() {
	}

	public static void register(List<Module> list) {
		list.add(new AutoRespawn());
		list.add(new AutoEat());
		list.add(new FastPlace());
		list.add(new FastBreak());
		list.add(new Scaffold());
		list.add(new ChestStealer());
		list.add(new AutoTool());
		list.add(new Spin());
		list.add(new Derp());
		list.add(new Twerk());
	}

	public static class AutoRespawn extends Module {
		public AutoRespawn() {
			super("AutoRespawn", "Respawns instantly", Category.PLAYER);
		}

		@Override
		public void onTick() {
			if (mc.currentScreen instanceof DeathScreen) mc.player.requestRespawn();
		}
	}

	public static class AutoEat extends Module {
		final Setting.Num hunger = num("Eat below", 14, 1, 19, 1);
		boolean eating;
		int prevSlot = -1;

		public AutoEat() {
			super("AutoEat", "Eats food when hungry", Category.PLAYER);
		}

		@Override
		public void onDisable() {
			stop();
		}

		void stop() {
			if (eating) {
				mc.options.useKey.setPressed(false);
				if (prevSlot >= 0 && mc.player != null) mc.player.getInventory().setSelectedSlot(prevSlot);
				eating = false;
				prevSlot = -1;
			}
		}

		@Override
		public void onTick() {
			if (mc.currentScreen != null) return;
			int food = mc.player.getHungerManager().getFoodLevel();
			if (eating) {
				if (food >= 20 || !mc.player.isUsingItem() && mc.player.age % 40 == 0) stop();
				else mc.options.useKey.setPressed(true);
				return;
			}
			if (food > hunger.i()) return;
			for (int i = 0; i < 9; i++) {
				ItemStack s = mc.player.getInventory().getStack(i);
				if (s.get(DataComponentTypes.FOOD) != null) {
					prevSlot = mc.player.getInventory().getSelectedSlot();
					mc.player.getInventory().setSelectedSlot(i);
					eating = true;
					return;
				}
			}
		}
	}

	public static class FastPlace extends Module {
		public FastPlace() {
			super("FastPlace", "No block place delay", Category.PLAYER);
		}

		@Override
		public void onTick() {
			((MinecraftClientAccessor) mc).ousek$setItemUseCooldown(0);
		}
	}

	public static class FastBreak extends Module {
		public FastBreak() {
			super("FastBreak", "No block break delay", Category.PLAYER);
		}

		@Override
		public void onTick() {
			((InteractionManagerAccessor) mc.interactionManager).ousek$setBlockBreakingCooldown(0);
		}
	}

	public static class Scaffold extends Module {
		final Setting.Bool swing = bool("Swing", true);

		public Scaffold() {
			super("Scaffold", "Places blocks under you", Category.PLAYER);
		}

		@Override
		public void onTick() {
			int slot = -1;
			for (int i = 0; i < 9; i++) {
				if (mc.player.getInventory().getStack(i).getItem() instanceof BlockItem) {
					slot = i;
					break;
				}
			}
			if (slot < 0) return;
			BlockPos below = mc.player.getBlockPos().down();
			if (!mc.world.getBlockState(below).isReplaceable()) return;
			for (Direction d : Direction.values()) {
				BlockPos n = below.offset(d);
				if (mc.world.getBlockState(n).isReplaceable()) continue;
				Direction face = d.getOpposite();
				Vec3d hitPos = Vec3d.ofCenter(n).add(Vec3d.of(face.getVector()).multiply(0.5));
				mc.player.getInventory().setSelectedSlot(slot);
				mc.interactionManager.interactBlock(mc.player, Hand.MAIN_HAND, new BlockHitResult(hitPos, face, n, false));
				if (swing.on()) mc.player.swingHand(Hand.MAIN_HAND);
				return;
			}
		}
	}

	public static class ChestStealer extends Module {
		final Setting.Num delay = num("Delay", 2, 0, 10, 1);
		final Setting.Bool close = bool("Auto close", true);
		int wait;

		public ChestStealer() {
			super("ChestStealer", "Takes items from open chests", Category.PLAYER);
		}

		@Override
		public void onTick() {
			if (!(mc.currentScreen instanceof GenericContainerScreen screen)) return;
			if (wait-- > 0) return;
			GenericContainerScreenHandler h = screen.getScreenHandler();
			int size = h.getRows() * 9;
			for (int i = 0; i < size; i++) {
				if (!h.getSlot(i).getStack().isEmpty()) {
					mc.interactionManager.clickSlot(h.syncId, i, 0, SlotActionType.QUICK_MOVE, mc.player);
					wait = delay.i();
					return;
				}
			}
			if (close.on()) mc.player.closeHandledScreen();
		}
	}

	public static class AutoTool extends Module {
		public AutoTool() {
			super("AutoTool", "Picks the best tool for the block", Category.PLAYER);
		}

		@Override
		public void onTick() {
			if (mc.currentScreen != null || !mc.options.attackKey.isPressed()) return;
			if (!(mc.crosshairTarget instanceof BlockHitResult hit)) return;
			BlockState state = mc.world.getBlockState(hit.getBlockPos());
			if (state.isAir()) return;
			int best = mc.player.getInventory().getSelectedSlot();
			float bestSpeed = mc.player.getInventory().getStack(best).getMiningSpeedMultiplier(state);
			for (int i = 0; i < 9; i++) {
				float s = mc.player.getInventory().getStack(i).getMiningSpeedMultiplier(state);
				if (s > bestSpeed) {
					bestSpeed = s;
					best = i;
				}
			}
			mc.player.getInventory().setSelectedSlot(best);
		}
	}

	public static class Spin extends Module {
		final Setting.Num speed = num("Speed", 20, 1, 90, 1);

		public Spin() {
			super("Spin", "Spins your character", Category.PLAYER);
		}

		@Override
		public void onTick() {
			mc.player.setYaw(mc.player.getYaw() + speed.f());
		}
	}

	public static class Derp extends Module {
		final Random rng = new Random();

		public Derp() {
			super("Derp", "Random head movement", Category.PLAYER);
		}

		@Override
		public void onTick() {
			mc.player.setYaw(rng.nextFloat() * 360f - 180f);
			mc.player.setPitch(rng.nextFloat() * 180f - 90f);
		}
	}

	public static class Twerk extends Module {
		final Setting.Num speed = num("Interval", 3, 1, 20, 1);

		public Twerk() {
			super("Twerk", "Rapid sneaking", Category.PLAYER);
		}

		@Override
		public void onTick() {
			mc.options.sneakKey.setPressed((mc.player.age / speed.i()) % 2 == 0);
		}

		@Override
		public void onDisable() {
			mc.options.sneakKey.setPressed(false);
		}
	}
}
