package dev.ousek.module;

public enum Category {
	COMBAT("Combat"),
	MOVEMENT("Movement"),
	PLAYER("Player"),
	RENDER("Render"),
	WORLD("World"),
	MISC("Misc"),
	AUTH("AuthMe"),
	HUD("HUD"),
	CLIENT("Client");

	public final String label;

	Category(String label) {
		this.label = label;
	}
}
