package dev.ousek.module.impl;

import dev.ousek.module.Category;
import dev.ousek.module.Module;
import dev.ousek.module.Util;
import dev.ousek.setting.Setting;
import net.minecraft.entity.Entity;
import net.minecraft.entity.LivingEntity;
import net.minecraft.util.math.BlockPos;
import net.minecraft.util.math.Direction;
import net.minecraft.util.math.Vec3d;

import java.util.List;

/** Blatant exploits. Every one of these is detectable and bannable on most servers; toggling shows a warning. */
public final class BlatantModules {
	private BlatantModules() {
	}

	public static void register(List<Module> l) {
		l.add(new Fly());
		l.add(new Speed());
		l.add(new Jetpack());
		l.add(new HighJump());
		l.add(new Spider());
		l.add(new Jesus());
		l.add(new AirJump());
		l.add(new Phase());
		l.add(new Nuker());
		l.add(new MultiAura());
		l.add(new BacktrackModule());
	}

	private static double[] move(double speed) {
		var mcc = net.minecraft.client.MinecraftClient.getInstance();
		var o = mcc.options;
		float yaw = (float) Math.toRadians(mcc.player.getYaw());
		double f = (o.forwardKey.isPressed() ? 1 : 0) - (o.backKey.isPressed() ? 1 : 0);
		double s = (o.leftKey.isPressed() ? 1 : 0) - (o.rightKey.isPressed() ? 1 : 0);
		if (f == 0 && s == 0) return new double[]{0, 0};
		double len = Math.sqrt(f * f + s * s);
		f /= len;
		s /= len;
		double sin = Math.sin(yaw), cos = Math.cos(yaw);
		return new double[]{(-sin * f + cos * s) * speed, (cos * f + sin * s) * speed};
	}

	public static class Fly extends Module {
		final Setting.Num speed = num("Speed", 1.2, 0.2, 5, 0.1);
		final Setting.Num vertical = num("Vertical", 0.8, 0.1, 3, 0.1);

		public Fly() {
			super("Fly", "Free flight (bannable)", Category.BLATANT);
		}

		@Override
		public void onTick() {
			if (!ready()) return;
			double[] m = move(speed.get());
			double vy = (mc.options.jumpKey.isPressed() ? vertical.get() : 0) - (mc.options.sneakKey.isPressed() ? vertical.get() : 0);
			mc.player.setVelocity(m[0], vy, m[1]);
			mc.player.fallDistance = 0;
		}
	}

	public static class Speed extends Module {
		final Setting.Num speed = num("Speed", 0.6, 0.2, 3, 0.05);
		final Setting.Bool air = bool("In air", true);

		public Speed() {
			super("Speed", "Moves much faster than allowed (bannable)", Category.BLATANT);
		}

		@Override
		public void onTick() {
			if (!ready()) return;
			if (!air.on() && !mc.player.isOnGround()) return;
			double[] m = move(speed.get());
			if (m[0] == 0 && m[1] == 0) return;
			Vec3d v = mc.player.getVelocity();
			mc.player.setVelocity(m[0], v.y, m[1]);
		}
	}

	public static class Jetpack extends Module {
		final Setting.Num power = num("Power", 0.5, 0.1, 2, 0.05);

		public Jetpack() {
			super("Jetpack", "Hold jump to keep rising (bannable)", Category.BLATANT);
		}

		@Override
		public void onTick() {
			if (!ready() || !mc.options.jumpKey.isPressed()) return;
			Vec3d v = mc.player.getVelocity();
			mc.player.setVelocity(v.x, power.get(), v.z);
			mc.player.fallDistance = 0;
		}
	}

	public static class HighJump extends Module {
		final Setting.Num power = num("Power", 0.9, 0.5, 3, 0.05);

		public HighJump() {
			super("HighJump", "Jumps far higher than normal (bannable)", Category.BLATANT);
		}

		@Override
		public void onTick() {
			if (!ready() || !mc.player.isOnGround() || !mc.options.jumpKey.isPressed()) return;
			Vec3d v = mc.player.getVelocity();
			mc.player.setVelocity(v.x, power.get(), v.z);
		}
	}

	public static class Spider extends Module {
		public Spider() {
			super("Spider", "Climb any wall you touch (bannable)", Category.BLATANT);
		}

		@Override
		public void onTick() {
			if (!ready() || !mc.player.horizontalCollision) return;
			Vec3d v = mc.player.getVelocity();
			mc.player.setVelocity(v.x, 0.3, v.z);
		}
	}

	public static class Jesus extends Module {
		public Jesus() {
			super("Jesus", "Walk on water (bannable)", Category.BLATANT);
		}

		@Override
		public void onTick() {
			if (!ready() || mc.options.sneakKey.isPressed()) return;
			if (mc.player.isTouchingWater()) {
				Vec3d v = mc.player.getVelocity();
				mc.player.setVelocity(v.x, 0.16, v.z);
			}
		}
	}

	public static class AirJump extends Module {
		public AirJump() {
			super("AirJump", "Jump again while in the air (bannable)", Category.BLATANT);
		}

		@Override
		public void onTick() {
			if (!ready() || !mc.options.jumpKey.isPressed()) return;
			mc.player.setOnGround(true);
		}
	}

	public static class Phase extends Module {
		public Phase() {
			super("Phase", "Walk through blocks (bannable)", Category.BLATANT);
		}

		@Override
		public void onTick() {
			if (!ready()) return;
			mc.player.noClip = true;
			mc.player.setOnGround(false);
		}

		@Override
		public void onDisable() {
			if (mc.player != null) mc.player.noClip = false;
		}
	}

	public static class Nuker extends Module {
		final Setting.Num radius = num("Radius", 4, 1, 6, 1);
		final Setting.Num perTick = num("Blocks per tick", 4, 1, 20, 1);

		public Nuker() {
			super("Nuker", "Breaks every block around you (bannable)", Category.BLATANT);
		}

		@Override
		public void onTick() {
			if (!ready() || mc.interactionManager == null) return;
			int r = (int) radius.get(), left = (int) perTick.get();
			BlockPos c = mc.player.getBlockPos();
			for (int x = -r; x <= r && left > 0; x++) {
				for (int y = -r; y <= r && left > 0; y++) {
					for (int z = -r; z <= r && left > 0; z++) {
						BlockPos p = c.add(x, y, z);
						if (mc.world.getBlockState(p).isAir() || mc.world.getBlockState(p).getHardness(mc.world, p) < 0) continue;
						mc.interactionManager.attackBlock(p, Direction.UP);
						mc.interactionManager.updateBlockBreakingProgress(p, Direction.UP);
						left--;
					}
				}
			}
		}
	}

	public static class MultiAura extends Module {
		final Setting.Num range = num("Range", 5, 2, 8, 0.25);
		final Setting.Num maxTargets = num("Targets per tick", 4, 1, 12, 1);
		final Setting.Bool players = bool("Players", true);
		final Setting.Bool mobs = bool("Mobs", false);

		public MultiAura() {
			super("MultiAura", "Hits several targets every tick, no cooldown (bannable)", Category.BLATANT);
		}

		@Override
		public void onTick() {
			if (!ready()) return;
			int left = (int) maxTargets.get();
			double r2 = range.get() * range.get();
			for (Entity e : mc.world.getEntities()) {
				if (left <= 0) break;
				if (!(e instanceof LivingEntity le) || e == mc.player || !le.isAlive()) continue;
				boolean isPlayer = e instanceof net.minecraft.entity.player.PlayerEntity;
				if (isPlayer ? !players.on() : !mobs.on()) continue;
				if (mc.player.squaredDistanceTo(e) > r2) continue;
				Util.attack(e);
				left--;
			}
		}
	}
}
