package dev.ousek.module.impl;

import dev.ousek.module.Category;
import dev.ousek.module.Module;
import dev.ousek.setting.Setting;
import net.fabricmc.fabric.api.event.player.AttackEntityCallback;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.gui.DrawContext;
import net.minecraft.entity.Entity;
import net.minecraft.entity.player.PlayerEntity;
import net.minecraft.network.listener.PacketListener;
import net.minecraft.network.packet.Packet;
import net.minecraft.network.packet.s2c.play.EntityPositionS2CPacket;
import net.minecraft.network.packet.s2c.play.EntityPositionSyncS2CPacket;
import net.minecraft.network.packet.s2c.play.EntityS2CPacket;
import net.minecraft.util.ActionResult;

import java.util.HashSet;
import java.util.Iterator;
import java.util.Set;
import java.util.concurrent.ConcurrentHashMap;
import java.util.concurrent.ConcurrentLinkedQueue;

/**
 * Backtrack: holds back the server's movement packets of your combat target for a few milliseconds, so your client keeps
 * showing them where they were a moment ago. Packets are released in order once their delay has passed, so nothing is lost
 * and the target never teleports; the delay is dropped at once when you leave range, switch target or turn the module off.
 */
public class BacktrackModule extends Module {
	private record Held(Packet<?> packet, PacketListener listener, int id, long at) {
	}

	private static final ConcurrentLinkedQueue<Held> QUEUE = new ConcurrentLinkedQueue<>();
	private static final ConcurrentHashMap<Integer, Integer> PENDING = new ConcurrentHashMap<>();
	private static volatile Set<Integer> targets = Set.of();
	private static volatile BacktrackModule inst;
	private static volatile int lastTarget = -1;
	private static volatile long lastTargetAt;

	static {
		AttackEntityCallback.EVENT.register((player, world, hand, entity, hit) -> {
			if (player == MinecraftClient.getInstance().player && entity instanceof PlayerEntity) {
				lastTarget = entity.getId();
				lastTargetAt = System.currentTimeMillis();
			}
			return ActionResult.PASS;
		});
	}

	final Setting.Num delay = num("Delay (ms)", 150, 20, 600, 10);
	final Setting.Num range = num("Range", 6, 2, 12, 0.5);
	final Setting.Mode who = mode("Targets", "Combat target", "Combat target", "All players");
	final Setting.Num memory = num("Keep target (s)", 3, 1, 10, 1);
	final Setting.Bool freeze = bool("Freeze target (hold incoming movement)", false);
	private boolean previousFreeze;

	public BacktrackModule() {
		super("Backtrack", "Delays your target's movement so you hit where they were (bannable)", Category.BLATANT);
		inst = this;
	}

	@Override
	public String suffix() {
		return freeze.on() ? "Freeze" : (int) delay.get() + "ms";
	}

	// ---------------- network thread side ----------------

	/** Called from the network thread for every incoming play packet. Returns true when the packet was held. */
	public static boolean offer(Packet<?> p, PacketListener listener) {
		try {
			BacktrackModule b = inst;
			if (b == null || !b.enabled || listener == null) return false;
			MinecraftClient m = MinecraftClient.getInstance();
			if (m.world == null) return false;
			int id;
			if (p instanceof EntityS2CPacket e) {
				Entity en = e.getEntity(m.world);
				id = en == null ? -1 : en.getId();
			} else if (p instanceof EntityPositionS2CPacket e) {
				id = e.entityId();
			} else if (p instanceof EntityPositionSyncS2CPacket e) {
				id = e.id();
			} else {
				return false;
			}
			if (id < 0) return false;
			// once an entity has held packets every later one is held too, so they stay in order
			if (!targets.contains(id) && !PENDING.containsKey(id)) return false;
			PENDING.merge(id, 1, Integer::sum);
			// Keep the client-side packet buffer bounded during long Freeze sessions.
			// The newest packet is still queued after the oldest is evicted, avoiding
			// unbounded memory growth on high-packet-rate servers.
			if (QUEUE.size() >= 8192) {
				Held oldest = QUEUE.poll();
				if (oldest != null) PENDING.computeIfPresent(oldest.id(), (k, v) -> v <= 1 ? null : v - 1);
			}
			QUEUE.add(new Held(p, listener, id, System.currentTimeMillis()));
			return true;
		} catch (Throwable t) {
			return false;
		}
	}

	// ---------------- main thread side ----------------

	@Override
	public void onEnable() {
		previousFreeze = freeze.on();
	}

	@Override
	public void onTick() {
		if (!ready()) {
			QUEUE.clear();
			PENDING.clear();
			targets = Set.of();
			previousFreeze = freeze.on();
			return;
		}
		refreshTargets();
		// Turning Freeze off releases the buffered stream immediately. Normal Backtrack
		// delay then resumes for newly received packets.
		if (previousFreeze && !freeze.on()) release(true);
		previousFreeze = freeze.on();
		release(false);
	}

	@Override
	public void onHud(DrawContext ctx) {
		release(false); // also every frame, so the delay is not rounded to 50 ms ticks
	}

	@Override
	public void onDisable() {
		targets = Set.of();
		release(true);
	}

	private void refreshTargets() {
		long now = System.currentTimeMillis();
		Entity aimed = mc.targetedEntity;
		if (aimed instanceof PlayerEntity && aimed != mc.player) {
			lastTarget = aimed.getId();
			lastTargetAt = now;
		}
		boolean all = "All players".equals(who.value);
		double r2 = range.get() * range.get();
		Set<Integer> s = new HashSet<>();
		for (Entity e : mc.world.getEntities()) {
			if (!(e instanceof PlayerEntity pe) || e == mc.player || !pe.isAlive()) continue;
			if (mc.player.squaredDistanceTo(e) > r2) continue;
			if (all || (e.getId() == lastTarget && now - lastTargetAt <= memory.get() * 1000.0)) s.add(e.getId());
		}
		targets = s;
	}

	private void release(boolean all) {
		if (QUEUE.isEmpty()) return;
		long now = System.currentTimeMillis();
		long d = (long) delay.get();
		Object handler = mc.getNetworkHandler();
		Set<Integer> t = targets;
		for (Iterator<Held> it = QUEUE.iterator(); it.hasNext(); ) {
			Held h = it.next();
			// Freeze holds the selected target's incoming movement packets before they
			// reach the client entity handler. The target therefore stays at its last
			// rendered position on this client; no server-side state is changed.
			if (!all && t.contains(h.id()) && (freeze.on() || now - h.at() < d)) continue;
			it.remove();
			PENDING.computeIfPresent(h.id(), (k, v) -> v <= 1 ? null : v - 1);
			if (h.listener() != handler) continue; // connection changed: drop it
			try {
				@SuppressWarnings({"unchecked", "rawtypes"})
				Packet<PacketListener> p = (Packet) h.packet();
				p.apply(h.listener());
			} catch (Throwable ignored) {
			}
		}
	}
}
