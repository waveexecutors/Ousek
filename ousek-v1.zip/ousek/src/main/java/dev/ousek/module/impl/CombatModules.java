package dev.ousek.module.impl;

import dev.ousek.module.Category;
import dev.ousek.module.Module;
import dev.ousek.module.Util;
import dev.ousek.setting.Setting;
import net.minecraft.component.DataComponentTypes;
import net.minecraft.component.type.EquippableComponent;
import net.minecraft.entity.EquipmentSlot;
import net.minecraft.entity.LivingEntity;
import net.minecraft.item.ItemStack;
import net.minecraft.item.Items;
import net.minecraft.registry.tag.ItemTags;
import net.minecraft.screen.slot.SlotActionType;
import net.minecraft.util.hit.EntityHitResult;
import net.minecraft.util.math.MathHelper;

import java.util.Comparator;
import java.util.List;

public final class CombatModules {
	private CombatModules() {
	}

	public static void register(List<Module> list) {
		// AutoCrit ticks before KillAura so a prepared hop can start before the next swing.
		list.add(new AutoCrit());
		list.add(new KillAura());
		list.add(new AutoClicker());
		list.add(new TriggerBot());
		list.add(new AimAssist());
		list.add(new AutoTotem());
		list.add(new AutoArmor());
		list.add(new AutoSword());
	}

	public static class KillAura extends Module {
		public static LivingEntity target;
		final Setting.Num range = num("Range", 3.5, 1, 6, 0.1);
		final Setting.Bool players = bool("Players", true);
		final Setting.Bool mobs = bool("Mobs", false);
		final Setting.Bool rotate = bool("Rotate", true);
		final Setting.Bool cooldown = bool("Cooldown", true);
		final Setting.Num cps = num("CPS (no cooldown)", 10, 1, 20, 1);
		final Setting.Mode sort = mode("Sort", "Distance", "Distance", "Health");
		long last;

		public KillAura() {
			super("KillAura", "Attacks nearby entities", Category.COMBAT);
		}

		@Override
		public void onDisable() {
			target = null;
		}

		@Override
		public String suffix() {
			return sort.value;
		}

		@Override
		public void onTick() {
			List<LivingEntity> t = Util.targets(range.get(), players.on(), mobs.on());
			if (t.isEmpty()) {
				target = null;
				return;
			}
			Comparator<LivingEntity> c = sort.is("Health")
					? Comparator.comparingDouble(LivingEntity::getHealth)
					: Comparator.comparingDouble(e -> mc.player.distanceTo(e));
			t.sort(c);
			target = t.get(0);
			if (rotate.on()) {
				float[] r = Util.rotationsTo(target);
				mc.player.setYaw(r[0]);
				mc.player.setPitch(MathHelper.clamp(r[1], -90f, 90f));
			}
			long now = System.currentTimeMillis();
			boolean ready = cooldown.on()
					? mc.player.getAttackCooldownProgress(0.5f) >= 0.95f
					: now - last >= 1000.0 / cps.get();
			if (ready && !AutoCrit.shouldWaitForCrit()) {
				Util.attack(target);
				last = now;
			}
		}
	}

	public static class AutoClicker extends Module {
		final Setting.Num cps = num("CPS", 10, 1, 20, 1);
		final Setting.Bool blocks = bool("Hold to click", true);
		long last;

		public AutoClicker() {
			super("AutoClicker", "Clicks for you while attack is held", Category.COMBAT);
		}

		@Override
		public void onTick() {
			if (mc.currentScreen != null || !mc.options.attackKey.isPressed()) return;
			long now = System.currentTimeMillis();
			if (now - last < 1000.0 / cps.get()) return;
			if (mc.crosshairTarget instanceof EntityHitResult r) {
				Util.attack(r.getEntity());
				last = now;
			}
		}
	}

	public static class TriggerBot extends Module {
		final Setting.Bool players = bool("Players only", false);

		public TriggerBot() {
			super("TriggerBot", "Attacks what your crosshair is on", Category.COMBAT);
		}

		@Override
		public void onTick() {
			if (mc.currentScreen != null) return;
			if (mc.crosshairTarget instanceof EntityHitResult r && r.getEntity() instanceof LivingEntity le) {
				if (players.on() && !(le instanceof net.minecraft.entity.player.PlayerEntity)) return;
				if (mc.player.getAttackCooldownProgress(0.5f) >= 0.95f) Util.attack(le);
			}
		}
	}

	public static class AimAssist extends Module {
		final Setting.Num range = num("Range", 4.5, 2, 8, 0.1);
		final Setting.Num speed = num("Speed", 6, 1, 30, 1);
		final Setting.Num fov = num("FOV", 90, 10, 180, 5);

		public AimAssist() {
			super("AimAssist", "Smoothly nudges your aim to players", Category.COMBAT);
		}

		@Override
		public void onTick() {
			if (mc.currentScreen != null) return;
			List<LivingEntity> t = Util.targets(range.get(), true, false);
			LivingEntity best = null;
			float bestDiff = 999;
			for (LivingEntity e : t) {
				float[] r = Util.rotationsTo(e);
				float d = Math.abs(MathHelper.wrapDegrees(r[0] - mc.player.getYaw()));
				if (d < fov.get() / 2 && d < bestDiff) {
					bestDiff = d;
					best = e;
				}
			}
			if (best == null) return;
			float[] r = Util.rotationsTo(best);
			float yd = MathHelper.wrapDegrees(r[0] - mc.player.getYaw());
			float pd = r[1] - mc.player.getPitch();
			float s = speed.f();
			mc.player.setYaw(mc.player.getYaw() + MathHelper.clamp(yd, -s, s));
			mc.player.setPitch(MathHelper.clamp(mc.player.getPitch() + MathHelper.clamp(pd, -s / 2, s / 2), -90, 90));
		}
	}

	public static class AutoCrit extends Module {
		final Setting.Mode mode = mode("Mode", "Legit", "Legit", "Smart", "Jump", "MiniHop", "Strict");
		final Setting.Num cooldown = num("Attack cooldown %", 90, 50, 100, 1);
		final Setting.Num miniHop = num("Mini hop", 0.18, 0.08, 0.30, 0.01);
		private boolean hopArmed;
		private boolean critWindow;

		public AutoCrit() {
			super("AutoCrit", "Times a hop so Aura can strike while falling", Category.COMBAT);
		}

		@Override
		public String suffix() {
			return mode.value;
		}

		@Override
		public void onEnable() {
			hopArmed = false;
			critWindow = false;
		}

		@Override
		public void onDisable() {
			hopArmed = false;
			critWindow = false;
		}

		private boolean canHop() {
			return mc.player != null && mc.player.isOnGround() && !mc.player.isTouchingWater()
					&& !mc.player.isSubmergedInWater() && !mc.player.isClimbing()
					&& !mc.player.hasVehicle() && !mc.player.isGliding();
		}

		private LivingEntity currentTarget(boolean manualAttack) {
			if ((mode.is("Legit") || mode.is("Strict"))
					&& mc.crosshairTarget instanceof EntityHitResult hit
					&& hit.getEntity() instanceof LivingEntity living && living != mc.player) return living;
			if (KillAura.target != null) return KillAura.target;
			if (manualAttack && mc.crosshairTarget instanceof EntityHitResult hit
					&& hit.getEntity() instanceof LivingEntity living && living != mc.player) return living;
			return null;
		}

		private boolean readyForSwing() {
			return mc.player.getAttackCooldownProgress(0.5f) >= cooldown.f() / 100.0f;
		}

		/** KillAura waits for the descending part of an AutoCrit hop. */
		public static boolean shouldWaitForCrit() {
			AutoCrit module = dev.ousek.module.ModuleManager.get(AutoCrit.class);
			return module != null && module.enabled && module.hopArmed && !module.critWindow;
		}

		@Override
		public void onTick() {
			critWindow = false;
			if (mc.player == null || mc.currentScreen != null) return;

			if (hopArmed && !mc.player.isOnGround()) {
				critWindow = mc.player.fallDistance > 0.0f && mc.player.getVelocity().y < 0.0;
				return;
			}
			if (mc.player.isOnGround()) hopArmed = false;
			if (!canHop()) return;

			boolean manualAttack = mc.options.attackKey.isPressed();
			if (mode.is("Strict") && !manualAttack) return;
			if (mode.is("Legit") && !manualAttack) return;

			LivingEntity target = currentTarget(manualAttack);
			if (target == null) return;
			if (mode.is("Strict") && !(target instanceof net.minecraft.entity.player.PlayerEntity)) return;
			if (mode.is("Strict")
					&& mc.player.getAttackCooldownProgress(0.5f) < 1.0f) return;
			if (!mode.is("Jump") && !readyForSwing()) return;

			if (mode.is("MiniHop")) {
				var velocity = mc.player.getVelocity();
				mc.player.setVelocity(velocity.x, miniHop.get(), velocity.z);
			} else {
				mc.player.jump();
			}
			hopArmed = true;
		}
	}

	public static class AutoTotem extends Module {
		final Setting.Num delay = num("Delay", 2, 0, 10, 1);
		int wait;

		public AutoTotem() {
			super("AutoTotem", "Keeps a totem in your offhand", Category.COMBAT);
		}

		@Override
		public void onTick() {
			if (mc.currentScreen != null) return;
			if (mc.player.getOffHandStack().isOf(Items.TOTEM_OF_UNDYING)) return;
			if (wait-- > 0) return;
			for (int i = 0; i < 36; i++) {
				if (mc.player.getInventory().getStack(i).isOf(Items.TOTEM_OF_UNDYING)) {
					mc.interactionManager.clickSlot(mc.player.playerScreenHandler.syncId,
							Util.invToScreen(i), 40, SlotActionType.SWAP, mc.player);
					wait = delay.i();
					return;
				}
			}
		}
	}

	public static class AutoArmor extends Module {
		final Setting.Num delay = num("Delay", 4, 1, 20, 1);
		int wait;

		public AutoArmor() {
			super("AutoArmor", "Equips armor from your inventory", Category.COMBAT);
		}

		@Override
		public void onTick() {
			if (mc.currentScreen != null) return;
			if (wait-- > 0) return;
			EquipmentSlot[] slots = {EquipmentSlot.HEAD, EquipmentSlot.CHEST, EquipmentSlot.LEGS, EquipmentSlot.FEET};
			for (EquipmentSlot slot : slots) {
				if (!mc.player.getEquippedStack(slot).isEmpty()) continue;
				for (int i = 0; i < 36; i++) {
					ItemStack s = mc.player.getInventory().getStack(i);
					EquippableComponent eq = s.get(DataComponentTypes.EQUIPPABLE);
					if (eq != null && eq.slot() == slot) {
						mc.interactionManager.clickSlot(mc.player.playerScreenHandler.syncId,
								Util.invToScreen(i), 0, SlotActionType.QUICK_MOVE, mc.player);
						wait = delay.i();
						return;
					}
				}
			}
		}
	}

	public static class AutoSword extends Module {
		public AutoSword() {
			super("AutoSword", "Switches to a sword when you attack", Category.COMBAT);
		}

		@Override
		public void onTick() {
			if (mc.currentScreen != null || !mc.options.attackKey.isPressed()) return;
			if (mc.player.getMainHandStack().isIn(ItemTags.SWORDS)) return;
			for (int i = 0; i < 9; i++) {
				if (mc.player.getInventory().getStack(i).isIn(ItemTags.SWORDS)) {
					mc.player.getInventory().setSelectedSlot(i);
					return;
				}
			}
		}
	}
}
