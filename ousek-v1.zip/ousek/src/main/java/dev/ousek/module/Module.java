package dev.ousek.module;

import dev.ousek.hud.Hud;
import dev.ousek.setting.Setting;
import net.minecraft.client.MinecraftClient;

import java.util.ArrayList;
import java.util.List;

public abstract class Module {
	protected static final MinecraftClient mc = MinecraftClient.getInstance();

	public final String name;
	public final String desc;
	public final Category category;
	public final List<Setting<?>> settings = new ArrayList<>();

	public boolean enabled;
	public int key = -1;
	public boolean expanded;
	public boolean keyDown;

	protected Module(String name, String desc, Category category) {
		this.name = name;
		this.desc = desc;
		this.category = category;
	}

	protected Module(String name, String desc, Category category, int defaultKey) {
		this(name, desc, category);
		this.key = defaultKey;
	}

	public void toggle() {
		setEnabled(!enabled);
	}

	public void setEnabled(boolean value) {
		if (enabled == value) return;
		enabled = value;
		try {
			if (value) onEnable();
			else onDisable();
		} catch (Throwable ignored) {
		}
		if (category != Category.HUD && category != Category.CLIENT) {
			Hud.notify(name + (value ? " enabled" : " disabled"), value);
		}
	}

	public void onKey() {
		toggle();
	}

	public void onEnable() {
	}

	public void onDisable() {
	}

	public void onTick() {
	}

	public void onChat(String message) {
	}

	public String suffix() {
		return null;
	}

	protected Setting.Bool bool(String n, boolean def) {
		Setting.Bool s = new Setting.Bool(n, def);
		settings.add(s);
		return s;
	}

	protected Setting.Num num(String n, double def, double min, double max, double step) {
		Setting.Num s = new Setting.Num(n, def, min, max, step);
		settings.add(s);
		return s;
	}

	protected Setting.Mode mode(String n, String def, String... modes) {
		Setting.Mode s = new Setting.Mode(n, def, modes);
		settings.add(s);
		return s;
	}

	protected boolean ready() {
		return mc.player != null && mc.world != null;
	}
}
