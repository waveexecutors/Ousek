package dev.ousek.module.impl;

import com.google.gson.JsonObject;
import com.google.gson.JsonParser;
import dev.ousek.gui.Fonts;
import dev.ousek.module.Category;
import dev.ousek.module.Module;
import dev.ousek.music.MusicPlayer;
import dev.ousek.setting.Setting;
import net.minecraft.client.gui.DrawContext;
import net.minecraft.text.Text;
import net.minecraft.util.math.MathHelper;

import java.net.URI;
import java.net.URLEncoder;
import java.net.http.HttpClient;
import java.net.http.HttpRequest;
import java.net.http.HttpResponse;
import java.nio.charset.StandardCharsets;
import java.time.Duration;
import java.util.ArrayList;
import java.util.List;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

/** Timed lyrics HUD. LRCLIB is a keyless fallback because Audius does not expose lyrics in its track API. */
public final class Lyrics3DModule extends Module {
    private record Line(long time, String text) {}
    private static final Pattern STAMP = Pattern.compile("\\[(\\d{1,2}):(\\d{2})(?:\\.(\\d{1,3}))?\\]");
    private static final HttpClient HTTP = HttpClient.newBuilder().connectTimeout(Duration.ofSeconds(7))
            .followRedirects(HttpClient.Redirect.NORMAL).build();
    private static volatile List<Line> lines = List.of();
    private static volatile String loadedKey = "";
    private static volatile String loadingKey = "";
    private static volatile String message = "";
    private long lastTrackCheck;
    private long lineChangedAt;
    private int shownLine = -1;
    private float smoothAnchorX = Float.NaN;
    private float smoothAnchorY = Float.NaN;

    public final Setting.Mode color = mode("Color", "Accent", "Accent", "White", "Cyan", "Purple", "Rainbow");
    public final Setting.Num scale = num("Text scale", 1.15, 0.65, 2.0, 0.05);
    public final Setting.Num heightAboveCrosshair = num("Height above crosshair", 48, 12, 220, 1);
    public final Setting.Num curve = num("Curve amount", 12, 0, 36, 1);
    public final Setting.Num glow = num("Glow strength", 3, 0, 8, 1);
    public final Setting.Num spacing = num("Letter spacing", 0, -2, 8, 0.5);
    public final Setting.Num maxWidth = num("Max width", 320, 120, 600, 10);
    public final Setting.Num fade = num("Fade duration (ms)", 450, 100, 1500, 50);
    public final Setting.Bool showNext = bool("Preview next line", true);
    public final Setting.Bool shadow = bool("Extra depth shadow", true);
    public final Setting.Bool hideWithoutLyrics = bool("Hide when unavailable", true);

    public Lyrics3DModule() {
        super("3D Lyrics", "Curved animated synchronized lyrics above the hotbar", Category.RENDER);
    }

    @Override public String suffix() { return color.value; }

    @Override
    public void onHud(DrawContext ctx) {
        MusicPlayer.Track track = MusicPlayer.current;
        if (track == null || !MusicPlayer.playing) return;
        long now = System.currentTimeMillis();
        if (now - lastTrackCheck > 800) {
            lastTrackCheck = now;
            String key = track.title() + "\\u0000" + track.artist();
            if (!key.equals(loadedKey) && !key.equals(loadingKey)) fetch(track, key);
        }
        List<Line> current = lines;
        if (current.isEmpty()) {
            if (!hideWithoutLyrics.on() && !message.isEmpty()) drawCentered(ctx, message, 0xFFB9B9C4, 0.75f);
            return;
        }
        long pos = MusicPlayer.posMs;
        int index = -1;
        for (int i = 0; i < current.size(); i++) {
            if (current.get(i).time() <= pos) index = i;
            else break;
        }
        if (index < 0) return;
        if (index != shownLine) {
            shownLine = index;
            lineChangedAt = now;
        }
        float in = MathHelper.clamp((now - lineChangedAt) / (float) fade.get(), 0f, 1f);
        float alpha = ease(in);
        String line = current.get(index).text();
        drawCurved(ctx, line, color(), alpha, 1f, 0f);
        if (showNext.on() && index + 1 < current.size()) {
            long until = current.get(index + 1).time() - pos;
            if (until < 2400) {
                float a = MathHelper.clamp(1f - until / 2400f, 0f, 0.55f);
                drawCurved(ctx, current.get(index + 1).text(), 0xFFB7BAC6, a, 0.62f, 18f);
            }
        }
    }

    private void fetch(MusicPlayer.Track track, String key) {
        loadingKey = key;
        lines = List.of();
        message = "Loading lyrics...";
        Thread t = new Thread(() -> {
            try {
                String url = "https://lrclib.net/api/get?track_name=" + enc(track.title())
                        + "&artist_name=" + enc(track.artist()) + "&duration=" + track.seconds();
                HttpRequest req = HttpRequest.newBuilder(URI.create(url)).timeout(Duration.ofSeconds(10))
                        .header("User-Agent", "OusekClient/1.0").GET().build();
                HttpResponse<String> response = HTTP.send(req, HttpResponse.BodyHandlers.ofString());
                List<Line> parsed = new ArrayList<>();
                if (response.statusCode() == 200) {
                    JsonObject json = JsonParser.parseString(response.body()).getAsJsonObject();
                    String synced = json.has("syncedLyrics") && !json.get("syncedLyrics").isJsonNull()
                            ? json.get("syncedLyrics").getAsString() : "";
                    parsed = parse(synced);
                }
                if (parsed.isEmpty()) {
                    String searchUrl = "https://lrclib.net/api/search?track_name=" + enc(track.title())
                            + "&artist_name=" + enc(track.artist());
                    HttpRequest searchReq = HttpRequest.newBuilder(URI.create(searchUrl)).timeout(Duration.ofSeconds(10))
                            .header("User-Agent", "OusekClient/1.0").GET().build();
                    HttpResponse<String> searchResponse = HTTP.send(searchReq, HttpResponse.BodyHandlers.ofString());
                    if (searchResponse.statusCode() == 200 && JsonParser.parseString(searchResponse.body()).isJsonArray()) {
                        for (var item : JsonParser.parseString(searchResponse.body()).getAsJsonArray()) {
                            if (!item.isJsonObject()) continue;
                            JsonObject candidate = item.getAsJsonObject();
                            if (candidate.has("syncedLyrics") && !candidate.get("syncedLyrics").isJsonNull()) {
                                parsed = parse(candidate.get("syncedLyrics").getAsString());
                                if (!parsed.isEmpty()) break;
                            }
                        }
                    }
                }
                if (parsed.isEmpty()) throw new IllegalStateException("No synchronized lyrics for this track");
                if ((track.title() + "\\u0000" + track.artist()).equals(loadingKey)) {
                    lines = List.copyOf(parsed);
                    loadedKey = key;
                    message = "";
                }
            } catch (Throwable e) {
                if (key.equals(loadingKey)) {
                    loadedKey = key;
                    message = "Synchronized lyrics unavailable";
                }
            }
        }, "ousek-lyrics");
        t.setDaemon(true);
        t.start();
    }

    private static List<Line> parse(String raw) {
        List<Line> out = new ArrayList<>();
        for (String row : raw.split("\\R")) {
            Matcher m = STAMP.matcher(row);
            String text = STAMP.matcher(row).replaceAll("").trim();
            while (m.find()) {
                long min = Long.parseLong(m.group(1));
                long sec = Long.parseLong(m.group(2));
                String frac = m.group(3) == null ? "0" : m.group(3);
                long ms = frac.length() == 1 ? Long.parseLong(frac) * 100
                        : frac.length() == 2 ? Long.parseLong(frac) * 10 : Long.parseLong(frac);
                if (!text.isEmpty()) out.add(new Line((min * 60 + sec) * 1000 + ms, text));
            }
        }
        out.sort((a,b) -> Long.compare(a.time(), b.time()));
        return out;
    }

    private void drawCurved(DrawContext ctx, String raw, int base, float alpha, float size, float lineOffset) {
        if (alpha <= 0.01f) return;
        String value = raw.length() > 100 ? raw.substring(0, 100) : raw;
        var tr = mc.textRenderer;
        float sc = (float) scale.get() * size;
        float spacingPx = (float) spacing.get();
        float total = 0;
        for (int i = 0; i < value.length(); i++) total += tr.getWidth(String.valueOf(value.charAt(i))) * sc + spacingPx;
        float limit = (float) maxWidth.get();
        if (total > limit && total > 0) sc *= limit / total;
        float screenCenterX = ctx.getScaledWindowWidth() / 2f;
        float screenCenterY = ctx.getScaledWindowHeight() / 2f;
        if (Float.isNaN(smoothAnchorX) || Float.isNaN(smoothAnchorY)) {
            smoothAnchorX = screenCenterX;
            smoothAnchorY = screenCenterY - (float) heightAboveCrosshair.get();
        }
        // Smoothly track the HUD anchor (screen center/crosshair) if the viewport changes.
        smoothAnchorX += (screenCenterX - smoothAnchorX) * 0.28f;
        float targetY = screenCenterY - (float) heightAboveCrosshair.get();
        smoothAnchorY += (targetY - smoothAnchorY) * 0.28f;
        float x = smoothAnchorX - total * (sc / ((float) scale.get() * size)) / 2f;
        float y = smoothAnchorY + lineOffset;
        float center = value.length() / 2f;
        float cursor = x;
        int c = (base & 0x00FFFFFF) | ((int)(255 * alpha) << 24);
        for (int i = 0; i < value.length(); i++) {
            String ch = String.valueOf(value.charAt(i));
            float cw = tr.getWidth(ch) * sc;
            int glyphColor = color.value.equals("Rainbow")
                    ? rainbow(i, value.length(), alpha) : c;
            float t = value.length() <= 1 ? 0 : (i - center) / Math.max(1f, center);
            float cy = y + (float) curve.get() * t * t;
            ctx.getMatrices().pushMatrix();
            ctx.getMatrices().translate(cursor, cy);
            ctx.getMatrices().scale(sc, sc);
            if (shadow.on()) ctx.drawText(tr, Fonts.text(ch, Fonts.PROXIMA), 0, 0, 0xAA000000, true);
            int g = (int) glow.get();
            for (int k = g; k >= 1; k--) {
                int gc = (c & 0x00FFFFFF) | ((int)(alpha * (22f / k)) << 24);
                ctx.drawText(tr, Fonts.text(ch, Fonts.PROXIMA), (int)(-k * 0.18f), 0, gc, false);
                ctx.drawText(tr, Fonts.text(ch, Fonts.PROXIMA), (int)(k * 0.18f), 0, gc, false);
            }
            ctx.drawText(tr, Fonts.text(ch, Fonts.PROXIMA), 0, 0, glyphColor, true);
            ctx.getMatrices().popMatrix();
            cursor += cw + spacingPx;
        }
    }

    private void drawCentered(DrawContext ctx, String s, int color, float alpha) {
        int w = Fonts.width(mc.textRenderer, s);
        Fonts.draw(ctx, mc.textRenderer, s, ctx.getScaledWindowWidth()/2-w/2,
                ctx.getScaledWindowHeight()/2-(int)heightAboveCrosshair.get(), (color & 0x00FFFFFF) | ((int)(255*alpha)<<24), true);
    }

    private static int rainbow(int index, int count, float alpha) {
        float hue = (System.currentTimeMillis() % 5000L) / 5000f + index / (float)Math.max(1, count);
        int rgb = java.awt.Color.HSBtoRGB(hue % 1f, 0.72f, 1f);
        return (rgb & 0x00FFFFFF) | ((int)(255 * alpha) << 24);
    }

    private int color() {
        return switch (color.value) {
            case "White" -> 0xFFFFFFFF;
            case "Cyan" -> 0xFF67E8FF;
            case "Purple" -> 0xFFB58CFF;
            case "Rainbow" -> 0xFFFF72C8;
            default -> dev.ousek.gui.Theme.accent();
        };
    }

    private static float ease(float x) { return x*x*(3f-2f*x); }
    private static String enc(String s) { return java.net.URLEncoder.encode(s, StandardCharsets.UTF_8); }
}
