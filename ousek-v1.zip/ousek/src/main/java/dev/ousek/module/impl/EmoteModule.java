package dev.ousek.module.impl;

import dev.ousek.emote.EmoteManager;
import dev.ousek.gui.EmoteScreen;
import dev.ousek.module.Category;
import dev.ousek.module.Module;
import net.minecraft.client.MinecraftClient;

/** Opens the emote picker (keybind or toggle) and keeps emote playback ticking. */
public class EmoteModule extends Module {
	public EmoteModule() {
		super("Emotes", "Play JSON emotes on your character", Category.PLAYER);
	}

	@Override
	public void onEnable() {
		// Defer screen open to next tick so we don't open while ClickGUI is handling the click
		MinecraftClient mc = MinecraftClient.getInstance();
		if (mc == null) return;
		mc.execute(() -> {
			try {
				EmoteManager.ensureLoaded();
				if (mc.currentScreen instanceof EmoteScreen) return;
				mc.setScreen(new EmoteScreen(mc.currentScreen));
			} catch (Throwable ignored) {
			}
		});
	}

	@Override
	public void onTick() {
		try {
			EmoteManager.tickClient();
			if (EmoteManager.playing != null && !EmoteManager.allowMove && mc.player != null) {
				if (mc.player.isOnGround()) {
					mc.player.setVelocity(mc.player.getVelocity().x * 0.2, mc.player.getVelocity().y, mc.player.getVelocity().z * 0.2);
				}
			}
		} catch (Throwable ignored) {
		}
	}
}
