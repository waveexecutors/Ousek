package dev.ousek.module.impl;

import dev.ousek.emote.EmoteManager;
import dev.ousek.gui.EmoteScreen;
import dev.ousek.module.Category;
import dev.ousek.module.Module;
import net.minecraft.client.MinecraftClient;

/** Opens the emote picker and keeps emote playback ticking. */
public class EmoteModule extends Module {
	public EmoteModule() {
		super("Emotes", "Play JSON emotes on your character", Category.PLAYER);
	}

	@Override
	public void onEnable() {
		MinecraftClient mc = MinecraftClient.getInstance();
		if (mc != null) {
			EmoteManager.ensureLoaded();
			mc.setScreen(new EmoteScreen(mc.currentScreen));
		}
		// stay enabled so tick continues; user closes screen independently
	}

	@Override
	public void onTick() {
		EmoteManager.tickClient();
		// if movement not allowed while emoting, lightly damp motion
		if (EmoteManager.playing != null && !EmoteManager.allowMove && mc.player != null) {
			if (mc.player.isOnGround()) {
				mc.player.setVelocity(mc.player.getVelocity().x * 0.2, mc.player.getVelocity().y, mc.player.getVelocity().z * 0.2);
			}
		}
	}
}
