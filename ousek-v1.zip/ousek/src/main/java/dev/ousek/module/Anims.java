package dev.ousek.module;

/** Attack animation curves. Remaps vanilla's linear swing progress into other shapes. */
public final class Anims {
	public static boolean active;
	public static int index;
	public static double speed = 1.0;

	public static final String[] NAMES = {
			"Vanilla", "Smoothstep", "Smootherstep", "Snap", "Heavy", "Whip", "Sharp Stab", "Flick",
			"Sine In", "Sine Out", "Sine InOut",
			"Quad In", "Quad Out", "Quad InOut",
			"Cubic In", "Cubic Out", "Cubic InOut",
			"Quart In", "Quart Out", "Quart InOut",
			"Quint In", "Quint Out", "Quint InOut",
			"Expo In", "Expo Out", "Expo InOut",
			"Circ In", "Circ Out", "Circ InOut",
			"Back In", "Back Out", "Back InOut",
			"Elastic In", "Elastic Out", "Elastic InOut",
			"Bounce In", "Bounce Out", "Bounce InOut",
			"Double Hit", "Triple Hit", "Wobble", "Pulse",
			"Quick In", "Quick Out", "Back Snap", "Soft Back", "Rubberband", "Stepped",
			"Two Tap", "Three Tap", "Pendulum", "Arc", "Flick Back", "Spring",
			"Damped Spring", "Swoop", "Boomerang", "Glide", "Jolt", "Elastic Snap",
			"Ease Then Strike", "Delayed Strike", "Fast Return", "Overshoot Lite",
			"Soft Landing", "Oscillate"
	};

	private Anims() {
	}

	public static int indexOf(String name) {
		for (int i = 0; i < NAMES.length; i++) if (NAMES[i].equals(name)) return i;
		return 0;
	}

	public static double apply(int idx, double t) {
		double r;
		switch (idx) {
			case 1 -> r = t * t * (3 - 2 * t);
			case 2 -> r = t * t * t * (t * (6 * t - 15) + 10);
			case 3 -> r = 1 - Math.pow(1 - t, 6);
			case 4 -> r = t * t * t * (4 - 3 * t);
			case 5 -> r = t < 0.8 ? 0.15 * (t / 0.8) : 0.15 + 0.85 * Math.sqrt((t - 0.8) / 0.2);
			case 6 -> {
				double u = t / 0.35;
				r = t < 0.35 ? (1 - Math.pow(1 - u, 3)) * 0.9 : 0.9 + 0.1 * (t - 0.35) / 0.65;
			}
			case 7 -> r = 1 - Math.pow(1 - t, 3) * Math.cos(t * Math.PI * 1.5);
			case 8 -> r = sine(t, 0);
			case 9 -> r = sine(t, 1);
			case 10 -> r = sine(t, 2);
			case 11 -> r = poly(t, 2, 0);
			case 12 -> r = poly(t, 2, 1);
			case 13 -> r = poly(t, 2, 2);
			case 14 -> r = poly(t, 3, 0);
			case 15 -> r = poly(t, 3, 1);
			case 16 -> r = poly(t, 3, 2);
			case 17 -> r = poly(t, 4, 0);
			case 18 -> r = poly(t, 4, 1);
			case 19 -> r = poly(t, 4, 2);
			case 20 -> r = poly(t, 5, 0);
			case 21 -> r = poly(t, 5, 1);
			case 22 -> r = poly(t, 5, 2);
			case 23 -> r = expo(t, 0);
			case 24 -> r = expo(t, 1);
			case 25 -> r = expo(t, 2);
			case 26 -> r = circ(t, 0);
			case 27 -> r = circ(t, 1);
			case 28 -> r = circ(t, 2);
			case 29 -> r = back(t, 0);
			case 30 -> r = back(t, 1);
			case 31 -> r = back(t, 2);
			case 32 -> r = elastic(t, 0);
			case 33 -> r = elastic(t, 1);
			case 34 -> r = elastic(t, 2);
			case 35 -> r = bounce(t, 0);
			case 36 -> r = bounce(t, 1);
			case 37 -> r = bounce(t, 2);
			case 38 -> {
				double u = t * 2;
				r = u > 1 ? u - 1 : u;
			}
			case 39 -> {
				double u = t * 3;
				r = u > 2 ? u - 2 : u > 1 ? u - 1 : u;
			}
			case 40 -> r = t + 0.12 * Math.sin(t * Math.PI * 6) * (1 - t);
			case 41 -> r = t + 0.2 * Math.sin(t * Math.PI * 3);
			case 42 -> r = 1 - Math.pow(1 - t, 8);
			case 43 -> r = Math.pow(t, 0.58);
			case 44 -> r = 1 - Math.pow(1 - t, 3) + 0.16 * Math.sin(t * Math.PI * 2) * (1 - t);
			case 45 -> r = t * t * (2.8 * t - 1.8);
			case 46 -> r = t + 0.14 * Math.sin(t * Math.PI * 5) * (1 - t);
			case 47 -> r = t >= 1 ? 1 : Math.floor(t * 6) / 5.0;
			case 48 -> r = t < 0.34 ? (t / 0.34) * 0.78 : 0.78 + (t - 0.34) / 0.66 * 0.22;
			case 49 -> r = t < 0.25 ? t * 2.4 : t < 0.58 ? 0.6 + (t - 0.25) * 0.8 : 0.86 + (t - 0.58) * 0.34;
			case 50 -> r = t + 0.17 * Math.sin(t * Math.PI * 2) * (1 - t);
			case 51 -> r = t + 0.12 * Math.sin(Math.PI * t);
			case 52 -> r = 1 - Math.pow(1 - t, 2.5) + 0.12 * Math.sin(t * Math.PI * 4) * (1 - t);
			case 53 -> r = 1 - Math.exp(-7 * t) * Math.cos(9 * t);
			case 54 -> r = 1 - Math.exp(-6 * t) * (1 + 6 * t);
			case 55 -> r = t < 0.62 ? 1 - Math.pow(1 - t / 0.62, 3) : 0.92 + 0.08 * ((t - 0.62) / 0.38);
			case 56 -> r = t < 0.5 ? 2 * t * t : 1 - 2 * (1 - t) * (1 - t);
			case 57 -> r = t * t * (3 - 2 * t) * 0.72 + t * 0.28;
			case 58 -> r = t + 0.08 * Math.sin(t * Math.PI * 12) * (1 - t);
			case 59 -> r = 1 - Math.pow(2, -9 * t) * Math.cos(t * Math.PI * 3.5);
			case 60 -> r = t < 0.45 ? 0.18 * (t / 0.45) : 0.18 + 0.82 * Math.pow((t - 0.45) / 0.55, 0.42);
			case 61 -> r = t < 0.72 ? Math.pow(t / 0.72, 0.68) * 0.96 : 0.96 + 0.04 * ((t - 0.72) / 0.28);
			case 62 -> r = 1 - Math.pow(1 - t, 4) + 0.08 * Math.sin(t * Math.PI * 3) * (1 - t);
			case 63 -> r = t < 0.28 ? 0.04 : 0.04 + 0.96 * Math.pow((t - 0.28) / 0.72, 0.7);
			case 64 -> r = 1 - Math.pow(1 - t, 2) * (0.7 + 0.3 * Math.cos(t * Math.PI * 2));
			case 65 -> r = t + 0.06 * Math.sin(t * Math.PI * 4) * (1 - t);
			default -> r = t;
		}
		if (Double.isNaN(r)) r = t;
		return Math.max(0.0, Math.min(1.2, r));
	}

	private static double sine(double t, int m) {
		return switch (m) {
			case 0 -> 1 - Math.cos(t * Math.PI / 2);
			case 1 -> Math.sin(t * Math.PI / 2);
			default -> -(Math.cos(Math.PI * t) - 1) / 2;
		};
	}

	private static double poly(double t, int p, int m) {
		return switch (m) {
			case 0 -> Math.pow(t, p);
			case 1 -> 1 - Math.pow(1 - t, p);
			default -> t < 0.5 ? Math.pow(2, p - 1) * Math.pow(t, p) : 1 - Math.pow(-2 * t + 2, p) / 2;
		};
	}

	private static double expo(double t, int m) {
		if (t <= 0) return 0;
		if (t >= 1) return 1;
		return switch (m) {
			case 0 -> Math.pow(2, 10 * t - 10);
			case 1 -> 1 - Math.pow(2, -10 * t);
			default -> t < 0.5 ? Math.pow(2, 20 * t - 10) / 2 : (2 - Math.pow(2, -20 * t + 10)) / 2;
		};
	}

	private static double circ(double t, int m) {
		return switch (m) {
			case 0 -> 1 - Math.sqrt(1 - t * t);
			case 1 -> Math.sqrt(1 - (t - 1) * (t - 1));
			default -> t < 0.5
					? (1 - Math.sqrt(1 - Math.pow(2 * t, 2))) / 2
					: (Math.sqrt(1 - Math.pow(-2 * t + 2, 2)) + 1) / 2;
		};
	}

	private static double back(double t, int m) {
		double c1 = 1.70158, c2 = c1 * 1.525, c3 = c1 + 1;
		return switch (m) {
			case 0 -> c3 * t * t * t - c1 * t * t;
			case 1 -> 1 + c3 * Math.pow(t - 1, 3) + c1 * Math.pow(t - 1, 2);
			default -> t < 0.5
					? (Math.pow(2 * t, 2) * ((c2 + 1) * 2 * t - c2)) / 2
					: (Math.pow(2 * t - 2, 2) * ((c2 + 1) * (2 * t - 2) + c2) + 2) / 2;
		};
	}

	private static double elastic(double t, int m) {
		if (t <= 0) return 0;
		if (t >= 1) return 1;
		double c4 = (2 * Math.PI) / 3, c5 = (2 * Math.PI) / 4.5;
		return switch (m) {
			case 0 -> -Math.pow(2, 10 * t - 10) * Math.sin((t * 10 - 10.75) * c4);
			case 1 -> Math.pow(2, -10 * t) * Math.sin((t * 10 - 0.75) * c4) + 1;
			default -> t < 0.5
					? -(Math.pow(2, 20 * t - 10) * Math.sin((20 * t - 11.125) * c5)) / 2
					: (Math.pow(2, -20 * t + 10) * Math.sin((20 * t - 11.125) * c5)) / 2 + 1;
		};
	}

	private static double bounceOut(double t) {
		double n1 = 7.5625, d1 = 2.75;
		if (t < 1 / d1) return n1 * t * t;
		if (t < 2 / d1) {
			t -= 1.5 / d1;
			return n1 * t * t + 0.75;
		}
		if (t < 2.5 / d1) {
			t -= 2.25 / d1;
			return n1 * t * t + 0.9375;
		}
		t -= 2.625 / d1;
		return n1 * t * t + 0.984375;
	}

	private static double bounce(double t, int m) {
		return switch (m) {
			case 0 -> 1 - bounceOut(1 - t);
			case 1 -> bounceOut(t);
			default -> t < 0.5 ? (1 - bounceOut(1 - 2 * t)) / 2 : (1 + bounceOut(2 * t - 1)) / 2;
		};
	}
}
