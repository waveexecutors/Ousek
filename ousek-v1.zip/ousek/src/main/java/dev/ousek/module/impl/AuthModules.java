package dev.ousek.module.impl;

import dev.ousek.alt.AltManager;
import dev.ousek.module.Category;
import dev.ousek.module.Module;
import dev.ousek.module.ModuleManager;
import dev.ousek.module.Util;
import dev.ousek.setting.Setting;

import java.util.List;

/**
 * Convenience helpers for servers that use an AuthMe style login plugin.
 * They only send the password stored on your own selected alt.
 */
public final class AuthModules {
	private AuthModules() {
	}

	public static void register(List<Module> list) {
		list.add(new AutoLogin());
		list.add(new AutoRegister());
		list.add(new AuthNotify());
	}

	static boolean loginPrompt(String m) {
		String l = m.toLowerCase();
		return l.contains("/login") || l.contains("/l ") || l.contains("please login") || l.contains("please log in");
	}

	static boolean registerPrompt(String m) {
		String l = m.toLowerCase();
		return l.contains("/register") || l.contains("/reg ") || l.contains("please register");
	}

	public static class AutoLogin extends Module {
		final Setting.Num delay = num("Delay (ticks)", 20, 0, 100, 5);
		long lastSent;

		public AutoLogin() {
			super("AutoLogin", "Sends /login with your alt's password", Category.AUTH);
		}

		@Override
		public void onChat(String m) {
			if (!loginPrompt(m) || registerPrompt(m)) return;
			long now = System.currentTimeMillis();
			if (now - lastSent < 3000) return;
			String pw = AltManager.currentPassword();
			if (pw.isEmpty()) {
				Util.info("AutoLogin: set a password on your alt in the Alt Manager.");
				return;
			}
			lastSent = now;
			ModuleManager.later(delay.i(), () -> {
				if (mc.getNetworkHandler() != null) mc.getNetworkHandler().sendChatCommand("login " + pw);
			});
		}
	}

	public static class AutoRegister extends Module {
		final Setting.Num delay = num("Delay (ticks)", 20, 0, 100, 5);
		final Setting.Bool confirm = bool("Repeat password", true);
		long lastSent;

		public AutoRegister() {
			super("AutoRegister", "Sends /register with your alt's password", Category.AUTH);
		}

		@Override
		public void onChat(String m) {
			if (!registerPrompt(m)) return;
			long now = System.currentTimeMillis();
			if (now - lastSent < 3000) return;
			String pw = AltManager.currentPassword();
			if (pw.isEmpty()) {
				Util.info("AutoRegister: set a password on your alt in the Alt Manager.");
				return;
			}
			lastSent = now;
			ModuleManager.later(delay.i(), () -> {
				if (mc.getNetworkHandler() != null) {
					mc.getNetworkHandler().sendChatCommand("register " + pw + (confirm.on() ? " " + pw : ""));
				}
			});
		}
	}

	public static class AuthNotify extends Module {
		public AuthNotify() {
			super("AuthNotify", "Alerts you when a login prompt shows", Category.AUTH);
		}

		@Override
		public void onChat(String m) {
			if (loginPrompt(m)) Util.info("Login prompt detected.");
			else if (registerPrompt(m)) Util.info("Register prompt detected.");
		}
	}
}
