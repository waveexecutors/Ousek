package dev.ousek.module.impl;

import dev.ousek.module.Category;
import dev.ousek.module.Module;
import dev.ousek.setting.Setting;
import net.minecraft.client.gl.PostEffectProcessor;
import net.minecraft.client.gui.DrawContext;
import net.minecraft.client.util.ObjectAllocator;
import net.minecraft.util.Identifier;

import java.lang.reflect.Field;
import java.lang.reflect.Modifier;
import java.util.HashMap;
import java.util.Map;
import java.util.Set;

/**
 * Motion blur by blending every frame with the previous one (post effect in assets/ousek/post_effect).
 * Runs when the HUD is built, i.e. after the world and hand are drawn and before the GUI, so only the 3D scene is blurred.
 */
public class MotionBlurModule extends Module {
	public final Setting.Mode mode = mode("Mode", "Lunar", "Lunar", "Smooth", "Trail");
	public final Setting.Num strength = num("Strength %", 50, 10, 90, 10);
	public final Setting.Bool onlyMoving = bool("Only when moving", true);
	public final Setting.Num threshold = num("Move threshold", 0.3, 0.02, 5, 0.02);
	public final Setting.Num keep = num("Keep blur frames", 6, 0, 60, 1);

	private final Map<String, PostEffectProcessor> cache = new HashMap<>();
	private ObjectAllocator allocator;
	private boolean failed;
	private String error = "";
	private float lastYaw, lastPitch;
	private double lastX, lastY, lastZ;
	private boolean haveLast;
	private int still;

	public MotionBlurModule() {
		super("MotionBlur", "Frame-blend motion blur. Lunar mode = the classic Lunar Client look", Category.RENDER);
	}

	@Override
	public String suffix() {
		return failed ? "unavailable" : mode.value + " " + (int) strength.get();
	}

	@Override
	public void onEnable() {
		failed = false;
		error = "";
		haveLast = false;
		still = 0;
	}

	@Override
	public void onDisable() {
		closeAll();
	}

	private void closeAll() {
		for (PostEffectProcessor p : cache.values()) {
			try {
				p.close();
			} catch (Throwable ignored) {
			}
		}
		cache.clear();
	}

	private ObjectAllocator allocator() {
		if (allocator != null) return allocator;
		try {
			for (Field f : mc.gameRenderer.getClass().getDeclaredFields()) {
				if (!ObjectAllocator.class.isAssignableFrom(f.getType())) continue;
				f.setAccessible(true);
				Object o = Modifier.isStatic(f.getModifiers()) ? f.get(null) : f.get(mc.gameRenderer);
				if (o instanceof ObjectAllocator a) return allocator = a;
			}
		} catch (Throwable ignored) {
		}
		try {
			for (Field f : ObjectAllocator.class.getFields()) {
				if (Modifier.isStatic(f.getModifiers()) && ObjectAllocator.class.isAssignableFrom(f.getType())
						&& f.get(null) instanceof ObjectAllocator a) return allocator = a;
			}
		} catch (Throwable ignored) {
		}
		return null;
	}

	private PostEffectProcessor processor() {
		int level = Math.max(10, Math.min(90, (int) Math.round(strength.get() / 10.0) * 10));
		String name = "acid_blur_" + mode.value.toLowerCase() + "_" + level;
		PostEffectProcessor p = cache.get(name);
		if (p == null) {
			closeAll(); // only one level is kept alive
			p = mc.getShaderLoader().loadPostEffect(Identifier.of("ousek", name), Set.of(PostEffectProcessor.MAIN));
			if (p != null) cache.put(name, p);
		}
		return p;
	}

	@Override
	public void onHud(DrawContext c) {
		if (failed || mc.player == null || mc.world == null) return;
		try {
			boolean moving = true;
			if (onlyMoving.on()) {
				float yaw = mc.player.getYaw(), pitch = mc.player.getPitch();
				double x = mc.player.getX(), y = mc.player.getY(), z = mc.player.getZ();
				if (haveLast) {
					double rot = Math.abs(yaw - lastYaw) + Math.abs(pitch - lastPitch);
					double mv = Math.abs(x - lastX) + Math.abs(y - lastY) + Math.abs(z - lastZ);
					if (rot * 0.5 + mv * 20.0 > threshold.get()) still = 0;
					else still++;
				}
				lastYaw = yaw;
				lastPitch = pitch;
				lastX = x;
				lastY = y;
				lastZ = z;
				haveLast = true;
				moving = still <= keep.get();
			}
			if (!moving) return; // nothing to blend: zero cost while standing still
			ObjectAllocator a = allocator();
			PostEffectProcessor p = processor();
			if (a == null || p == null) {
				failed = true;
				error = a == null ? "no allocator" : "effect not loaded";
				System.err.println("[Acid] motion blur unavailable: " + error);
				return;
			}
			p.render(mc.getFramebuffer(), a);
		} catch (Throwable t) {
			failed = true;
			System.err.println("[Acid] motion blur failed: " + t);
			closeAll();
		}
	}
}
