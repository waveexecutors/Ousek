package dev.ousek.module.impl;

import dev.ousek.gui.Theme;
import dev.ousek.module.Category;
import dev.ousek.module.Module;
import dev.ousek.setting.Setting;

/** Settings for the Ousek logo shown in the menus and the watermark. */
public class LogoModule extends Module {
	public final Setting.Mode text = mode("Text", "OUSEK", "OUSEK", "Ousek", "ousek", "OUSEK CLIENT", "OUSEK.CC", "O U S E K");
	public final Setting.Mode mark = mode("Icon", "None", "None", "Skull", "Swords", "Globe", "Plus", "Wrench", "Dice", "Bars", "Pirate");
	public final Setting.Mode colorMode = mode("Color", "Theme", "Theme", "Gradient", "Rainbow", "White");
	public final Setting.Num size = num("Size", 1.0, 0.6, 2.5, 0.1);
	public final Setting.Num spacing = num("Letter spacing", 1, 0, 6, 1);
	public final Setting.Bool bold = bool("Bold", true);
	public final Setting.Bool shadow = bool("Shadow", true);
	public final Setting.Bool showV1 = bool("Show v1", true);

	public LogoModule() {
		super("Logo", "Customise the Ousek logo (text, icon, colour, size)", Category.CLIENT);
		enabled = true;
	}

	public String text() {
		return text.value;
	}

	/** Glyph in the assetsio icon font for the chosen icon ("" = none). */
	public String mark() {
		return switch (mark.value) {
			case "Skull" -> "B";
			case "Swords" -> "C";
			case "Globe" -> "W";
			case "Plus" -> "P";
			case "Wrench" -> "U";
			case "Dice" -> "M";
			case "Bars" -> "O";
			case "Pirate" -> "R";
			default -> "";
		};
	}

	public int color(int i, int n, int acc) {
		return switch (colorMode.value) {
			case "Gradient" -> Theme.lerp(acc, 0xFFFFFFFF, n <= 1 ? 0f : 0.65f * i / (n - 1));
			case "Rainbow" -> Theme.rainbow(i * 3);
			case "White" -> 0xFFFFFFFF;
			default -> acc;
		};
	}
}
