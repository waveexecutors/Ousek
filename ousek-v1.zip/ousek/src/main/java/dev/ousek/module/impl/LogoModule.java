package dev.ousek.module.impl;

import dev.ousek.module.Category;
import dev.ousek.module.Module;
import dev.ousek.setting.Setting;

/** Settings for the Acid logo (menus and watermark). */
public class LogoModule extends Module {
	public final Setting.Num size = num("Size", 1.0, 0.6, 2.5, 0.1);
	public final Setting.Bool tint = bool("Tint with theme", false);

	public LogoModule() {
		super("Logo", "Size and colour of the Acid logo", Category.CLIENT);
		enabled = true;
	}
}
