package dev.ousek.module.impl;

import dev.ousek.gui.ClickGui;
import dev.ousek.gui.Theme;
import dev.ousek.module.Category;
import dev.ousek.module.Module;
import dev.ousek.setting.Setting;
import org.lwjgl.glfw.GLFW;

public class ClickGuiModule extends Module {
	public final Setting.Mode theme = mode("Theme", "Teal", Theme.NAMES);
	public final Setting.Num red = num("Custom red", 46, 0, 255, 1);
	public final Setting.Num green = num("Custom green", 230, 0, 255, 1);
	public final Setting.Num blue = num("Custom blue", 166, 0, 255, 1);
	public final Setting.Bool notifications = bool("Notifications", true);

	public ClickGuiModule() {
		super("ClickGUI", "Opens the menu (default: Right Shift)", Category.CLIENT, GLFW.GLFW_KEY_RIGHT_SHIFT);
	}

	@Override
	public void onKey() {
		if (mc.currentScreen == null) mc.setScreen(new ClickGui());
	}

	@Override
	public void toggle() {
		// the menu itself is not a toggle
	}
}
