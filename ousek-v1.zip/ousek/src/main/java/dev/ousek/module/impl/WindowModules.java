package dev.ousek.module.impl;

import dev.ousek.gui.EmoteScreen;
import dev.ousek.gui.MusicScreen;
import dev.ousek.module.Category;
import dev.ousek.module.Module;
import dev.ousek.module.ModuleManager;
import dev.ousek.music.MusicPlayer;
import dev.ousek.setting.Setting;

import java.util.List;

/** Modules that open a window instead of toggling something. Their settings are saved in the config. */
public final class WindowModules {
	private WindowModules() {
	}

	public static void register(List<Module> list) {
		list.add(new Emotes());
		list.add(new Music());
		list.add(new WalkEffects());
		list.add(new Wardrobe());
	}

	public static Emotes emotes() {
		return ModuleManager.get(Emotes.class);
	}

	public static Wardrobe wardrobe() {
		return ModuleManager.get(Wardrobe.class);
	}

	public static Music music() {
		return ModuleManager.get(Music.class);
	}

	public static class Emotes extends Module {
		public final Setting.Bool loop = bool("Loop", true);
		public final Setting.Bool whileMoving = bool("Play while moving", true);
		public final Setting.Bool thirdPerson = bool("Auto third person", true);
		public final Setting.Num speed = num("Speed", 1.0, 0.25, 2.0, 0.05);

		public Emotes() {
			super("Emotes", "Window to play JSON emotes on your 3D character", Category.CLIENT);
		}

		@Override
		public void onKey() {
			if (mc.currentScreen == null) mc.setScreen(new EmoteScreen(null));
		}

		@Override
		public void toggle() {
			mc.setScreen(new EmoteScreen(mc.currentScreen));
		}
	}

	public static class Music extends Module {
		public final Setting.Num volume = num("Volume", 50, 0, 100, 1);
		public final Setting.Mode source = mode("Source", "Auto", "Auto", "Audius (full songs)", "Deezer (30s previews)");

		public Music() {
			super("Music", "Music player window (free APIs, no key)", Category.CLIENT);
		}

		@Override
		public String suffix() {
			return MusicPlayer.current == null ? null : MusicPlayer.current.title();
		}

		@Override
		public void onKey() {
			if (mc.currentScreen == null) mc.setScreen(new MusicScreen(null));
		}

		@Override
		public void toggle() {
			mc.setScreen(new MusicScreen(mc.currentScreen));
		}
	}

	/** Particle trails while you walk. */
	public static class WalkEffects extends Module {
		final Setting.Mode effect = mode("Effect", "Flames", "Flames", "Hearts", "Notes", "Snow", "Magic");
		final Setting.Num amount = num("Amount", 2, 1, 6, 1);
		final Setting.Bool onlyMoving = bool("Only while moving", true);
		final java.util.Random rng = new java.util.Random();

		public WalkEffects() {
			super("WalkEffects", "Particle trail behind you (5 effects)", Category.RENDER);
		}

		@Override
		public String suffix() {
			return effect.value;
		}

		@Override
		public void onTick() {
			if (mc.player == null || mc.world == null) return;
			if (onlyMoving.on() && mc.player.getVelocity().horizontalLengthSquared() < 0.0004) return;
			net.minecraft.particle.ParticleEffect p = switch (effect.value) {
				case "Hearts" -> net.minecraft.particle.ParticleTypes.HEART;
				case "Notes" -> net.minecraft.particle.ParticleTypes.NOTE;
				case "Snow" -> net.minecraft.particle.ParticleTypes.SNOWFLAKE;
				case "Magic" -> net.minecraft.particle.ParticleTypes.ENCHANT;
				default -> net.minecraft.particle.ParticleTypes.FLAME;
			};
			for (int i = 0; i < amount.i(); i++) {
				double x = mc.player.getX() + (rng.nextDouble() - 0.5) * 0.5;
				double y = mc.player.getY() + 0.1 + rng.nextDouble() * 0.2;
				double z = mc.player.getZ() + (rng.nextDouble() - 0.5) * 0.5;
				try {
					mc.particleManager.addParticle(p, x, y, z, 0.0, 0.02, 0.0);
				} catch (Throwable ignored) {
				}
			}
		}
	}

	/** Wearable 3D accessories (wings, masks, capes, bandanas, halos). Selections are saved as settings. */
	public static class Wardrobe extends Module {
		public final Setting.Mode wings = mode("Wings", "None", dev.ousek.accessory.Catalog.names(dev.ousek.accessory.Catalog.Cat.WINGS));
		public final Setting.Mode masks = mode("Masks", "None", dev.ousek.accessory.Catalog.names(dev.ousek.accessory.Catalog.Cat.MASKS));
		public final Setting.Mode capes = mode("Capes", "None", dev.ousek.accessory.Catalog.names(dev.ousek.accessory.Catalog.Cat.CAPES));
		public final Setting.Mode bandanas = mode("Bandanas", "None", dev.ousek.accessory.Catalog.names(dev.ousek.accessory.Catalog.Cat.BANDANAS));
		public final Setting.Mode halos = mode("Halos", "None", dev.ousek.accessory.Catalog.names(dev.ousek.accessory.Catalog.Cat.HALOS));

		public final Setting.Num wingHeight = num("Wing height", 3.0, -10, 16, 0.25);
		public final Setting.Num wingBack = num("Wing distance back", 2.8, 0, 12, 0.25);
		public final Setting.Num wingSpread = num("Wing spread (gap)", 2.0, 0, 10, 0.25);
		public final Setting.Num wingAngle = num("Wing angle", 0, -40, 40, 1);
		public final Setting.Num bandanaHeight = num("Bandana height", 0, -3, 3, 0.25);
		public final Setting.Num flapSpeed = num("Flap speed", 1.0, 0, 3, 0.05);

		public Wardrobe() {
			super("Accessories", "Window with 68 wearable 3D wings, masks, capes, bandanas and halos", Category.CLIENT);
		}

		public Setting.Mode mode(dev.ousek.accessory.Catalog.Cat c) {
			return switch (c) {
				case WINGS -> wings;
				case MASKS -> masks;
				case CAPES -> capes;
				case BANDANAS -> bandanas;
				case HALOS -> halos;
			};
		}

		/** The equipped item of a category, or null. */
		public dev.ousek.accessory.Catalog.Item equipped(dev.ousek.accessory.Catalog.Cat c) {
			int i = mode(c).index() - 1;
			java.util.List<dev.ousek.accessory.Catalog.Item> l = dev.ousek.accessory.Catalog.of(c);
			return i < 0 || i >= l.size() ? null : l.get(i);
		}

		@Override
		public void onKey() {
			if (mc.currentScreen == null) mc.setScreen(new dev.ousek.gui.AccessoryScreen(null));
		}

		@Override
		public void toggle() {
			mc.setScreen(new dev.ousek.gui.AccessoryScreen(mc.currentScreen));
		}
	}
}
