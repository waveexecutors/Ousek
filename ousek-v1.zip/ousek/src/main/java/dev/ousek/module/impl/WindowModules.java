package dev.ousek.module.impl;

import dev.ousek.gui.EmoteScreen;
import dev.ousek.gui.MusicScreen;
import dev.ousek.module.Category;
import dev.ousek.module.Module;
import dev.ousek.module.ModuleManager;
import dev.ousek.music.MusicPlayer;
import dev.ousek.setting.Setting;

import java.util.List;

/** Modules that open a window instead of toggling something. Their settings are saved in the config. */
public final class WindowModules {
	private WindowModules() {
	}

	public static void register(List<Module> list) {
		list.add(new Emotes());
		list.add(new Music());
		list.add(new WalkEffects());
	}

	public static Emotes emotes() {
		return ModuleManager.get(Emotes.class);
	}

	public static Music music() {
		return ModuleManager.get(Music.class);
	}

	public static class Emotes extends Module {
		public final Setting.Bool loop = bool("Loop", true);
		public final Setting.Bool whileMoving = bool("Play while moving", true);
		public final Setting.Bool thirdPerson = bool("Auto third person", true);
		public final Setting.Num speed = num("Speed", 1.0, 0.25, 2.0, 0.05);

		public Emotes() {
			super("Emotes", "Window to play JSON emotes on your 3D character", Category.CLIENT);
		}

		@Override
		public void onKey() {
			if (mc.currentScreen == null) mc.setScreen(new EmoteScreen(null));
		}

		@Override
		public void toggle() {
			mc.setScreen(new EmoteScreen(mc.currentScreen));
		}
	}

	public static class Music extends Module {
		public final Setting.Num volume = num("Volume", 50, 0, 100, 1);
		public final Setting.Mode source = mode("Source", "Auto", "Auto", "Audius (full songs)", "Deezer (30s previews)");

		public Music() {
			super("Music", "Music player window (free APIs, no key)", Category.CLIENT);
		}

		@Override
		public String suffix() {
			return MusicPlayer.current == null ? null : MusicPlayer.current.title();
		}

		@Override
		public void onKey() {
			if (mc.currentScreen == null) mc.setScreen(new MusicScreen(null));
		}

		@Override
		public void toggle() {
			mc.setScreen(new MusicScreen(mc.currentScreen));
		}
	}

	/** Particle trails while you walk. */
	public static class WalkEffects extends Module {
		final Setting.Mode effect = mode("Effect", "Flames", "Flames", "Hearts", "Notes", "Snow", "Magic");
		final Setting.Num amount = num("Amount", 2, 1, 6, 1);
		final Setting.Bool onlyMoving = bool("Only while moving", true);
		final java.util.Random rng = new java.util.Random();

		public WalkEffects() {
			super("WalkEffects", "Particle trail behind you (5 effects)", Category.RENDER);
		}

		@Override
		public String suffix() {
			return effect.value;
		}

		@Override
		public void onTick() {
			if (mc.player == null || mc.world == null) return;
			if (onlyMoving.on() && mc.player.getVelocity().horizontalLengthSquared() < 0.0004) return;
			net.minecraft.particle.ParticleEffect p = switch (effect.value) {
				case "Hearts" -> net.minecraft.particle.ParticleTypes.HEART;
				case "Notes" -> net.minecraft.particle.ParticleTypes.NOTE;
				case "Snow" -> net.minecraft.particle.ParticleTypes.SNOWFLAKE;
				case "Magic" -> net.minecraft.particle.ParticleTypes.ENCHANT;
				default -> net.minecraft.particle.ParticleTypes.FLAME;
			};
			for (int i = 0; i < amount.i(); i++) {
				double x = mc.player.getX() + (rng.nextDouble() - 0.5) * 0.5;
				double y = mc.player.getY() + 0.1 + rng.nextDouble() * 0.2;
				double z = mc.player.getZ() + (rng.nextDouble() - 0.5) * 0.5;
				try {
					mc.particleManager.addParticle(p, x, y, z, 0.0, 0.02, 0.0);
				} catch (Throwable ignored) {
				}
			}
		}
	}
}
