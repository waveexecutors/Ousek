package dev.ousek.module.impl;

import dev.ousek.gui.EmoteScreen;
import dev.ousek.gui.MusicScreen;
import dev.ousek.module.Category;
import dev.ousek.module.Module;
import dev.ousek.module.ModuleManager;
import dev.ousek.music.MusicPlayer;
import dev.ousek.setting.Setting;

import java.util.List;

/** Modules that open a window instead of toggling something. Their settings are saved in the config. */
public final class WindowModules {
	private WindowModules() {
	}

	public static void register(List<Module> list) {
		list.add(new Emotes());
		list.add(new Music());
	}

	public static Emotes emotes() {
		return ModuleManager.get(Emotes.class);
	}

	public static Music music() {
		return ModuleManager.get(Music.class);
	}

	public static class Emotes extends Module {
		public final Setting.Bool loop = bool("Loop", true);
		public final Setting.Bool whileMoving = bool("Play while moving", true);
		public final Setting.Bool thirdPerson = bool("Auto third person", true);
		public final Setting.Num speed = num("Speed", 1.0, 0.25, 2.0, 0.05);

		public Emotes() {
			super("Emotes", "Window to play JSON emotes on your 3D character", Category.CLIENT);
		}

		@Override
		public void onKey() {
			if (mc.currentScreen == null) mc.setScreen(new EmoteScreen(null));
		}

		@Override
		public void toggle() {
			mc.setScreen(new EmoteScreen(mc.currentScreen));
		}
	}

	public static class Music extends Module {
		public final Setting.Num volume = num("Volume", 50, 0, 100, 1);
		public final Setting.Mode source = mode("Source", "Auto", "Auto", "Audius (full songs)", "Deezer (30s previews)");

		public Music() {
			super("Music", "Music player window (free APIs, no key)", Category.CLIENT);
		}

		@Override
		public String suffix() {
			return MusicPlayer.current == null ? null : MusicPlayer.current.title();
		}

		@Override
		public void onKey() {
			if (mc.currentScreen == null) mc.setScreen(new MusicScreen(null));
		}

		@Override
		public void toggle() {
			mc.setScreen(new MusicScreen(mc.currentScreen));
		}
	}
}
