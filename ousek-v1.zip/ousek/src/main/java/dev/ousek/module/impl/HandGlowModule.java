package dev.ousek.module.impl;

import dev.ousek.gui.Theme;
import dev.ousek.module.Category;
import dev.ousek.module.Module;
import dev.ousek.setting.Setting;
import net.minecraft.client.gl.PostEffectProcessor;
import net.minecraft.client.gui.DrawContext;
import net.minecraft.client.util.ObjectAllocator;
import net.minecraft.util.Identifier;

import java.lang.reflect.Field;
import java.lang.reflect.Modifier;
import java.util.HashMap;
import java.util.Map;
import java.util.Set;

/**
 * Glow / outline around your first-person hand and held item (main hand and offhand).
 * The game clears the depth buffer before drawing the hand, so the depth buffer is a perfect mask of the hand;
 * a post effect (assets/ousek/post_effect/acid_hg_*) draws the glow around that mask.
 */
public class HandGlowModule extends Module {
	public final Setting.Mode style = mode("Style", "Glow", "Glow", "Outline", "Mask (debug)");
	public final Setting.Mode colorMode = mode("Color", "Theme", "Theme", "Custom", "White", "Rainbow");
	public final Setting.Num hue = num("Custom hue", 120, 0, 345, 15);
	public final Setting.Mode size = mode("Size", "Medium", "Thin", "Medium", "Wide", "Huge");
	public final Setting.Mode intensity = mode("Intensity", "Strong", "Soft", "Strong");
	public final Setting.Bool pulse = bool("Pulse", false);
	public final Setting.Num pulseSpeed = num("Pulse speed", 1.5, 0.3, 5, 0.1);
	public final Setting.Num rainbowSpeed = num("Rainbow speed", 1.0, 0.2, 5, 0.1);

	private final Map<String, PostEffectProcessor> cache = new HashMap<>();
	private ObjectAllocator allocator;
	private boolean failed;
	private int fails, lastW, lastH;
	private long retryAt;

	public HandGlowModule() {
		super("HandGlow", "Glow around your hand and held items (offhand too)", Category.RENDER);
	}

	@Override
	public String suffix() {
		return failed ? "unavailable" : style.value;
	}

	@Override
	public void onEnable() {
		failed = false;
	}

	@Override
	public void onDisable() {
		closeAll();
	}

	private void closeAll() {
		for (PostEffectProcessor p : cache.values()) {
			try {
				p.close();
			} catch (Throwable ignored) {
			}
		}
		cache.clear();
	}

	private ObjectAllocator allocator() {
		if (allocator != null) return allocator;
		try {
			for (Field f : mc.gameRenderer.getClass().getDeclaredFields()) {
				if (!ObjectAllocator.class.isAssignableFrom(f.getType())) continue;
				f.setAccessible(true);
				Object o = Modifier.isStatic(f.getModifiers()) ? f.get(null) : f.get(mc.gameRenderer);
				if (o instanceof ObjectAllocator a) return allocator = a;
			}
		} catch (Throwable ignored) {
		}
		try {
			for (Field f : ObjectAllocator.class.getFields()) {
				if (Modifier.isStatic(f.getModifiers()) && ObjectAllocator.class.isAssignableFrom(f.getType())
						&& f.get(null) instanceof ObjectAllocator a) return allocator = a;
			}
		} catch (Throwable ignored) {
		}
		return null;
	}

	/** 0..23 hue steps, or -1 for white. */
	private int hueIndex() {
		switch (colorMode.value) {
			case "White":
				return -1;
			case "Custom":
				return (int) Math.round(hue.get() / 15.0) % 24;
			case "Rainbow":
				return (int) ((System.currentTimeMillis() / 1000.0 * rainbowSpeed.get() * 6.0)) % 24;
			default: {
				int c = Theme.accent();
				float r = ((c >> 16) & 255) / 255f, g = ((c >> 8) & 255) / 255f, b = (c & 255) / 255f;
				float max = Math.max(r, Math.max(g, b)), min = Math.min(r, Math.min(g, b));
				if (max - min < 0.12f) return -1;
				float h;
				if (max == r) h = ((g - b) / (max - min)) % 6f;
				else if (max == g) h = (b - r) / (max - min) + 2f;
				else h = (r - g) / (max - min) + 4f;
				h = (h * 60f + 360f) % 360f;
				return Math.round(h / 15f) % 24;
			}
		}
	}

	private PostEffectProcessor processor() {
		int hi = hueIndex();
		int rad = switch (size.value) {
			case "Thin" -> 1;
			case "Wide" -> 3;
			case "Huge" -> 5;
			default -> 2;
		};
		int in = intensity.value.equals("Soft") ? 60 : 100;
		if (pulse.on()) {
			double s = 0.5 + 0.5 * Math.sin(System.currentTimeMillis() / 1000.0 * pulseSpeed.get() * Math.PI * 2);
			in = s > 0.5 ? 100 : 60;
		}
		if (style.value.startsWith("Mask")) {
			PostEffectProcessor m = cache.get("mask");
			if (m == null) {
				m = mc.getShaderLoader().loadPostEffect(Identifier.of("ousek", "acid_hg_mask_w_1_100"), Set.of(PostEffectProcessor.MAIN));
				if (m != null) cache.put("mask", m);
			}
			return m;
		}
		String name = "acid_hg_" + style.value.toLowerCase() + "_" + (hi < 0 ? "w" : String.valueOf(hi)) + "_" + rad + "_" + in;
		PostEffectProcessor p = cache.get(name);
		if (p == null) {
			if (cache.size() > 40) closeAll();
			p = mc.getShaderLoader().loadPostEffect(Identifier.of("ousek", name), Set.of(PostEffectProcessor.MAIN));
			if (p != null) cache.put(name, p);
		}
		return p;
	}

	@Override
	public void onHud(DrawContext c) {
		if (failed || mc.player == null || mc.world == null || System.currentTimeMillis() < retryAt) return;
		if (!mc.options.getPerspective().isFirstPerson()) return;
		try {
			int fw = mc.getFramebuffer().textureWidth, fh = mc.getFramebuffer().textureHeight;
			if (fw != lastW || fh != lastH) {
				closeAll();
				lastW = fw;
				lastH = fh;
			}
			ObjectAllocator a = allocator();
			PostEffectProcessor p = processor();
			if (a == null || p == null) throw new IllegalStateException(a == null ? "no allocator" : "effect not loaded");
			p.render(mc.getFramebuffer(), a);
			fails = 0;
		} catch (Throwable t) {
			closeAll();
			fails++;
			retryAt = System.currentTimeMillis() + 1500;
			if (fails == 1 || fails == 4) dev.ousek.module.Util.info("HandGlow: " + t + " (retrying)");
			if (fails >= 6) failed = true;
		}
	}
}
