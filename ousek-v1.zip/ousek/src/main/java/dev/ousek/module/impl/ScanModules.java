package dev.ousek.module.impl;

import dev.ousek.module.Category;
import dev.ousek.module.Module;
import dev.ousek.setting.Setting;
import net.minecraft.block.Block;
import net.minecraft.block.Blocks;
import net.minecraft.block.entity.AbstractFurnaceBlockEntity;
import net.minecraft.block.entity.BarrelBlockEntity;
import net.minecraft.block.entity.BeaconBlockEntity;
import net.minecraft.block.entity.BedBlockEntity;
import net.minecraft.block.entity.BlockEntity;
import net.minecraft.block.entity.BrewingStandBlockEntity;
import net.minecraft.block.entity.ChestBlockEntity;
import net.minecraft.block.entity.DispenserBlockEntity;
import net.minecraft.block.entity.EnderChestBlockEntity;
import net.minecraft.block.entity.HopperBlockEntity;
import net.minecraft.block.entity.ShulkerBoxBlockEntity;
import net.minecraft.block.entity.SignBlockEntity;
import net.minecraft.client.gui.DrawContext;
import net.minecraft.client.gui.PlayerSkinDrawer;
import net.minecraft.client.network.AbstractClientPlayerEntity;
import net.minecraft.client.sound.PositionedSoundInstance;
import net.minecraft.entity.Entity;
import net.minecraft.entity.player.PlayerEntity;
import net.minecraft.sound.SoundEvents;
import net.minecraft.util.math.BlockPos;
import net.minecraft.util.math.Vec3d;
import net.minecraft.world.chunk.WorldChunk;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

/** Base Finder (arrows + text to player bases) and Admin Alert (warden sound + face when staff is near). */
public final class ScanModules {
	private ScanModules() {
	}

	public static void register(List<Module> list) {
		list.add(new BaseFinder());
		list.add(new AdminAlert());
		list.add(new MotionBlurModule());
		list.add(new HandGlowModule());
		list.add(new ScreenFXModule());
	}

	/** Projects a world position to scaled GUI coordinates; returns {x, y, depth, rightComponent, upComponent}. */
	static double[] project(DrawContext c, net.minecraft.client.MinecraftClient mc, Vec3d eye, double x, double y, double z) {
		double yaw = Math.toRadians(mc.player.getYaw()), pitch = Math.toRadians(mc.player.getPitch());
		double cy = Math.cos(yaw), sy = Math.sin(yaw), cp = Math.cos(pitch), sp = Math.sin(pitch);
		double fx = -sy * cp, fy = -sp, fz = cy * cp;
		double rx = -cy, ry = 0, rz = -sy;
		double ux = ry * fz - rz * fy, uy = rz * fx - rx * fz, uz = rx * fy - ry * fx;
		double dx = x - eye.x, dy = y - eye.y, dz = z - eye.z;
		double depth = dx * fx + dy * fy + dz * fz, right = dx * rx + dy * ry + dz * rz, up = dx * ux + dy * uy + dz * uz;
		double w = c.getScaledWindowWidth(), h = c.getScaledWindowHeight();
		double tan = Math.tan(Math.toRadians(mc.options.getFov().getValue()) / 2.0);
		double sx, sy2;
		if (depth > 0.05) {
			sx = w / 2 * (1 + right / (depth * tan * (w / h)));
			sy2 = h / 2 * (1 - up / (depth * tan));
		} else {
			sx = Double.NaN;
			sy2 = Double.NaN;
		}
		return new double[]{sx, sy2, depth, right, up};
	}

	// ------------------------------------------------------------------ Base finder

	public static class BaseFinder extends Module {
		private record Base(double x, double y, double z, int score, int count) {
		}

		public final Setting.Num range = num("Range (blocks)", 1500, 64, 5000, 32);
		public final Setting.Num minScore = num("Min storage score", 4, 1, 40, 1);
		public final Setting.Num maxShown = num("Max bases shown", 8, 1, 20, 1);
		public final Setting.Bool showDistance = bool("Show distance", true);
		private volatile List<Base> bases = new ArrayList<>();
		private int tick;

		public BaseFinder() {
			super("BaseFinder", "Finds player bases (chests, furnaces, beds...) in loaded chunks and points arrows at them", Category.RENDER);
		}

		private static final Block[] NATURAL = {Blocks.MOSSY_COBBLESTONE, Blocks.COBWEB, Blocks.RAIL, Blocks.POWERED_RAIL,
				Blocks.SCULK, Blocks.SCULK_CATALYST, Blocks.SCULK_SHRIEKER, Blocks.DEEPSLATE_BRICKS, Blocks.DEEPSLATE_TILES,
				Blocks.SOUL_LANTERN, Blocks.TUFF_BRICKS, Blocks.CHISELED_TUFF, Blocks.SPAWNER, Blocks.TRIAL_SPAWNER, Blocks.VAULT,
				Blocks.CRACKED_STONE_BRICKS, Blocks.MOSSY_STONE_BRICKS};

		public final Setting.Bool ignoreStructures = bool("Ignore caves & structures", true);
		public final Setting.Bool ignoreVillages = bool("Ignore villages", true);

		/** True when the block entity sits in generated terrain (mineshaft, dungeon, ancient city, trial chamber...). */
		private boolean natural(BlockPos p) {
			for (int dx = -2; dx <= 2; dx++) {
				for (int dy = -2; dy <= 2; dy++) {
					for (int dz = -2; dz <= 2; dz++) {
						Block b = mc.world.getBlockState(p.add(dx, dy, dz)).getBlock();
						for (Block n : NATURAL) if (b == n) return true;
					}
				}
			}
			return false;
		}

		private static int weight(BlockEntity be) {
			if (be instanceof BeaconBlockEntity) return 6;
			if (be instanceof ShulkerBoxBlockEntity) return 2;
			if (be instanceof ChestBlockEntity || be instanceof BarrelBlockEntity || be instanceof EnderChestBlockEntity
					|| be instanceof AbstractFurnaceBlockEntity || be instanceof HopperBlockEntity
					|| be instanceof DispenserBlockEntity || be instanceof BedBlockEntity
					|| be instanceof BrewingStandBlockEntity || be instanceof SignBlockEntity) return 1;
			return 0;
		}

		private static int kind(BlockEntity be) {
			if (be instanceof ChestBlockEntity || be instanceof EnderChestBlockEntity) return 1;
			if (be instanceof BarrelBlockEntity) return 2;
			if (be instanceof ShulkerBoxBlockEntity) return 3;
			if (be instanceof AbstractFurnaceBlockEntity) return 4;
			if (be instanceof HopperBlockEntity || be instanceof DispenserBlockEntity) return 5;
			if (be instanceof BedBlockEntity) return 6;
			if (be instanceof SignBlockEntity) return 7;
			if (be instanceof BrewingStandBlockEntity) return 8;
			return 9;
		}

		@Override
		public void onTick() {
			if (mc.world == null || mc.player == null || ++tick % 40 != 0) return;
			try {
				int r = Math.max(2, mc.options.getViewDistance().getValue());
				int pcx = mc.player.getBlockPos().getX() >> 4, pcz = mc.player.getBlockPos().getZ() >> 4;
				Map<Long, double[]> cells = new HashMap<>(); // sx, sy, sz, score, count, kinds bitmask
				List<double[]> villagers = new ArrayList<>();
				if (ignoreVillages.on()) {
					for (Entity e : mc.world.getEntities()) {
						if (e instanceof net.minecraft.entity.passive.VillagerEntity || e instanceof net.minecraft.entity.passive.WanderingTraderEntity)
							villagers.add(new double[]{e.getX(), e.getZ()});
					}
				}
				int checked = 0;
				for (int cx = pcx - r; cx <= pcx + r; cx++) {
					for (int cz = pcz - r; cz <= pcz + r; cz++) {
						WorldChunk ch = mc.world.getChunk(cx, cz);
						if (ch == null) continue;
						for (Map.Entry<BlockPos, BlockEntity> en : ch.getBlockEntities().entrySet()) {
							int wgt = weight(en.getValue());
							if (wgt == 0) continue;
							BlockPos p = en.getKey();
							if (ignoreStructures.on() && ++checked < 600 && natural(p)) continue;
							long key = (((long) (p.getX() >> 5)) << 32) ^ ((p.getZ() >> 5) & 0xFFFFFFFFL);
							double[] a = cells.computeIfAbsent(key, k -> new double[6]);
							a[5] = (long) a[5] | (1L << Math.min(20, kind(en.getValue())));
							a[0] += p.getX();
							a[1] += p.getY();
							a[2] += p.getZ();
							a[3] += wgt;
							a[4] += 1;
						}
					}
				}
				List<Base> out = new ArrayList<>();
				for (double[] a : cells.values()) {
					if (a[3] < minScore.get()) continue;
					if (Long.bitCount((long) a[5]) < 2 && a[4] < minScore.get() * 2) continue; // one lonely chest type is not a base
					double cxm = a[0] / a[4], czm = a[2] / a[4];
					boolean village = false;
					for (double[] v : villagers) {
						if ((v[0] - cxm) * (v[0] - cxm) + (v[1] - czm) * (v[1] - czm) < 48 * 48) {
							village = true;
							break;
						}
					}
					if (village) continue;
					out.add(new Base(a[0] / a[4] + 0.5, a[1] / a[4] + 1.5, a[2] / a[4] + 0.5, (int) a[3], (int) a[4]));
				}
				bases = out;
			} catch (Throwable ignored) {
			}
		}

		@Override
		public void onDisable() {
			bases = new ArrayList<>();
		}

		@Override
		public String suffix() {
			return String.valueOf(bases.size());
		}

		@Override
		public void onHud(DrawContext c) {
			if (mc.player == null) return;
			Vec3d eye = mc.player.getEyePos();
			List<Base> list = new ArrayList<>();
			double max = range.get();
			for (Base b : bases) {
				double d = Math.sqrt((b.x - eye.x) * (b.x - eye.x) + (b.z - eye.z) * (b.z - eye.z));
				if (d <= max) list.add(b);
			}
			list.sort((p, q) -> Double.compare(dist(p, eye), dist(q, eye)));
			int shown = (int) maxShown.get();
			int w = c.getScaledWindowWidth(), h = c.getScaledWindowHeight();
			for (int i = 0; i < list.size() && i < shown; i++) {
				Base b = list.get(i);
				double d = dist(b, eye);
				String t = "BASE  " + b.count + " blocks" + (showDistance.on() ? "  " + (int) d + "m" : "");
				double[] p = project(c, mc, eye, b.x, b.y, b.z);
				int tw = mc.textRenderer.getWidth(t);
				if (!Double.isNaN(p[0]) && p[0] > 8 && p[0] < w - 8 && p[1] > 8 && p[1] < h - 8) {
					int x = (int) p[0], y = (int) p[1];
					c.fill(x - tw / 2 - 3, y - 22, x + tw / 2 + 3, y - 10, 0xAA101014);
					c.drawText(mc.textRenderer, t, x - tw / 2, y - 20, 0xFFFFD34D, false);
					for (int k = 0; k < 6; k++) c.fill(x - 6 + k, y - 9 + k, x + 6 - k, y - 8 + k, 0xFFFFD34D); // arrow pointing down
				} else {
					// off-screen: stick to the screen edge in the right direction
					double rx = p[3], ru = p[4];
					if (p[2] <= 0.05) rx = rx == 0 ? 1 : rx * 1000;
					double len = Math.max(1e-6, Math.sqrt(rx * rx + ru * ru));
					double ex = w / 2.0 + rx / len * (w / 2.0 - 30), ey = h / 2.0 - ru / len * (h / 2.0 - 30);
					String a = Math.abs(rx) > Math.abs(ru) ? (rx > 0 ? ">" : "<") : (ru > 0 ? "^" : "v");
					c.drawText(mc.textRenderer, a, (int) ex - 3, (int) ey - 4, 0xFFFFD34D, true);
					String s2 = (int) d + "m";
					c.drawText(mc.textRenderer, s2, (int) ex - mc.textRenderer.getWidth(s2) / 2, (int) ey + 6, 0xFFFFD34D, false);
				}
			}
		}

		private static double dist(Base b, Vec3d e) {
			return Math.sqrt((b.x - e.x) * (b.x - e.x) + (b.y - e.y) * (b.y - e.y) + (b.z - e.z) * (b.z - e.z));
		}
	}

	// ------------------------------------------------------------------ Admin alert

	public static class AdminAlert extends Module {
		public final Setting.Num range = num("Range (blocks)", 96, 8, 256, 4);
		public final Setting.Bool tagNames = bool("Staff tags (admin/mod/owner...)", true);
		public final Setting.Bool notInTab = bool("Not in tab list (vanished)", true);
		public final Setting.Bool spectators = bool("Spectator mode", true);
		public final Setting.Bool invisible = bool("Invisible players", true);
		public final Setting.Num showSeconds = num("Show seconds", 5, 2, 15, 1);
		private final Map<java.util.UUID, Long> lastAlert = new HashMap<>();
		private AbstractClientPlayerEntity shown;
		private String reason = "";
		private long shownAt;

		public AdminAlert() {
			super("AdminAlert", "Warden sound + name and face in the middle when an admin / vanished player is near", Category.PLAYER);
		}

		private String why(AbstractClientPlayerEntity p) {
			var nh = mc.getNetworkHandler();
			var entry = nh == null ? null : nh.getPlayerListEntry(p.getUuid());
			if (spectators.on() && entry != null && entry.getGameMode() == net.minecraft.world.GameMode.SPECTATOR) return "Spectator";
			if (notInTab.on() && entry == null) return "Vanished";
			if (invisible.on() && p.isInvisible()) return "Invisible";
			if (tagNames.on()) {
				String n = p.getDisplayName() == null ? "" : p.getDisplayName().getString().toLowerCase();
				for (String k : new String[]{"admin", "owner", "mod", "staff", "helper", "dev", "manager", "[sr", "founder"}) {
					if (n.contains(k)) return "Staff";
				}
			}
			return null;
		}

		@Override
		public void onTick() {
			if (mc.world == null || mc.player == null) return;
			long now = System.currentTimeMillis();
			double r2 = range.get() * range.get();
			for (PlayerEntity pe : mc.world.getPlayers()) {
				if (pe == mc.player || !(pe instanceof AbstractClientPlayerEntity p)) continue;
				if (p.squaredDistanceTo(mc.player) > r2) continue;
				String w = why(p);
				if (w == null) continue;
				Long last = lastAlert.get(p.getUuid());
				if (last != null && now - last < 30_000L) continue;
				lastAlert.put(p.getUuid(), now);
				shown = p;
				reason = w;
				shownAt = now;
				try {
					mc.getSoundManager().play(new PositionedSoundInstance(SoundEvents.ENTITY_WARDEN_NEARBY_CLOSEST,
							net.minecraft.sound.SoundCategory.MASTER, 1.0f, 1.0f, mc.player.getRandom(),
							mc.player.getX(), mc.player.getY(), mc.player.getZ()));
				} catch (Throwable ignored) {
				}
			}
		}

		/** Matches the skin accessor and the drawer by their types (method names are obfuscated at runtime). */
		private static void drawFace(DrawContext c, AbstractClientPlayerEntity p, int x, int y, int size) throws Exception {
			for (java.lang.reflect.Method d : PlayerSkinDrawer.class.getMethods()) {
				Class<?>[] t = d.getParameterTypes();
				if (t.length != 5 || t[0] != DrawContext.class || t[2] != int.class || t[3] != int.class || t[4] != int.class
						|| !java.lang.reflect.Modifier.isStatic(d.getModifiers()) || t[1].isPrimitive()) continue;
				for (java.lang.reflect.Method g : AbstractClientPlayerEntity.class.getMethods()) {
					if (g.getParameterCount() == 0 && g.getReturnType() == t[1]) {
						Object skin = g.invoke(p);
						if (skin != null) d.invoke(null, c, skin, x, y, size);
						return;
					}
				}
			}
		}

		@Override
		public void onHud(DrawContext c) {
			if (shown == null) return;
			long age = System.currentTimeMillis() - shownAt;
			if (age > showSeconds.get() * 1000) {
				shown = null;
				return;
			}
			int w = c.getScaledWindowWidth(), h = c.getScaledWindowHeight();
			String name = shown.getName().getString();
			String head = reason.toUpperCase() + " NEARBY";
			int bw = Math.max(150, Math.max(mc.textRenderer.getWidth(name), mc.textRenderer.getWidth(head)) + 60);
			int x = w / 2 - bw / 2, y = h / 2 - 70;
			boolean pulse = (age / 250) % 2 == 0;
			c.fill(x, y, x + bw, y + 44, 0xCC120808);
			c.fill(x, y, x + bw, y + 1, pulse ? 0xFFFF3B3B : 0xFF8A1F1F);
			c.fill(x, y + 43, x + bw, y + 44, pulse ? 0xFFFF3B3B : 0xFF8A1F1F);
			try {
				drawFace(c, shown, x + 6, y + 6, 32);
			} catch (Throwable ignored) {
			}
			c.drawText(mc.textRenderer, head, x + 46, y + 10, 0xFFFF5555, false);
			c.drawText(mc.textRenderer, name, x + 46, y + 24, 0xFFFFFFFF, false);
		}
	}
}
