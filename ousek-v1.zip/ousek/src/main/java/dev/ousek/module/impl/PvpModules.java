package dev.ousek.module.impl;

import dev.ousek.module.Category;
import dev.ousek.module.Module;
import dev.ousek.module.Util;
import dev.ousek.setting.Setting;
import net.minecraft.block.BlockState;
import net.minecraft.block.Blocks;
import net.minecraft.block.RespawnAnchorBlock;
import net.minecraft.client.MinecraftClient;
import net.minecraft.entity.Entity;
import net.minecraft.entity.LivingEntity;
import net.minecraft.entity.decoration.EndCrystalEntity;
import net.minecraft.item.ItemStack;
import net.minecraft.item.Items;
import net.minecraft.util.Hand;
import net.minecraft.util.hit.BlockHitResult;
import net.minecraft.util.hit.EntityHitResult;
import net.minecraft.util.hit.HitResult;
import net.minecraft.util.math.Box;
import net.minecraft.util.math.BlockPos;
import net.minecraft.util.math.Direction;
import net.minecraft.util.math.Vec3d;
import net.minecraft.world.RaycastContext;
import net.minecraft.world.World;

import java.util.List;

public final class PvpModules {
	private PvpModules() {
	}

	public static void register(List<Module> list) {
		list.add(new FakeLag());
		list.add(new AutoCrystal());
		list.add(new AutoHitCrystal());
		list.add(new AutoAnchor());
	}

	// ---------- shared crystal helpers ----------

	static double exposure(Vec3d from, LivingEntity e) {
		MinecraftClient mc = MinecraftClient.getInstance();
		Box bb = e.getBoundingBox();
		double cx = (bb.minX + bb.maxX) / 2, cz = (bb.minZ + bb.maxZ) / 2;
		double[] ys = {bb.minY + 0.1, (bb.minY + bb.maxY) / 2, bb.maxY - 0.1};
		int seen = 0;
		for (double y : ys) {
			BlockHitResult r = mc.world.raycast(new RaycastContext(from, new Vec3d(cx, y, cz),
					RaycastContext.ShapeType.COLLIDER, RaycastContext.FluidHandling.NONE, mc.player));
			if (r.getType() == HitResult.Type.MISS) seen++;
		}
		return seen / 3.0;
	}

	/** Approximate end crystal damage (ignores armor and difficulty). */
	static double damage(Vec3d crystal, LivingEntity e) {
		double dist = crystal.distanceTo(new Vec3d(e.getX(), e.getY(), e.getZ()));
		double d = dist / 12.0;
		if (d > 1) return 0;
		double exp = exposure(crystal, e);
		if (exp <= 0) return 0;
		double impact = (1 - d) * exp;
		return (impact * impact + impact) / 2 * 7 * 12 + 1;
	}

	static boolean isBase(BlockState s) {
		return s.isOf(Blocks.OBSIDIAN) || s.isOf(Blocks.BEDROCK);
	}

	// ---------- FakeLag ----------

	public static class FakeLag extends Module {
		final Setting.Num delay = num("Delay (ms)", 200, 50, 1000, 10);
		final Setting.Bool moveOnly = bool("Movement only", false);
		final Setting.Bool onAttack = bool("Release on attack", true);
		final Setting.Num range = num("Only near players (0 = always)", 0, 0, 20, 1);
		long last;

		public FakeLag() {
			super("FakeLag", "Delays your outgoing packets", Category.COMBAT);
		}

		@Override
		public String suffix() {
			return delay.i() + "ms";
		}

		@Override
		public void onEnable() {
			last = System.currentTimeMillis();
		}

		@Override
		public void onDisable() {
			PacketDelay.active = false;
			PacketDelay.flush();
		}

		@Override
		public void onTick() {
			PacketDelay.movementOnly = moveOnly.on();
			boolean near = range.i() <= 0 || !Util.targets(range.get(), true, false).isEmpty();
			if (!near) {
				PacketDelay.active = false;
				PacketDelay.flush();
				return;
			}
			PacketDelay.active = true;
			long now = System.currentTimeMillis();
			boolean attacking = onAttack.on() && mc.options.attackKey.isPressed();
			if (now - last >= delay.i() || PacketDelay.size() > 150 || attacking) {
				PacketDelay.flush();
				last = now;
			}
		}
	}

	// ---------- AutoCrystal ----------

	public static class AutoCrystal extends Module {
		final Setting.Bool place = bool("Place", true);
		final Setting.Bool breakB = bool("Break", true);
		final Setting.Num targetRange = num("Target range", 10, 3, 16, 1);
		final Setting.Num placeRange = num("Place range", 4.5, 2, 6, 0.1);
		final Setting.Num breakRange = num("Break range", 4.5, 2, 6, 0.1);
		final Setting.Num minDmg = num("Min damage", 4, 0, 20, 0.5);
		final Setting.Num maxSelf = num("Max self damage", 8, 0, 20, 0.5);
		final Setting.Num placeDelay = num("Place delay (ms)", 60, 0, 500, 10);
		final Setting.Num breakDelay = num("Break delay (ms)", 60, 0, 500, 10);
		final Setting.Bool rotate = bool("Rotate", true);
		final Setting.Bool autoSwitch = bool("Auto switch", true);
		long lastPlace, lastBreak;
		int prevSlot = -1;

		public AutoCrystal() {
			super("AutoCrystal", "Places and breaks end crystals near targets", Category.COMBAT);
		}

		@Override
		public void onDisable() {
			restore();
		}

		void restore() {
			if (prevSlot >= 0 && mc.player != null) Util.select(prevSlot);
			prevSlot = -1;
		}

		Hand crystalHand() {
			if (mc.player.getOffHandStack().isOf(Items.END_CRYSTAL)) return Hand.OFF_HAND;
			if (mc.player.getMainHandStack().isOf(Items.END_CRYSTAL)) return Hand.MAIN_HAND;
			if (autoSwitch.on()) {
				int s = Util.findHotbar(Items.END_CRYSTAL);
				if (s >= 0) {
					if (prevSlot < 0) prevSlot = mc.player.getInventory().getSelectedSlot();
					Util.select(s);
					return Hand.MAIN_HAND;
				}
			}
			return null;
		}

		@Override
		public void onTick() {
			if (mc.currentScreen != null) return;
			LivingEntity target = Util.nearestPlayer(targetRange.get());
			if (target == null) {
				restore();
				return;
			}
			long now = System.currentTimeMillis();
			double selfHp = mc.player.getHealth() + mc.player.getAbsorptionAmount();

			if (breakB.on() && now - lastBreak >= breakDelay.i()) {
				EndCrystalEntity best = null;
				double bestDmg = -1;
				for (Entity e : mc.world.getEntities()) {
					if (!(e instanceof EndCrystalEntity c) || mc.player.distanceTo(c) > breakRange.get()) continue;
					Vec3d cp = Util.pos(c);
					double dt = damage(cp, target), ds = damage(cp, mc.player);
					if (ds > maxSelf.get() || ds >= selfHp - 1) continue;
					if ((dt >= minDmg.get() || dt >= target.getHealth()) && dt > bestDmg) {
						bestDmg = dt;
						best = c;
					}
				}
				if (best != null) {
					if (rotate.on()) Util.face(Util.pos(best).add(0, 0.5, 0));
					Util.attack(best);
					lastBreak = now;
					return;
				}
			}

			if (place.on() && now - lastPlace >= placeDelay.i()) {
				BlockPos base = mc.player.getBlockPos();
				int r = (int) Math.ceil(placeRange.get());
				BlockPos bestPos = null;
				double bestScore = -999;
				Vec3d eye = mc.player.getEyePos();
				for (int x = -r; x <= r; x++) {
					for (int y = -r; y <= r; y++) {
						for (int z = -r; z <= r; z++) {
							BlockPos p = base.add(x, y, z);
							if (!isBase(mc.world.getBlockState(p))) continue;
							BlockPos up = p.up();
							if (!mc.world.getBlockState(up).isAir() || !mc.world.getBlockState(up.up()).isAir()) continue;
							if (eye.distanceTo(Vec3d.ofCenter(up)) > placeRange.get()) continue;
							Box box = new Box(up.getX(), up.getY(), up.getZ(), up.getX() + 1, up.getY() + 2, up.getZ() + 1);
							if (!mc.world.getOtherEntities(null, box).isEmpty()) continue;
							Vec3d cp = new Vec3d(p.getX() + 0.5, p.getY() + 1.0, p.getZ() + 0.5);
							double dt = damage(cp, target);
							if (dt < minDmg.get() && dt < target.getHealth()) continue;
							double ds = damage(cp, mc.player);
							if (ds > maxSelf.get() || ds >= selfHp - 1) continue;
							double score = dt - ds * 0.5;
							if (score > bestScore) {
								bestScore = score;
								bestPos = p;
							}
						}
					}
				}
				if (bestPos != null) {
					Hand hand = crystalHand();
					if (hand == null) return;
					if (rotate.on()) Util.face(Vec3d.ofCenter(bestPos).add(0, 0.5, 0));
					BlockHitResult hr = new BlockHitResult(new Vec3d(bestPos.getX() + 0.5, bestPos.getY() + 1.0, bestPos.getZ() + 0.5),
							Direction.UP, bestPos, false);
					mc.interactionManager.interactBlock(mc.player, hand, hr);
					mc.player.swingHand(hand);
					lastPlace = now;
				}
			}
		}
	}

	// ---------- AutoHitCrystal ----------

	public static class AutoHitCrystal extends Module {
		final Setting.Bool autoPlace = bool("Auto place", true);
		final Setting.Num hitDelay = num("Hit delay (ms)", 40, 0, 300, 10);
		final Setting.Num placeDelay = num("Place delay (ms)", 80, 0, 500, 10);
		final Setting.Bool needHold = bool("Only while using", true);
		long lastHit, lastPlace;

		public AutoHitCrystal() {
			super("AutoHitCrystal", "Places a crystal on the block you look at and hits it", Category.COMBAT);
		}

		@Override
		public void onTick() {
			if (mc.currentScreen != null) return;
			boolean crystal = mc.player.getMainHandStack().isOf(Items.END_CRYSTAL) || mc.player.getOffHandStack().isOf(Items.END_CRYSTAL);
			if (!crystal) return;
			if (needHold.on() && !mc.options.useKey.isPressed()) return;
			long now = System.currentTimeMillis();

			if (mc.crosshairTarget instanceof EntityHitResult er && er.getEntity() instanceof EndCrystalEntity c) {
				if (now - lastHit >= hitDelay.i()) {
					Util.attack(c);
					lastHit = now;
				}
				return;
			}
			if (!(mc.crosshairTarget instanceof BlockHitResult hit) || hit.getType() != HitResult.Type.BLOCK) return;
			BlockPos p = hit.getBlockPos();
			if (!isBase(mc.world.getBlockState(p))) return;
			BlockPos up = p.up();
			List<EndCrystalEntity> list = mc.world.getEntitiesByClass(EndCrystalEntity.class, new Box(up), e -> true);
			if (!list.isEmpty()) {
				if (now - lastHit >= hitDelay.i()) {
					Util.attack(list.get(0));
					lastHit = now;
				}
			} else if (autoPlace.on() && now - lastPlace >= placeDelay.i()
					&& mc.world.getBlockState(up).isAir() && mc.world.getOtherEntities(null, new Box(up)).isEmpty()) {
				Hand hand = mc.player.getOffHandStack().isOf(Items.END_CRYSTAL) ? Hand.OFF_HAND : Hand.MAIN_HAND;
				mc.interactionManager.interactBlock(mc.player, hand, hit);
				mc.player.swingHand(hand);
				lastPlace = now;
			}
		}
	}

	// ---------- AutoAnchor ----------

	public static class AutoAnchor extends Module {
		final Setting.Num targetRange = num("Target range", 8, 3, 12, 1);
		final Setting.Num placeRange = num("Place range", 4.5, 2, 6, 0.1);
		final Setting.Num safeDist = num("Min distance from you", 3, 1, 6, 0.5);
		final Setting.Num minHealth = num("Min health to explode", 8, 1, 20, 1);
		final Setting.Num delay = num("Delay (ticks)", 2, 1, 10, 1);
		final Setting.Bool rotate = bool("Rotate", true);
		int wait;

		public AutoAnchor() {
			super("AutoAnchor", "Places, charges (4x glowstone) and detonates respawn anchors", Category.COMBAT);
		}

		BlockPos findAnchor(LivingEntity target) {
			BlockPos t = target.getBlockPos();
			BlockPos best = null;
			double bd = 999;
			for (int x = -3; x <= 3; x++) {
				for (int y = -2; y <= 4; y++) {
					for (int z = -3; z <= 3; z++) {
						BlockPos p = t.add(x, y, z);
						if (!mc.world.getBlockState(p).isOf(Blocks.RESPAWN_ANCHOR)) continue;
						if (mc.player.getEyePos().distanceTo(Vec3d.ofCenter(p)) > placeRange.get() + 0.5) continue;
						double d = Vec3d.ofCenter(p).distanceTo(Util.pos(target));
						if (d < bd) {
							bd = d;
							best = p;
						}
					}
				}
			}
			return best;
		}

		void use(BlockPos p) {
			if (rotate.on()) Util.face(Vec3d.ofCenter(p));
			BlockHitResult hr = new BlockHitResult(Vec3d.ofCenter(p), Direction.UP, p, false);
			mc.interactionManager.interactBlock(mc.player, Hand.MAIN_HAND, hr);
			mc.player.swingHand(Hand.MAIN_HAND);
		}

		boolean placeAnchor(LivingEntity target) {
			int slot = Util.findHotbar(Items.RESPAWN_ANCHOR);
			if (slot < 0) return false;
			BlockPos t = target.getBlockPos();
			BlockPos bestPos = null;
			Direction bestFace = null;
			BlockPos bestNeighbor = null;
			double bd = 999;
			Vec3d eye = mc.player.getEyePos();
			for (int x = -2; x <= 2; x++) {
				for (int y = -1; y <= 3; y++) {
					for (int z = -2; z <= 2; z++) {
						BlockPos p = t.add(x, y, z);
						if (!mc.world.getBlockState(p).isReplaceable()) continue;
						Vec3d c = Vec3d.ofCenter(p);
						if (eye.distanceTo(c) > placeRange.get() || c.distanceTo(eye) < safeDist.get()) continue;
						for (Direction d : Direction.values()) {
							BlockPos n = p.offset(d);
							if (mc.world.getBlockState(n).isReplaceable()) continue;
							double dist = c.distanceTo(Util.pos(target));
							if (dist < bd) {
								bd = dist;
								bestPos = p;
								bestFace = d.getOpposite();
								bestNeighbor = n;
							}
							break;
						}
					}
				}
			}
			if (bestPos == null) return false;
			Util.select(slot);
			if (rotate.on()) Util.face(Vec3d.ofCenter(bestPos));
			Vec3d hitPos = Vec3d.ofCenter(bestNeighbor).add(Vec3d.of(bestFace.getVector()).multiply(0.5));
			mc.interactionManager.interactBlock(mc.player, Hand.MAIN_HAND, new BlockHitResult(hitPos, bestFace, bestNeighbor, false));
			mc.player.swingHand(Hand.MAIN_HAND);
			return true;
		}

		@Override
		public void onTick() {
			if (mc.currentScreen != null) return;
			if (mc.world.getRegistryKey() == World.NETHER) {
				Util.info("AutoAnchor: anchors only explode outside the Nether.");
				setEnabled(false);
				return;
			}
			if (wait-- > 0) return;
			LivingEntity target = Util.nearestPlayer(targetRange.get());
			if (target == null) return;

			BlockPos anchor = findAnchor(target);
			if (anchor == null) {
				if (placeAnchor(target)) wait = delay.i();
				return;
			}

			int charges = mc.world.getBlockState(anchor).get(RespawnAnchorBlock.CHARGES);
			if (charges < 4) {
				int gs = Util.findHotbar(Items.GLOWSTONE);
				if (gs < 0) return;
				Util.select(gs);
				use(anchor);
				wait = delay.i();
				return;
			}

			if (mc.player.getHealth() < minHealth.get()) return;
			int slot = -1;
			for (int i = 0; i < 9; i++) {
				ItemStack s = mc.player.getInventory().getStack(i);
				if (!s.isOf(Items.GLOWSTONE) && !s.isOf(Items.RESPAWN_ANCHOR)) {
					slot = i;
					break;
				}
			}
			if (slot < 0) return;
			Util.select(slot);
			use(anchor);
			wait = delay.i() * 2;
		}
	}
}
