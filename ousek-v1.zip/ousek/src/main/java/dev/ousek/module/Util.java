package dev.ousek.module;

import net.minecraft.client.MinecraftClient;
import net.minecraft.entity.Entity;
import net.minecraft.entity.LivingEntity;
import net.minecraft.entity.mob.MobEntity;
import net.minecraft.entity.player.PlayerEntity;
import net.minecraft.text.Text;
import net.minecraft.util.math.Vec3d;

import java.util.ArrayList;
import java.util.List;

public final class Util {
	private static final MinecraftClient mc = MinecraftClient.getInstance();

	private Util() {
	}

	public static boolean moving() {
		return mc.options.forwardKey.isPressed() || mc.options.backKey.isPressed()
				|| mc.options.leftKey.isPressed() || mc.options.rightKey.isPressed();
	}

	public static void setSpeed(double speed) {
		if (mc.player == null) return;
		double f = (mc.options.forwardKey.isPressed() ? 1 : 0) - (mc.options.backKey.isPressed() ? 1 : 0);
		double r = (mc.options.rightKey.isPressed() ? 1 : 0) - (mc.options.leftKey.isPressed() ? 1 : 0);
		Vec3d v = mc.player.getVelocity();
		if (f == 0 && r == 0) {
			mc.player.setVelocity(0, v.y, 0);
			return;
		}
		double rad = Math.toRadians(mc.player.getYaw());
		double sin = Math.sin(rad), cos = Math.cos(rad);
		double x = f * -sin + r * -cos;
		double z = f * cos + r * -sin;
		double len = Math.sqrt(x * x + z * z);
		mc.player.setVelocity(x / len * speed, v.y, z / len * speed);
	}

	public static List<LivingEntity> targets(double range, boolean players, boolean mobs) {
		List<LivingEntity> out = new ArrayList<>();
		if (mc.world == null || mc.player == null) return out;
		for (Entity e : mc.world.getEntities()) {
			if (e == mc.player || !(e instanceof LivingEntity le) || !le.isAlive()) continue;
			if (mc.player.distanceTo(e) > range) continue;
			if (e instanceof PlayerEntity && players) out.add(le);
			else if (e instanceof MobEntity && mobs) out.add(le);
		}
		return out;
	}

	public static float[] rotationsTo(Entity e) {
		Vec3d eye = mc.player.getEyePos();
		Vec3d t = new Vec3d(e.getX(), e.getY() + e.getHeight() * 0.6, e.getZ());
		double dx = t.x - eye.x, dy = t.y - eye.y, dz = t.z - eye.z;
		double h = Math.sqrt(dx * dx + dz * dz);
		float yaw = (float) Math.toDegrees(Math.atan2(dz, dx)) - 90f;
		float pitch = (float) -Math.toDegrees(Math.atan2(dy, h));
		return new float[]{yaw, pitch};
	}

	public static void attack(Entity e) {
		mc.interactionManager.attackEntity(mc.player, e);
		mc.player.swingHand(net.minecraft.util.Hand.MAIN_HAND);
	}

	public static int invToScreen(int invIndex) {
		return invIndex < 9 ? invIndex + 36 : invIndex;
	}

	public static void info(String s) {
		if (mc.inGameHud != null) {
			mc.inGameHud.getChatHud().addMessage(Text.literal("§c[Ousek] §7" + s));
		}
	}
}
