package dev.ousek.module.impl;

import dev.ousek.module.Category;
import dev.ousek.module.Module;
import dev.ousek.setting.Setting;
import net.minecraft.client.gui.DrawContext;

/**
 * Atmosphere: changes the world itself (time of day, weather, sky and fog colour), client side only.
 * Time and weather are written to the client world every frame; the sky and fog colours are blended in by mixins
 * (SkyRenderingMixin, FogRendererMixin) through {@link #sky(int)} and {@link #fog(float[])}.
 */
public class AtmosphereModule extends Module {
	private static volatile AtmosphereModule inst;

	// preset: time of day, weather (0 clear, 1 rain, 2 storm), sky rgb, strength 0-100
	private static final String[] PRESETS = {"Custom", "Sunset", "Dawn", "Midnight", "Blood Moon", "Vaporwave", "Toxic", "Overcast", "Deep Ocean"};
	private static final int[] P_TIME = {0, 12600, 23000, 18000, 18000, 13000, 6000, 6000, 3000};
	private static final int[] P_WEATHER = {0, 0, 0, 0, 0, 0, 0, 1, 0};
	private static final int[] P_RGB = {0, 0xFF6A2B, 0xFF9AB0, 0x0A0F2E, 0x8A0A12, 0xC25CFF, 0x5CFF3A, 0x6E7580, 0x0B4FA8};
	private static final int[] P_STR = {0, 85, 70, 90, 90, 80, 75, 70, 80};

	final Setting.Mode preset = mode("Preset", "Custom", PRESETS);
	final Setting.Mode timeMode = mode("Time", "Server", "Server", "Fixed", "Cycle");
	final Setting.Num time = num("Time of day", 6000, 0, 24000, 250);
	final Setting.Num cycle = num("Cycle speed", 20, 1, 200, 1);
	final Setting.Mode weather = mode("Weather", "Server", "Server", "Clear", "Rain", "Storm");
	final Setting.Bool skyOn = bool("Custom sky", true);
	final Setting.Num hue = num("Sky hue", 210, 0, 360, 5);
	final Setting.Num sat = num("Sky saturation", 70, 0, 100, 5);
	final Setting.Num bri = num("Sky brightness", 80, 0, 100, 5);
	final Setting.Num strength = num("Sky strength", 70, 0, 100, 5);
	final Setting.Bool fogOn = bool("Tint fog too", true);

	private double clock = 6000;
	private long lastNs;
	private boolean overrodeTime;

	public AtmosphereModule() {
		super("Atmosphere", "Change the time, weather, sky and fog colour of the world (client side)", Category.RENDER);
		inst = this;
	}

	// ---------------- values in effect (a preset overrides the manual settings) ----------------

	private int idx() {
		return Math.max(0, preset.index());
	}

	private boolean useSky() {
		return idx() > 0 || skyOn.on();
	}

	private int skyRgb() {
		int i = idx();
		if (i > 0) return P_RGB[i];
		return hsv(hue.get() / 360.0, sat.get() / 100.0, bri.get() / 100.0);
	}

	private double skyStrength() {
		int i = idx();
		return (i > 0 ? P_STR[i] : strength.get()) / 100.0;
	}

	private static int hsv(double h, double s, double v) {
		h = (h - Math.floor(h)) * 6.0;
		int k = (int) h;
		double f = h - k, p = v * (1 - s), q = v * (1 - s * f), t = v * (1 - s * (1 - f));
		double r, g, b;
		switch (k) {
			case 0 -> { r = v; g = t; b = p; }
			case 1 -> { r = q; g = v; b = p; }
			case 2 -> { r = p; g = v; b = t; }
			case 3 -> { r = p; g = q; b = v; }
			case 4 -> { r = t; g = p; b = v; }
			default -> { r = v; g = p; b = q; }
		}
		return ((int) Math.round(r * 255) << 16) | ((int) Math.round(g * 255) << 8) | (int) Math.round(b * 255);
	}

	// ---------------- called by the mixins ----------------

	/** Blends the vanilla sky colour (keeps its alpha byte) towards the chosen one. */
	public static int sky(int vanilla) {
		try {
			AtmosphereModule a = inst;
			if (a == null || !a.enabled || !a.useSky()) return vanilla;
			return mix(vanilla, a.skyRgb(), a.skyStrength());
		} catch (Throwable t) {
			return vanilla;
		}
	}

	/** Blends the fog/horizon colour in place (rgb 0..1). */
	public static void fog(float[] rgb) {
		try {
			AtmosphereModule a = inst;
			if (a == null || !a.enabled || !a.useSky() || !a.fogOn.on()) return;
			if (mc.player != null && (mc.player.isSubmergedInWater() || mc.player.isInLava())) return;
			int c = a.skyRgb();
			double s = a.skyStrength();
			rgb[0] += (float) ((((c >> 16) & 255) / 255.0 - rgb[0]) * s);
			rgb[1] += (float) ((((c >> 8) & 255) / 255.0 - rgb[1]) * s);
			rgb[2] += (float) (((c & 255) / 255.0 - rgb[2]) * s);
		} catch (Throwable ignored) {
		}
	}

	private static int mix(int vanilla, int rgb, double s) {
		int r = (int) Math.round(((vanilla >> 16) & 255) * (1 - s) + ((rgb >> 16) & 255) * s);
		int g = (int) Math.round(((vanilla >> 8) & 255) * (1 - s) + ((rgb >> 8) & 255) * s);
		int b = (int) Math.round((vanilla & 255) * (1 - s) + (rgb & 255) * s);
		return (vanilla & 0xFF000000) | (r << 16) | (g << 8) | b;
	}

	// ---------------- time and weather ----------------

	@Override
	public void onEnable() {
		lastNs = 0;
		if (mc.world != null) clock = mc.world.getTimeOfDay() % 24000L;
	}

	@Override
	public void onDisable() {
		if (mc.world != null && overrodeTime) {
			try {
				mc.world.setTime(mc.world.getTimeOfDay(), mc.world.getTimeOfDay(), true); // the server's next time packet resyncs it
			} catch (Throwable ignored) {
			}
		}
		overrodeTime = false;
	}

	@Override
	public void onTick() {
		apply();
	}

	@Override
	public void onHud(DrawContext ctx) {
		apply(); // every frame, so server updates never show for more than a frame
	}

	private void apply() {
		if (!ready()) return;
		long now = System.nanoTime();
		double dt = lastNs == 0 ? 0 : Math.min(0.1, (now - lastNs) / 1e9);
		lastNs = now;
		int i = idx();
		try {
			String tm = i > 0 ? "Fixed" : timeMode.value;
			if (!"Server".equals(tm)) {
				if ("Cycle".equals(tm)) clock = (clock + dt * cycle.get()) % 24000.0;
				else clock = i > 0 ? P_TIME[i] : time.get();
				mc.world.setTime((long) clock, (long) clock, false);
				overrodeTime = true;
			} else if (overrodeTime) {
				mc.world.setTime(mc.world.getTimeOfDay(), mc.world.getTimeOfDay(), true);
				overrodeTime = false;
			}
		} catch (Throwable ignored) {
		}
		try {
			int w = i > 0 ? P_WEATHER[i] + 1 : weather.index(); // 0 server, 1 clear, 2 rain, 3 storm
			if (w > 0) {
				mc.world.setRainGradient(w >= 3 ? 1f : w == 2 ? 0.9f : 0f);
				mc.world.setThunderGradient(w >= 3 ? 1f : 0f);
			}
		} catch (Throwable ignored) {
		}
	}

	@Override
	public String suffix() {
		return idx() > 0 ? PRESETS[idx()] : null;
	}
}
