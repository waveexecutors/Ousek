package dev.ousek.module.impl;

import dev.ousek.module.Category;
import dev.ousek.module.Module;
import dev.ousek.setting.Setting;
import net.minecraft.client.gui.DrawContext;

/** Screen atmosphere: colour tint, haze, darkness, brightness, vignette and cinematic bars. Every value is adjustable. */
public class AtmosphereModule extends Module {
	public final Setting.Mode preset = mode("Preset", "Custom", "Custom", "Sunset", "Night", "Foggy", "Cold", "Warm", "Vaporwave", "Toxic", "Blood");
	public final Setting.Num hue = num("Tint hue", 30, 0, 350, 10);
	public final Setting.Num tint = num("Tint strength %", 15, 0, 60, 1);
	public final Setting.Num haze = num("Haze %", 0, 0, 60, 1);
	public final Setting.Num dark = num("Darkness %", 0, 0, 70, 1);
	public final Setting.Num bright = num("Brightness %", 0, 0, 40, 1);
	public final Setting.Num vignette = num("Vignette %", 25, 0, 90, 1);
	public final Setting.Num vigSize = num("Vignette size", 20, 5, 45, 1);
	public final Setting.Bool bars = bool("Cinematic bars", false);
	public final Setting.Num barSize = num("Bar size %", 10, 4, 20, 1);
	public final Setting.Bool pulse = bool("Breathing", false);

	public AtmosphereModule() {
		super("Atmosphere", "Tint, haze, darkness, vignette and bars over the whole screen", Category.RENDER);
	}

	private static int hsv(double h, double s, double v) {
		h = ((h % 360) + 360) % 360 / 60.0;
		int i = (int) h;
		double f = h - i, p = v * (1 - s), q = v * (1 - s * f), t = v * (1 - s * (1 - f));
		double r, g, b;
		switch (i) {
			case 0 -> { r = v; g = t; b = p; }
			case 1 -> { r = q; g = v; b = p; }
			case 2 -> { r = p; g = v; b = t; }
			case 3 -> { r = p; g = q; b = v; }
			case 4 -> { r = t; g = p; b = v; }
			default -> { r = v; g = p; b = q; }
		}
		return ((int) (r * 255) << 16) | ((int) (g * 255) << 8) | (int) (b * 255);
	}

	private static int a(double pct) {
		return Math.max(0, Math.min(255, (int) Math.round(pct * 2.55)));
	}

	@Override
	public void onHud(DrawContext c) {
		int w = c.getScaledWindowWidth(), h = c.getScaledWindowHeight();
		double th = hue.get(), ts = tint.get(), hz = haze.get(), dk = dark.get(), br = bright.get(), vg = vignette.get();
		switch (preset.value) {
			case "Sunset" -> { th = 25; ts = 22; hz = 6; dk = 6; br = 0; vg = 35; }
			case "Night" -> { th = 225; ts = 25; hz = 0; dk = 28; br = 0; vg = 45; }
			case "Foggy" -> { th = 200; ts = 6; hz = 28; dk = 0; br = 4; vg = 20; }
			case "Cold" -> { th = 205; ts = 18; hz = 4; dk = 0; br = 0; vg = 25; }
			case "Warm" -> { th = 35; ts = 16; hz = 3; dk = 0; br = 2; vg = 20; }
			case "Vaporwave" -> { th = 300; ts = 24; hz = 4; dk = 4; br = 0; vg = 30; }
			case "Toxic" -> { th = 100; ts = 22; hz = 5; dk = 6; br = 0; vg = 35; }
			case "Blood" -> { th = 0; ts = 26; hz = 0; dk = 12; br = 0; vg = 45; }
			default -> { }
		}
		double k = pulse.on() ? 0.75 + 0.25 * Math.sin(System.currentTimeMillis() / 1200.0) : 1.0;
		if (ts > 0) c.fill(0, 0, w, h, (a(ts * k) << 24) | hsv(th, 0.85, 1.0));
		if (hz > 0) c.fill(0, 0, w, h, (a(hz * k) << 24) | 0xCFD6DE);
		if (dk > 0) c.fill(0, 0, w, h, (a(dk * k) << 24));
		if (br > 0) c.fill(0, 0, w, h, (a(br * k) << 24) | 0xFFFFFF);
		if (vg > 0) {
			int steps = 18;
			double size = vigSize.get() / 100.0;
			for (int i = 0; i < steps; i++) {
				double f = 1.0 - i / (double) steps;
				int al = a(vg * f * f * 0.45);
				int ex = (int) (w * size * (i / (double) steps)), ey = (int) (h * size * (i / (double) steps));
				int ex2 = (int) (w * size * ((i + 1) / (double) steps)), ey2 = (int) (h * size * ((i + 1) / (double) steps));
				int col = al << 24;
				c.fill(ex, ey, ex2, h - ey, col);                // left strip
				c.fill(w - ex2, ey, w - ex, h - ey, col);        // right strip
				c.fill(ex2, ey, w - ex2, ey2, col);              // top strip
				c.fill(ex2, h - ey2, w - ex2, h - ey, col);      // bottom strip
			}
		}
		if (bars.on()) {
			int bh = (int) (h * barSize.get() / 100.0);
			c.fill(0, 0, w, bh, 0xFF000000);
			c.fill(0, h - bh, w, h, 0xFF000000);
		}
	}
}
