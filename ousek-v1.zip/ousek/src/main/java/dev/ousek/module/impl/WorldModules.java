package dev.ousek.module.impl;

import dev.ousek.module.Category;
import dev.ousek.module.Module;
import dev.ousek.setting.Setting;
import net.minecraft.util.Hand;
import net.minecraft.util.math.BlockPos;
import net.minecraft.util.math.Direction;

import java.util.List;

public final class WorldModules {
	private WorldModules() {
	}

	public static void register(List<Module> list) {
		list.add(new Nuker());
	}

	public static class Nuker extends Module {
		final Setting.Num range = num("Range", 4, 1, 6, 1);
		final Setting.Bool ignoreFluids = bool("Ignore fluids", true);

		public Nuker() {
			super("Nuker", "Breaks blocks around you", Category.WORLD);
		}

		@Override
		public void onTick() {
			int r = range.i();
			BlockPos base = mc.player.getBlockPos();
			for (int x = -r; x <= r; x++) {
				for (int y = -r; y <= r; y++) {
					for (int z = -r; z <= r; z++) {
						BlockPos p = base.add(x, y, z);
						var state = mc.world.getBlockState(p);
						if (state.isAir() || state.getHardness(mc.world, p) < 0) continue;
						if (ignoreFluids.on() && !state.getFluidState().isEmpty()) continue;
						mc.interactionManager.updateBlockBreakingProgress(p, Direction.UP);
						mc.player.swingHand(Hand.MAIN_HAND);
						return;
					}
				}
			}
		}
	}
}
