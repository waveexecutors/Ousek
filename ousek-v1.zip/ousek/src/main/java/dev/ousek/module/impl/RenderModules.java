package dev.ousek.module.impl;

import dev.ousek.module.Category;
import dev.ousek.module.Module;
import dev.ousek.setting.Setting;
import net.minecraft.entity.Entity;
import net.minecraft.entity.ItemEntity;
import net.minecraft.entity.effect.StatusEffectInstance;
import net.minecraft.entity.effect.StatusEffects;
import net.minecraft.entity.player.PlayerEntity;

import java.util.List;

public final class RenderModules {
	private RenderModules() {
	}

	public static void register(List<Module> list) {
		list.add(new Fullbright());
		list.add(new ESP());
		list.add(new ItemESP());
		list.add(new Zoom());
		list.add(new FovChanger());
		list.add(new NoWeather());
	}

	public static class Fullbright extends Module {
		public Fullbright() {
			super("Fullbright", "See in the dark", Category.RENDER);
		}

		@Override
		public void onTick() {
			mc.player.addStatusEffect(new StatusEffectInstance(StatusEffects.NIGHT_VISION, 400, 0, false, false, false));
		}

		@Override
		public void onDisable() {
			if (mc.player != null) mc.player.removeStatusEffect(StatusEffects.NIGHT_VISION);
		}
	}

	public static class ESP extends Module {
		public ESP() {
			super("ESP", "Outlines players through walls", Category.RENDER);
		}

		@Override
		public void onTick() {
			for (Entity e : mc.world.getEntities()) {
				if (e instanceof PlayerEntity && e != mc.player) e.setGlowing(true);
			}
		}

		@Override
		public void onDisable() {
			if (mc.world == null) return;
			for (Entity e : mc.world.getEntities()) {
				if (e instanceof PlayerEntity && e != mc.player) e.setGlowing(false);
			}
		}
	}

	public static class ItemESP extends Module {
		public ItemESP() {
			super("ItemESP", "Outlines dropped items", Category.RENDER);
		}

		@Override
		public void onTick() {
			for (Entity e : mc.world.getEntities()) {
				if (e instanceof ItemEntity) e.setGlowing(true);
			}
		}

		@Override
		public void onDisable() {
			if (mc.world == null) return;
			for (Entity e : mc.world.getEntities()) {
				if (e instanceof ItemEntity) e.setGlowing(false);
			}
		}
	}

	public static class Zoom extends Module {
		final Setting.Num fov = num("Zoom FOV", 30, 30, 70, 1);
		int old = 70;

		public Zoom() {
			super("Zoom", "Zooms in", Category.RENDER);
		}

		@Override
		public void onEnable() {
			old = mc.options.getFov().getValue();
		}

		@Override
		public void onTick() {
			mc.options.getFov().setValue(fov.i());
		}

		@Override
		public void onDisable() {
			mc.options.getFov().setValue(old);
		}
	}

	public static class FovChanger extends Module {
		final Setting.Num fov = num("FOV", 100, 30, 110, 1);
		int old = 70;

		public FovChanger() {
			super("FovChanger", "Sets your field of view", Category.RENDER);
		}

		@Override
		public void onEnable() {
			old = mc.options.getFov().getValue();
		}

		@Override
		public void onTick() {
			mc.options.getFov().setValue(fov.i());
		}

		@Override
		public void onDisable() {
			mc.options.getFov().setValue(old);
		}
	}

	public static class NoWeather extends Module {
		public NoWeather() {
			super("NoWeather", "Hides rain and thunder", Category.RENDER);
		}

		@Override
		public void onTick() {
			mc.world.setRainGradient(0f);
			mc.world.setThunderGradient(0f);
		}
	}
}
