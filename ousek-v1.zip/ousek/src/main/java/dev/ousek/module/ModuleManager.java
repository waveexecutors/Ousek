package dev.ousek.module;

import dev.ousek.module.impl.*;
import net.minecraft.client.MinecraftClient;
import org.lwjgl.glfw.GLFW;

import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;

public final class ModuleManager {
	public static final List<Module> modules = new ArrayList<>();
	private static final List<Object[]> scheduled = new ArrayList<>();

	private ModuleManager() {
	}

	public static void init() {
		CombatModules.register(modules);
		PvpModules.register(modules);
		MovementModules.register(modules);
		PlayerModules.register(modules);
		RenderModules.register(modules);
		VisualModules.register(modules);
		WorldModules.register(modules);
		MiscModules.register(modules);
		AuthModules.register(modules);
		WindowModules.register(modules);
		HudModules.register(modules);
		modules.add(new ClickGuiModule());
	}

	public static Module get(String name) {
		for (Module m : modules) if (m.name.equalsIgnoreCase(name)) return m;
		return null;
	}

	@SuppressWarnings("unchecked")
	public static <T extends Module> T get(Class<T> cls) {
		for (Module m : modules) if (cls.isInstance(m)) return (T) m;
		return null;
	}

	public static List<Module> in(Category c) {
		List<Module> out = new ArrayList<>();
		for (Module m : modules) if (m.category == c) out.add(m);
		return out;
	}

	public static void later(int ticks, Runnable r) {
		scheduled.add(new Object[]{ticks, r});
	}

	public static void chat(String message) {
		for (Module m : modules) {
			if (!m.enabled) continue;
			try {
				m.onChat(message);
			} catch (Throwable ignored) {
			}
		}
	}

	public static void tick() {
		MinecraftClient mc = MinecraftClient.getInstance();
		try {
			dev.ousek.emote.EmoteManager.tick();
		} catch (Throwable ignored) {
		}
		if (mc.player == null || mc.world == null) return;

		long handle = mc.getWindow().getHandle();
		for (Module m : modules) {
			if (m.key > 0) {
				boolean down = GLFW.glfwGetKey(handle, m.key) == GLFW.GLFW_PRESS;
				if (down && !m.keyDown && mc.currentScreen == null) m.onKey();
				m.keyDown = down;
			}
		}

		for (Module m : modules) {
			if (!m.enabled) continue;
			try {
				m.onTick();
			} catch (Throwable ignored) {
			}
		}

		Iterator<Object[]> it = scheduled.iterator();
		List<Runnable> due = new ArrayList<>();
		while (it.hasNext()) {
			Object[] s = it.next();
			int left = (Integer) s[0] - 1;
			if (left <= 0) {
				due.add((Runnable) s[1]);
				it.remove();
			} else {
				s[0] = left;
			}
		}
		for (Runnable r : due) r.run();
	}
}
