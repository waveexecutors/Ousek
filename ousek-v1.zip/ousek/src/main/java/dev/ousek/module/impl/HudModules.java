package dev.ousek.module.impl;

import dev.ousek.gui.Theme;
import dev.ousek.hud.HudElement;
import dev.ousek.module.Category;
import dev.ousek.module.Module;
import dev.ousek.module.ModuleManager;
import dev.ousek.setting.Setting;
import net.minecraft.client.gui.DrawContext;
import net.minecraft.entity.Entity;
import net.minecraft.entity.EquipmentSlot;
import net.minecraft.entity.LivingEntity;
import net.minecraft.entity.player.PlayerEntity;
import net.minecraft.item.ItemStack;

import java.time.LocalTime;
import java.time.format.DateTimeFormatter;
import java.util.ArrayList;
import java.util.List;
import java.util.Locale;

public final class HudModules {
	private HudModules() {
	}

	public static void register(List<Module> list) {
		list.add(new Watermark());
		list.add(new ArrayListHud());
		list.add(new Coordinates());
		list.add(new Fps());
		list.add(new Ping());
		list.add(new SpeedHud());
		list.add(new ArmorHud());
		list.add(new Clock());
		list.add(new TargetHud());
		list.add(new Radar());
		list.add(new Keystrokes());
	}

	public static class Watermark extends HudElement {
		final Setting.Bool showFps = bool("Show FPS", true);
		final Setting.Bool showName = bool("Show name", true);

		public Watermark() {
			super("Watermark", "Client name bar", 6, 6, false, true);
		}

		@Override
		protected void render(DrawContext c) {
			String brand = "Ousek";
			StringBuilder rest = new StringBuilder(" v1");
			if (showName.on()) rest.append("  |  ").append(mc.getSession().getUsername());
			if (showFps.on()) rest.append("  |  ").append(mc.getCurrentFps()).append(" fps");
			w = tw(brand) + tw(rest.toString()) + 10;
			h = 16;
			box(c, 0, 0, w, h);
			c.fill(1, 2, 3, h - 2, col(0));
			text(c, brand, 6, 4, col(0));
			text(c, rest.toString(), 6 + tw(brand), 4, 0xFFE8E8EE);
		}
	}

	public static class ArrayListHud extends HudElement {
		final Setting.Mode sort = mode("Sort", "Length", "Length", "Alphabetical");
		final Setting.Bool bar = bool("Side bar", true);
		final Setting.Bool suffixes = bool("Suffixes", true);

		public ArrayListHud() {
			super("ArrayList", "Enabled module list", -4, 6, true, true);
		}

		@Override
		protected void render(DrawContext c) {
			List<Module> en = new ArrayList<>();
			for (Module m : ModuleManager.modules) {
				if (m.enabled && m.category != Category.HUD && m.category != Category.CLIENT) en.add(m);
			}
			if (sort.is("Alphabetical")) en.sort((a, b) -> a.name.compareToIgnoreCase(b.name));
			else en.sort((a, b) -> label(b).length() - label(a).length());
			int maxW = 40;
			for (Module m : en) maxW = Math.max(maxW, tw(label(m)) + 8);
			w = maxW;
			h = Math.max(12, en.size() * 11);
			for (int i = 0; i < en.size(); i++) {
				Module m = en.get(i);
				String l = label(m);
				int rw = tw(l) + 6;
				int rx = w - rw;
				int ry = i * 11;
				if (background.on()) c.fill(rx, ry, w, ry + 11, 0xA0101014);
				if (bar.on()) c.fill(w - 1, ry, w, ry + 11, col(i));
				text(c, m.name, rx + 3, ry + 2, col(i));
				if (suffixes.on() && m.suffix() != null) text(c, " " + m.suffix(), rx + 3 + tw(m.name), ry + 2, 0xFF9A9AA6);
			}
		}

		String label(Module m) {
			return m.name + (suffixes.on() && m.suffix() != null ? " " + m.suffix() : "");
		}
	}

	public static class Coordinates extends HudElement {
		final Setting.Bool facing = bool("Facing", true);

		public Coordinates() {
			super("Coordinates", "Your position", 6, -22, false, true);
		}

		@Override
		protected void render(DrawContext c) {
			String s = String.format(Locale.ROOT, "XYZ  %.1f  %.1f  %.1f", mc.player.getX(), mc.player.getY(), mc.player.getZ());
			String f = facing.on() ? mc.player.getHorizontalFacing().asString() : "";
			w = Math.max(tw(s), tw(f)) + 8;
			h = facing.on() ? 24 : 14;
			box(c, 0, 0, w, h);
			text(c, s, 4, 3, col(0));
			if (facing.on()) text(c, f, 4, 14, 0xFFE8E8EE);
		}
	}

	public static class Fps extends HudElement {
		public Fps() {
			super("FPS", "Frames per second", 6, 28, false, true);
		}

		@Override
		protected void render(DrawContext c) {
			String s = "FPS  " + mc.getCurrentFps();
			w = tw(s) + 8;
			h = 14;
			box(c, 0, 0, w, h);
			text(c, s, 4, 3, col(0));
		}
	}

	public static class Ping extends HudElement {
		public Ping() {
			super("Ping", "Server latency", 6, 44, false, true);
		}

		@Override
		protected void render(DrawContext c) {
			int ms = 0;
			if (mc.getNetworkHandler() != null) {
				var e = mc.getNetworkHandler().getPlayerListEntry(mc.player.getUuid());
				if (e != null) ms = e.getLatency();
			}
			String s = "Ping  " + ms + " ms";
			w = tw(s) + 8;
			h = 14;
			box(c, 0, 0, w, h);
			text(c, s, 4, 3, col(0));
		}
	}

	public static class SpeedHud extends HudElement {
		double px, pz, bps;

		public SpeedHud() {
			super("Speed", "Blocks per second", 6, 60, false, false);
		}

		@Override
		public void onTick() {
			if (mc.player == null) return;
			bps = Math.hypot(mc.player.getX() - px, mc.player.getZ() - pz) * 20;
			px = mc.player.getX();
			pz = mc.player.getZ();
		}

		@Override
		protected void render(DrawContext c) {
			String s = String.format(Locale.ROOT, "Speed  %.2f b/s", bps);
			w = tw(s) + 8;
			h = 14;
			box(c, 0, 0, w, h);
			text(c, s, 4, 3, col(0));
		}
	}

	public static class ArmorHud extends HudElement {
		public ArmorHud() {
			super("Armor", "Worn armor and durability", -200, -56, false, true);
		}

		@Override
		protected void render(DrawContext c) {
			EquipmentSlot[] slots = {EquipmentSlot.HEAD, EquipmentSlot.CHEST, EquipmentSlot.LEGS, EquipmentSlot.FEET, EquipmentSlot.MAINHAND, EquipmentSlot.OFFHAND};
			w = slots.length * 18 + 2;
			h = 20;
			box(c, 0, 0, w, h);
			for (int i = 0; i < slots.length; i++) {
				ItemStack s = mc.player.getEquippedStack(slots[i]);
				if (s.isEmpty()) continue;
				c.drawItem(s, 2 + i * 18, 2);
				c.drawStackOverlay(mc.textRenderer, s, 2 + i * 18, 2);
			}
		}
	}

	public static class Clock extends HudElement {
		static final DateTimeFormatter F = DateTimeFormatter.ofPattern("HH:mm:ss");
		final Setting.Bool seconds = bool("Seconds", true);

		public Clock() {
			super("Clock", "Local time", 6, 76, false, false);
		}

		@Override
		protected void render(DrawContext c) {
			String s = LocalTime.now().format(seconds.on() ? F : DateTimeFormatter.ofPattern("HH:mm"));
			w = tw(s) + 8;
			h = 14;
			box(c, 0, 0, w, h);
			text(c, s, 4, 3, col(0));
		}
	}

	public static class TargetHud extends HudElement {
		public TargetHud() {
			super("TargetHUD", "Shows your KillAura target", 6, 100, false, true);
		}

		@Override
		protected void render(DrawContext c) {
			LivingEntity t = CombatModules.KillAura.target;
			String name = t == null ? "No target" : t.getName().getString();
			float hp = t == null ? 0 : t.getHealth();
			float max = t == null ? 20 : Math.max(1f, t.getMaxHealth());
			w = Math.max(90, tw(name) + 12);
			h = 28;
			box(c, 0, 0, w, h);
			text(c, name, 5, 4, 0xFFFFFFFF);
			c.fill(5, 17, w - 5, 21, 0xFF26262E);
			int fill = (int) ((w - 10) * Math.max(0f, Math.min(1f, hp / max)));
			c.fill(5, 17, 5 + fill, 21, col(0));
			text(c, String.format(Locale.ROOT, "%.1f HP", hp), 5, 21, 0xFF9A9AA6);
		}
	}

	public static class Radar extends HudElement {
		final Setting.Num range = num("Range", 40, 10, 128, 1);

		public Radar() {
			super("Radar", "Nearby players", -90, 110, false, false);
		}

		@Override
		protected void render(DrawContext c) {
			w = h = 72;
			box(c, 0, 0, w, h);
			int cx = w / 2, cy = h / 2;
			c.fill(cx, 2, cx + 1, h - 2, 0x30FFFFFF);
			c.fill(2, cy, w - 2, cy + 1, 0x30FFFFFF);
			c.fill(cx - 1, cy - 1, cx + 2, cy + 2, col(0));
			double rad = Math.toRadians(mc.player.getYaw());
			double sin = Math.sin(rad), cos = Math.cos(rad);
			for (Entity e : mc.world.getEntities()) {
				if (!(e instanceof PlayerEntity) || e == mc.player) continue;
				double dx = e.getX() - mc.player.getX(), dz = e.getZ() - mc.player.getZ();
				double f = dx * -sin + dz * cos;
				double r = dx * -cos + dz * -sin;
				int sx = cx + (int) (r / range.get() * (cx - 3));
				int sy = cy - (int) (f / range.get() * (cy - 3));
				if (sx < 2 || sx > w - 4 || sy < 2 || sy > h - 4) continue;
				c.fill(sx - 1, sy - 1, sx + 2, sy + 2, 0xFFFF4B5C);
			}
		}
	}

	public static class Keystrokes extends HudElement {
		public Keystrokes() {
			super("Keystrokes", "Movement keys", 6, -90, false, false);
		}

		void key(DrawContext c, int kx, int ky, int kw, String label, boolean down) {
			Theme.rrect(c, kx, ky, kw, 16, 3, down ? Theme.alpha(col(0), 0xC0) : 0xA0101014);
			text(c, label, kx + (kw - tw(label)) / 2, ky + 4, down ? 0xFF0B0B0F : 0xFFE8E8EE);
		}

		@Override
		protected void render(DrawContext c) {
			w = 54;
			h = 52;
			key(c, 19, 0, 16, "W", mc.options.forwardKey.isPressed());
			key(c, 0, 18, 16, "A", mc.options.leftKey.isPressed());
			key(c, 19, 18, 16, "S", mc.options.backKey.isPressed());
			key(c, 38, 18, 16, "D", mc.options.rightKey.isPressed());
			key(c, 0, 36, 54, "SPACE", mc.options.jumpKey.isPressed());
		}
	}
}
