package dev.ousek.module.impl;

import dev.ousek.gui.Theme;
import dev.ousek.module.Anims;
import dev.ousek.module.Category;
import dev.ousek.module.Module;
import dev.ousek.setting.Setting;
import net.minecraft.block.Block;
import net.minecraft.block.BlockState;
import net.minecraft.block.Blocks;
import net.minecraft.client.gui.DrawContext;
import net.minecraft.entity.effect.StatusEffectInstance;
import net.minecraft.entity.effect.StatusEffects;
import net.minecraft.item.BlockItem;
import net.minecraft.item.ItemStack;
import net.minecraft.registry.Registries;
import net.minecraft.registry.tag.ItemTags;
import net.minecraft.util.Arm;

import java.util.ArrayList;
import java.util.Comparator;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

public final class VisualModules {
	private VisualModules() {
	}

	public static void register(List<Module> list) {
		list.add(new HandGlow());
		list.add(new Xray());
		list.add(new Animations());
	}

	// ======================= HandGlow =======================

	/** Tiny 4x4 matrix stack that replays vanilla's first-person hand/item transforms. */
	static final class Mx {
		final double[] m = {1, 0, 0, 0, 0, 1, 0, 0, 0, 0, 1, 0, 0, 0, 0, 1};

		Mx mul(double[] b) {
			double[] r = new double[16];
			for (int i = 0; i < 4; i++)
				for (int j = 0; j < 4; j++) {
					double s = 0;
					for (int k = 0; k < 4; k++) s += m[i * 4 + k] * b[k * 4 + j];
					r[i * 4 + j] = s;
				}
			System.arraycopy(r, 0, m, 0, 16);
			return this;
		}

		Mx tr(double x, double y, double z) {
			return mul(new double[]{1, 0, 0, x, 0, 1, 0, y, 0, 0, 1, z, 0, 0, 0, 1});
		}

		Mx sc(double k) {
			return mul(new double[]{k, 0, 0, 0, 0, k, 0, 0, 0, 0, k, 0, 0, 0, 0, 1});
		}

		Mx rx(double deg) {
			double a = Math.toRadians(deg), c = Math.cos(a), s = Math.sin(a);
			return mul(new double[]{1, 0, 0, 0, 0, c, -s, 0, 0, s, c, 0, 0, 0, 0, 1});
		}

		Mx ry(double deg) {
			double a = Math.toRadians(deg), c = Math.cos(a), s = Math.sin(a);
			return mul(new double[]{c, 0, s, 0, 0, 1, 0, 0, -s, 0, c, 0, 0, 0, 0, 1});
		}

		Mx rz(double deg) {
			double a = Math.toRadians(deg), c = Math.cos(a), s = Math.sin(a);
			return mul(new double[]{c, -s, 0, 0, s, c, 0, 0, 0, 0, 1, 0, 0, 0, 0, 1});
		}

		double[] apply(double x, double y, double z) {
			return new double[]{
					m[0] * x + m[1] * y + m[2] * z + m[3],
					m[4] * x + m[5] * y + m[6] * z + m[7],
					m[8] * x + m[9] * y + m[10] * z + m[11]};
		}
	}

	/**
	 * Outlines your first-person hand / held item. It replays the exact transforms vanilla uses
	 * (equip offset, swing offset, display transform, arm model box) and projects the real 3D shape
	 * to the screen, so the outline follows the hand and the item through every swing animation
	 * (including the Animations module).
	 */
	public static class HandGlow extends Module {
		final Setting.Mode color = mode("Color", "Accent", "Accent", "Rainbow", "White");
		final Setting.Num thickness = num("Thickness", 2, 1, 6, 1);
		final Setting.Num glow = num("Glow layers", 3, 0, 6, 1);
		final Setting.Num intensity = num("Intensity", 8, 1, 10, 1);
		final Setting.Bool pulse = bool("Pulse", true);
		final Setting.Bool swingFlash = bool("Swing flash", true);
		final Setting.Bool mainHand = bool("Main hand", true);
		final Setting.Bool offhand = bool("Offhand", true);
		final Setting.Bool fill = bool("Fill", false);

		public HandGlow() {
			super("HandGlow", "Outlines your 3D hand and held items (main + offhand)", Category.RENDER);
		}

		int rgb(int edge) {
			if (color.is("Rainbow")) return Theme.rainbow(edge * 24);
			if (color.is("White")) return 0xFFFFFFFF;
			return Theme.accent();
		}

		@Override
		public void onHud(DrawContext c) {
			if (mc.player == null || mc.world == null || !mc.options.getPerspective().isFirstPerson()) return;
			double gs = mc.getWindow().getScaleFactor();
			int W = mc.getWindow().getFramebufferWidth(), H = mc.getWindow().getFramebufferHeight();
			if (W <= 0 || H <= 0 || gs <= 0) return;

			float pt = mc.getRenderTickCounter().getTickProgress(false);
			double swing = mc.player.getHandSwingProgress(pt);
			double tan = Math.tan(Math.toRadians(mc.options.getFov().getValue()) / 2.0);
			double aspect = W / (double) H;
			boolean mainRight = mc.options.getMainArm().getValue() == Arm.RIGHT;
			boolean usingItem = mc.player.isUsingItem();

			float pulseF = pulse.on() ? 0.8f + 0.2f * (float) Math.sin(System.currentTimeMillis() / 300.0) : 1f;
			float flash = swingFlash.on() ? 1f + (float) Math.sin(Math.min(1.0, swing) * Math.PI) * 0.6f : 1f;
			int baseA = Math.max(10, Math.min(255, (int) (intensity.f() * 25.5f * pulseF * flash)));

			c.getMatrices().pushMatrix();
			c.getMatrices().scale((float) (1.0 / gs), (float) (1.0 / gs));
			try {
				ItemStack main = mc.player.getMainHandStack();
				if (mainHand.on()) {
					List<double[]> pts = main.isEmpty()
							? armPoints(mainRight, swing, usingItem)
							: itemPoints(main, mainRight, swing, usingItem);
					outline(c, pts, W, H, tan, aspect, baseA);
				}
				ItemStack off = mc.player.getOffHandStack();
				if (offhand.on() && !off.isEmpty()) {
					outline(c, itemPoints(off, !mainRight, 0, false), W, H, tan, aspect, baseA);
				}
			} finally {
				c.getMatrices().popMatrix();
			}
		}

		// ---- geometry ----

		/** Right arm: pivot (-5,2,0), box 4x12x4 px. Left arm: pivot (5,2,0). */
		List<double[]> armPoints(boolean right, double sw, boolean using) {
			double f = right ? 1 : -1;
			double s = using ? 0 : sw;
			double g = Math.sqrt(s);
			double h = -0.3 * Math.sin(g * Math.PI), i = 0.4 * Math.sin(g * Math.PI * 2), j = -0.4 * Math.sin(s * Math.PI);
			Mx m = new Mx();
			m.tr(f * (h + 0.64000005), i - 0.6, j - 0.71999997);
			m.ry(f * 45);
			double k = Math.sin(s * s * Math.PI), l = Math.sin(g * Math.PI);
			m.ry(f * l * 70).rz(f * k * -20);
			m.tr(f * -1, 3.6, 3.5).rz(f * 120).rx(200).ry(f * -135).tr(f * 5.6, 0, 0);
			double x0 = right ? -8 : 4, x1 = right ? -4 : 8;
			List<double[]> out = new ArrayList<>();
			for (double x : new double[]{x0, x1})
				for (double y : new double[]{0, 12})
					for (double z : new double[]{-2, 2})
						out.add(m.apply(x / 16.0, y / 16.0, z / 16.0));
			return out;
		}

		List<double[]> itemPoints(ItemStack st, boolean right, double sw, boolean using) {
			double o = right ? 1 : -1;
			double s = using ? 0 : sw;
			double n = -0.4 * Math.sin(Math.sqrt(s) * Math.PI);
			double mm = 0.2 * Math.sin(Math.sqrt(s) * Math.PI * 2);
			double f = -0.2 * Math.sin(s * Math.PI);
			Mx m = new Mx();
			m.tr(o * n, mm, f);
			m.tr(o * 0.56, -0.52, -0.72);
			if (s > 0) {
				double ff = Math.sin(s * s * Math.PI);
				m.ry(o * (45 + ff * -20));
				double g = Math.sin(Math.sqrt(s) * Math.PI);
				m.rz(o * g * -20).rx(g * -80).ry(o * -45);
			}
			List<double[]> shape;
			if (st.getItem() instanceof BlockItem) {
				m.ry(45).sc(0.4);
				shape = null;
			} else {
				m.tr(1.13 * o / 16.0, 3.2 / 16.0, 1.13 / 16.0).ry(-90).rz(25 * o).sc(0.68);
				shape = spriteShape(st);
			}
			List<double[]> out = new ArrayList<>();
			if (shape == null) {
				for (double x : new double[]{0, 1})
					for (double y : new double[]{0, 1})
						for (double z : new double[]{0, 1})
							out.add(m.apply(x - 0.5, y - 0.5, z - 0.5));
			} else {
				for (double[] p : shape)
					for (double z : new double[]{7.5 / 16.0, 8.5 / 16.0})
						out.add(m.apply(p[0] - 0.5, p[1] - 0.5, z - 0.5));
			}
			return out;
		}

		/** Rough sprite silhouettes (sprite space 0..1) so a sword outlines like a sword, not a square. */
		List<double[]> spriteShape(ItemStack st) {
			if (st.isIn(ItemTags.SWORDS)) {
				return List.of(p(0.02, 0.10), p(0.10, 0.02), p(0.98, 0.90), p(0.90, 0.98),
						p(0.30, 0.10), p(0.10, 0.30));
			}
			if (st.isIn(ItemTags.PICKAXES) || st.isIn(ItemTags.AXES) || st.isIn(ItemTags.SHOVELS) || st.isIn(ItemTags.HOES)) {
				return List.of(p(0.02, 0.10), p(0.10, 0.02), p(0.70, 0.62), p(0.62, 0.70),
						p(0.25, 0.97), p(0.97, 0.97), p(0.97, 0.25));
			}
			return List.of(p(0.06, 0.06), p(0.94, 0.06), p(0.94, 0.94), p(0.06, 0.94));
		}

		static double[] p(double x, double y) {
			return new double[]{x, y};
		}

		// ---- projection + drawing ----

		void outline(DrawContext c, List<double[]> pts3, int W, int H, double tan, double aspect, int baseA) {
			List<double[]> scr = new ArrayList<>();
			final double near = -0.1;
			for (int i = 0; i < pts3.size(); i++) {
				double[] a0 = pts3.get(i);
				if (a0[2] < near) addScr(scr, a0, W, H, tan, aspect);
				for (int j = i + 1; j < pts3.size(); j++) {
					double[] b0 = pts3.get(j);
					if ((a0[2] < near) != (b0[2] < near)) {
						double k = (near - a0[2]) / (b0[2] - a0[2]);
						addScr(scr, new double[]{a0[0] + (b0[0] - a0[0]) * k, a0[1] + (b0[1] - a0[1]) * k, near}, W, H, tan, aspect);
					}
				}
			}
			List<double[]> hull = hull(scr);
			if (hull.size() < 2) return;

			double minX = 1e18, maxX = -1e18, minY = 1e18, maxY = -1e18;
			for (double[] h : hull) {
				minX = Math.min(minX, h[0]);
				maxX = Math.max(maxX, h[0]);
				minY = Math.min(minY, h[1]);
				maxY = Math.max(maxY, h[1]);
			}
			if (maxX < 0 || minX > W || maxY < 0 || minY > H) return;

			int th = thickness.i();
			if (fill.on()) fillHull(c, hull, W, H, Theme.alpha(rgb(0), Math.max(8, baseA / 6)));
			for (int layer = glow.i(); layer >= 0; layer--) {
				int t = th + layer * 2;
				int a = layer == 0 ? baseA : Math.max(6, (int) (baseA * 0.38 / (1 + layer * 0.6)));
				for (int e = 0; e < hull.size(); e++) {
					double[] a0 = hull.get(e), a1 = hull.get((e + 1) % hull.size());
					int col = Theme.alpha(rgb(e), a);
					line(c, a0[0], a0[1], a1[0], a1[1], t, col, W, H);
				}
			}
		}

		static void addScr(List<double[]> out, double[] p, int W, int H, double tan, double aspect) {
			double nx = p[0] / (-p[2] * tan * aspect), ny = p[1] / (-p[2] * tan);
			out.add(new double[]{W / 2.0 * (1 + nx), H / 2.0 * (1 - ny)});
		}

		void line(DrawContext c, double x0, double y0, double x1, double y1, int t, int col, int W, int H) {
			double dist = Math.hypot(x1 - x0, y1 - y0);
			int steps = (int) Math.min(2500, Math.max(1, Math.ceil(dist / Math.max(1, t * 0.7))));
			int half = t / 2;
			for (int i = 0; i <= steps; i++) {
				double k = i / (double) steps;
				int x = (int) Math.round(x0 + (x1 - x0) * k) - half;
				int y = (int) Math.round(y0 + (y1 - y0) * k) - half;
				if (x < -t || y < -t || x > W || y > H) continue;
				c.fill(x, y, x + t, y + t, col);
			}
		}

		void fillHull(DrawContext c, List<double[]> hull, int W, int H, int col) {
			double minY = 1e18, maxY = -1e18;
			for (double[] h : hull) {
				minY = Math.min(minY, h[1]);
				maxY = Math.max(maxY, h[1]);
			}
			int y0 = (int) Math.max(0, minY), y1 = (int) Math.min(H, maxY);
			for (int y = y0; y < y1; y += 3) {
				double lo = 1e18, hi = -1e18;
				for (int e = 0; e < hull.size(); e++) {
					double[] a = hull.get(e), b = hull.get((e + 1) % hull.size());
					if ((a[1] <= y && b[1] > y) || (b[1] <= y && a[1] > y)) {
						double x = a[0] + (y - a[1]) / (b[1] - a[1]) * (b[0] - a[0]);
						lo = Math.min(lo, x);
						hi = Math.max(hi, x);
					}
				}
				if (hi > lo) c.fill((int) Math.max(0, lo), y, (int) Math.min(W, hi), y + 3, col);
			}
		}

		/** Andrew's monotone chain convex hull. */
		static List<double[]> hull(List<double[]> in) {
			List<double[]> p = new ArrayList<>(in);
			p.sort(Comparator.<double[]>comparingDouble(a -> a[0]).thenComparingDouble(a -> a[1]));
			int n = p.size();
			if (n < 3) return p;
			double[][] h = new double[2 * n][];
			int k = 0;
			for (int i = 0; i < n; i++) {
				while (k >= 2 && cross(h[k - 2], h[k - 1], p.get(i)) <= 0) k--;
				h[k++] = p.get(i);
			}
			for (int i = n - 2, t = k + 1; i >= 0; i--) {
				while (k >= t && cross(h[k - 2], h[k - 1], p.get(i)) <= 0) k--;
				h[k++] = p.get(i);
			}
			List<double[]> out = new ArrayList<>();
			for (int i = 0; i < k - 1; i++) out.add(h[i]);
			return out;
		}

		static double cross(double[] o, double[] a, double[] b) {
			return (a[0] - o[0]) * (b[1] - o[1]) - (a[1] - o[1]) * (b[0] - o[0]);
		}
	}

	// ======================= Xray =======================

	/**
	 * Vape-style Xray: every non-ore block stops rendering, every ore (all *_ore + ancient debris) is
	 * drawn on all sides. Hooked in BlockMixin (Block.shouldDrawSide).
	 */
	public static class Xray extends Module {
		public static boolean active;
		private static final Map<Block, Boolean> CACHE = new HashMap<>();

		final Setting.Bool fullbright = bool("Fullbright", true);
		final Setting.Bool debris = bool("Ancient debris", true);
		boolean addedNv;

		public Xray() {
			super("Xray", "Hides every block and shows all ores (Vape style)", Category.RENDER);
		}

		public static boolean visible(BlockState s) {
			Block b = s.getBlock();
			Boolean v = CACHE.get(b);
			if (v == null) {
				String path = Registries.BLOCK.getId(b).getPath();
				v = path.endsWith("_ore") || b == Blocks.ANCIENT_DEBRIS;
				CACHE.put(b, v);
			}
			if (v && b == Blocks.ANCIENT_DEBRIS) {
				Xray x = dev.ousek.module.ModuleManager.get(Xray.class);
				return x == null || x.debris.on();
			}
			return v;
		}

		static void reloadWorld() {
			try {
				if (mc.worldRenderer != null) mc.worldRenderer.reload();
			} catch (Throwable ignored) {
			}
		}

		@Override
		public void onEnable() {
			active = true;
			reloadWorld();
		}

		@Override
		public void onDisable() {
			active = false;
			reloadWorld();
			if (addedNv && mc.player != null) mc.player.removeStatusEffect(StatusEffects.NIGHT_VISION);
			addedNv = false;
		}

		@Override
		public void onTick() {
			active = true;
			if (fullbright.on()) {
				if (!mc.player.hasStatusEffect(StatusEffects.NIGHT_VISION)) addedNv = true;
				mc.player.addStatusEffect(new StatusEffectInstance(StatusEffects.NIGHT_VISION, 400, 0, false, false, false));
			}
		}
	}

	// ======================= Animations =======================

	public static class Animations extends Module {
		final Setting.Mode anim = mode("Animation", "Smoothstep", Anims.NAMES);
		final Setting.Num speed = num("Attack speed", 1.0, 0.25, 4.0, 0.05);

		public Animations() {
			super("Animations", Anims.NAMES.length + " attack animations and adjustable swing speed", Category.RENDER);
		}

		@Override
		public String suffix() {
			return anim.value;
		}

		@Override
		public void onEnable() {
			Anims.active = true;
		}

		@Override
		public void onDisable() {
			Anims.active = false;
		}

		@Override
		public void onTick() {
			Anims.active = true;
			Anims.index = Anims.indexOf(anim.value);
			Anims.speed = speed.get();
		}
	}
}
