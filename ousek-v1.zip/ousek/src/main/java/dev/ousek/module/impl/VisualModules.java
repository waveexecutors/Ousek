package dev.ousek.module.impl;

import dev.ousek.gui.Theme;
import dev.ousek.module.Anims;
import dev.ousek.module.Category;
import dev.ousek.module.Module;
import dev.ousek.setting.Setting;
import net.minecraft.block.Block;
import net.minecraft.block.BlockState;
import net.minecraft.block.Blocks;
import net.minecraft.client.gui.DrawContext;
import net.minecraft.util.Arm;
import net.minecraft.util.math.BlockPos;
import net.minecraft.util.math.Vec3d;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

public final class VisualModules {
	private VisualModules() {
	}

	public static void register(List<Module> list) {
		list.add(new HandGlow());
		list.add(new Xray());
		list.add(new Animations());
	}

	// ---------- HandGlow ----------

	/** Screen-space glow behind your hands. Cheap: a handful of flat bars, no textures, no shaders. */
	public static class HandGlow extends Module {
		final Setting.Mode color = mode("Color", "Accent", "Accent", "Rainbow", "White");
		final Setting.Num size = num("Size", 60, 20, 140, 1);
		final Setting.Num intensity = num("Intensity", 6, 1, 10, 1);
		final Setting.Bool pulse = bool("Pulse", true);
		final Setting.Bool swingReact = bool("React to swing", true);
		final Setting.Bool offhand = bool("Offhand", true);
		final Setting.Bool onlyItem = bool("Only with item", false);
		float swingSm;
		long lastNs;

		public HandGlow() {
			super("HandGlow", "Glow around your hands and held items", Category.RENDER);
		}

		int rgb() {
			if (color.is("Rainbow")) return Theme.rainbow(0);
			if (color.is("White")) return 0xFFFFFF;
			return Theme.accent();
		}

		@Override
		public void onHud(DrawContext c) {
			if (mc.player == null || !mc.options.getPerspective().isFirstPerson()) return;
			long ns = System.nanoTime();
			float dt = lastNs == 0 ? 0.016f : Math.min(0.1f, (ns - lastNs) / 1e9f);
			lastNs = ns;

			float target = swingReact.on() ? (float) Math.sin(mc.player.getHandSwingProgress(1f) * Math.PI) : 0f;
			swingSm += (target - swingSm) * (1f - (float) Math.exp(-18 * dt));

			int w = c.getScaledWindowWidth(), h = c.getScaledWindowHeight();
			boolean left = mc.options.getMainArm().getValue() == Arm.LEFT;
			float k = size.f() / 60f * (h / 240f);
			float pulseF = pulse.on() ? 0.85f + 0.15f * (float) Math.sin(System.currentTimeMillis() / 380.0) : 1f;
			int alphaPer = Math.max(2, Math.min(40, (int) (intensity.f() * 3.2f * pulseF)));
			int rx = (int) (70 * k), ry = (int) (52 * k);
			int col = rgb();

			if (!mc.player.getMainHandStack().isEmpty() || !onlyItem.on()) {
				float dir = left ? 1f : -1f;
				int cx = (int) (w * (left ? 0.22f : 0.78f) + dir * swingSm * w * 0.10f);
				int cy = (int) (h * 0.90f - swingSm * h * 0.16f);
				glow(c, cx, cy, rx, ry, col, alphaPer);
			}
			if (offhand.on() && !mc.player.getOffHandStack().isEmpty()) {
				int cx = (int) (w * (left ? 0.78f : 0.22f));
				int cy = (int) (h * 0.90f);
				glow(c, cx, cy, (int) (rx * 0.8f), (int) (ry * 0.8f), col, alphaPer);
			}
		}

		void glow(DrawContext c, int cx, int cy, int rx, int ry, int rgb, int alphaPer) {
			int layers = 8;
			int argb = (alphaPer << 24) | (rgb & 0xFFFFFF);
			for (int i = 0; i < layers; i++) {
				float f = 1f - i / (float) layers;
				int a = (int) (rx * f), b = (int) (ry * f);
				if (b <= 0 || a <= 0) continue;
				for (int y = -b; y < b; y += 3) {
					double t = 1.0 - (double) (y * y) / (double) (b * b);
					int half = (int) (a * Math.sqrt(Math.max(0, t)));
					if (half <= 0) continue;
					c.fill(cx - half, cy + y, cx + half, cy + y + 3, argb);
				}
			}
		}
	}

	// ---------- Xray (ore overlay) ----------

	/**
	 * Shows ores through walls as markers projected on screen. It scans a few thousand blocks per tick
	 * so it stays smooth. This is an overlay, not see-through textures.
	 */
	public static class Xray extends Module {
		final Setting.Num range = num("Range", 24, 8, 64, 1);
		final Setting.Num scan = num("Scan speed", 3000, 500, 12000, 500);
		final Setting.Bool diamond = bool("Diamond", true);
		final Setting.Bool iron = bool("Iron", false);
		final Setting.Bool gold = bool("Gold", true);
		final Setting.Bool emerald = bool("Emerald", true);
		final Setting.Bool redstone = bool("Redstone", false);
		final Setting.Bool lapis = bool("Lapis", false);
		final Setting.Bool coal = bool("Coal", false);
		final Setting.Bool copper = bool("Copper", false);
		final Setting.Bool debris = bool("Ancient debris", true);
		final Setting.Bool quartz = bool("Quartz", false);
		final Setting.Bool fill = bool("Fill", true);
		final Setting.Bool distance = bool("Distances", true);
		final Map<BlockPos, Integer> found = new HashMap<>();
		int cursor, tickCount;

		public Xray() {
			super("Xray", "Marks ores through walls", Category.RENDER);
		}

		@Override
		public void onDisable() {
			found.clear();
			cursor = 0;
		}

		int colorOf(BlockState s) {
			if (s.isAir()) return 0;
			Block b = s.getBlock();
			if (diamond.on() && (b == Blocks.DIAMOND_ORE || b == Blocks.DEEPSLATE_DIAMOND_ORE)) return 0x3DE8E8;
			if (iron.on() && (b == Blocks.IRON_ORE || b == Blocks.DEEPSLATE_IRON_ORE)) return 0xD8AF93;
			if (gold.on() && (b == Blocks.GOLD_ORE || b == Blocks.DEEPSLATE_GOLD_ORE || b == Blocks.NETHER_GOLD_ORE)) return 0xFFD23D;
			if (emerald.on() && (b == Blocks.EMERALD_ORE || b == Blocks.DEEPSLATE_EMERALD_ORE)) return 0x2BDB6A;
			if (redstone.on() && (b == Blocks.REDSTONE_ORE || b == Blocks.DEEPSLATE_REDSTONE_ORE)) return 0xFF3B3B;
			if (lapis.on() && (b == Blocks.LAPIS_ORE || b == Blocks.DEEPSLATE_LAPIS_ORE)) return 0x3A5BFF;
			if (coal.on() && (b == Blocks.COAL_ORE || b == Blocks.DEEPSLATE_COAL_ORE)) return 0x6A6A6A;
			if (copper.on() && (b == Blocks.COPPER_ORE || b == Blocks.DEEPSLATE_COPPER_ORE)) return 0xE07B4F;
			if (debris.on() && b == Blocks.ANCIENT_DEBRIS) return 0xB5663C;
			if (quartz.on() && b == Blocks.NETHER_QUARTZ_ORE) return 0xEDE6D8;
			return 0;
		}

		@Override
		public void onTick() {
			int r = range.i();
			int size = 2 * r + 1;
			int total = size * size * size;
			BlockPos base = mc.player.getBlockPos();
			BlockPos.Mutable m = new BlockPos.Mutable();
			for (int n = 0; n < scan.i(); n++) {
				int idx = cursor++ % total;
				int x = idx % size - r;
				int y = (idx / size) % size - r;
				int z = idx / (size * size) - r;
				m.set(base.getX() + x, base.getY() + y, base.getZ() + z);
				int col = colorOf(mc.world.getBlockState(m));
				if (col != 0) found.put(m.toImmutable(), col);
			}
			if (cursor >= total) cursor = 0;
			if (++tickCount % 10 == 0) {
				found.entrySet().removeIf(e -> {
					BlockPos p = e.getKey();
					double dx = p.getX() - base.getX(), dy = p.getY() - base.getY(), dz = p.getZ() - base.getZ();
					return Math.sqrt(dx * dx + dy * dy + dz * dz) > r + 4 || colorOf(mc.world.getBlockState(p)) == 0;
				});
			}
		}

		@Override
		public void onHud(DrawContext c) {
			if (mc.player == null || found.isEmpty()) return;
			int W = c.getScaledWindowWidth(), H = c.getScaledWindowHeight();
			Vec3d eye = mc.player.getEyePos();
			double ry = Math.toRadians(mc.player.getYaw()), rp = Math.toRadians(mc.player.getPitch());
			double fx = -Math.sin(ry) * Math.cos(rp), fy = -Math.sin(rp), fz = Math.cos(ry) * Math.cos(rp);
			double rx = -Math.cos(ry), rz = -Math.sin(ry);
			double ux = -rz * fy, uy = rz * fx - rx * fz, uz = rx * fy;
			double tan = Math.tan(Math.toRadians(mc.options.getFov().getValue()) / 2.0);
			double aspect = W / (double) H;
			int drawn = 0;
			for (Map.Entry<BlockPos, Integer> e : found.entrySet()) {
				if (drawn > 300) break;
				BlockPos p = e.getKey();
				double dx = p.getX() + 0.5 - eye.x, dy = p.getY() + 0.5 - eye.y, dz = p.getZ() + 0.5 - eye.z;
				double zc = dx * fx + dy * fy + dz * fz;
				if (zc < 0.5) continue;
				double xc = dx * rx + dz * rz;
				double yc = dx * ux + dy * uy + dz * uz;
				double nx = xc / (zc * tan * aspect), ny = yc / (zc * tan);
				if (Math.abs(nx) > 1.15 || Math.abs(ny) > 1.15) continue;
				int sx = (int) (W / 2.0 * (1 + nx)), sy = (int) (H / 2.0 * (1 - ny));
				int half = (int) Math.max(2, H / (2 * tan * zc) * 0.5);
				half = Math.min(half, 40);
				int col = 0xFF000000 | e.getValue();
				if (fill.on()) c.fill(sx - half, sy - half, sx + half, sy + half, Theme.alpha(col, 0x38));
				c.fill(sx - half, sy - half, sx + half, sy - half + 1, col);
				c.fill(sx - half, sy + half - 1, sx + half, sy + half, col);
				c.fill(sx - half, sy - half, sx - half + 1, sy + half, col);
				c.fill(sx + half - 1, sy - half, sx + half, sy + half, col);
				if (distance.on() && zc < 40) {
					String s = (int) zc + "m";
					c.drawText(mc.textRenderer, s, sx - mc.textRenderer.getWidth(s) / 2, sy + half + 2, 0xFFFFFFFF, true);
				}
				drawn++;
			}
		}
	}

	// ---------- Animations ----------

	public static class Animations extends Module {
		final Setting.Mode anim = mode("Animation", "Smoothstep", Anims.NAMES);
		final Setting.Num speed = num("Attack speed", 1.0, 0.25, 4.0, 0.05);

		public Animations() {
			super("Animations", "42 attack animations and adjustable swing speed", Category.RENDER);
		}

		@Override
		public String suffix() {
			return anim.value;
		}

		@Override
		public void onEnable() {
			Anims.active = true;
		}

		@Override
		public void onDisable() {
			Anims.active = false;
		}

		@Override
		public void onTick() {
			Anims.active = true;
			Anims.index = Anims.indexOf(anim.value);
			Anims.speed = speed.get();
		}
	}
}
