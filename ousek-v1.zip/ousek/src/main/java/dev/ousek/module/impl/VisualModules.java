package dev.ousek.module.impl;

import dev.ousek.gui.Theme;
import dev.ousek.module.Anims;
import dev.ousek.module.Category;
import dev.ousek.module.Module;
import dev.ousek.module.ModuleManager;
import dev.ousek.setting.Setting;
import net.minecraft.block.Block;
import net.minecraft.block.BlockState;
import net.minecraft.block.Blocks;
import net.minecraft.client.render.VertexConsumer;
import net.minecraft.util.Hand;

import java.lang.reflect.InvocationHandler;
import java.lang.reflect.Method;
import java.lang.reflect.Proxy;
import java.util.IdentityHashMap;
import java.util.List;

public final class VisualModules {
	private VisualModules() {
	}

	public static void register(List<Module> list) {
		list.add(new HandGlow());
		list.add(new Xray());
		list.add(new Animations());
	}

	// ---------- HandGlow ----------

	/** Adds a real render-queue outline to the first-person arm and item models. */
	public static class HandGlow extends Module {
		private static final ThreadLocal<Hand> RENDERING_HAND = new ThreadLocal<>();
		final Setting.Mode color = mode("Color", "Accent", "Accent", "Rainbow", "White", "Red", "Blue", "Purple");
		final Setting.Bool offhand = bool("Offhand", true);
		final Setting.Bool onlyItem = bool("Only with item", false);

		public HandGlow() {
			super("HandGlow", "Traces the 3D hand and held-item silhouettes", Category.RENDER);
		}

		public static void beginHandRender(Hand hand) {
			RENDERING_HAND.set(hand);
		}

		public static void endHandRender() {
			RENDERING_HAND.remove();
		}

		/** Zero means no outline should be applied to the current queued model. */
		public static int currentOutlineColor() {
			HandGlow module = ModuleManager.get(HandGlow.class);
			Hand hand = RENDERING_HAND.get();
			if (module == null || !module.enabled || hand == null) return 0;
			if (hand == Hand.OFF_HAND && !module.offhand.on()) return 0;

			var player = net.minecraft.client.MinecraftClient.getInstance().player;
			if (player == null) return 0;
			if (module.onlyItem.on()) {
				if (hand == Hand.MAIN_HAND && player.getMainHandStack().isEmpty()) return 0;
				if (hand == Hand.OFF_HAND && player.getOffHandStack().isEmpty()) return 0;
			}

			int rgb = switch (module.color.value) {
				case "Rainbow" -> Theme.rainbow(0) & 0xFFFFFF;
				case "White" -> 0xFFFFFF;
				case "Red" -> 0xFF4242;
				case "Blue" -> 0x49A8FF;
				case "Purple" -> 0xB66BFF;
				default -> Theme.accent() & 0xFFFFFF;
			};
			return 0xFF000000 | rgb;
		}
	}

	// ---------- Xray: real translucent block geometry ----------

	public static class Xray extends Module {
		private static final ThreadLocal<Boolean> FADE_CURRENT_BLOCK = ThreadLocal.withInitial(() -> false);
		private static final ThreadLocal<IdentityHashMap<VertexConsumer, VertexConsumer>> WRAPPERS =
				ThreadLocal.withInitial(IdentityHashMap::new);

		final Setting.Num transparency = num("Transparency %", 85, 0, 95, 1);

		public Xray() {
			super("Xray", "Makes terrain 85% transparent while keeping every ore solid", Category.RENDER);
		}

		public static boolean shouldMakeTransparent(BlockState state) {
			Xray module = ModuleManager.get(Xray.class);
			return module != null && module.enabled && state != null && !state.isAir()
					&& module.transparency.i() > 0 && !isOre(state);
		}

		/** Covers overworld ores, deepslate ores, Nether ores and ancient debris. */
		public static boolean isOre(BlockState state) {
			if (state == null) return false;
			Block block = state.getBlock();
			return block == Blocks.COAL_ORE || block == Blocks.DEEPSLATE_COAL_ORE
					|| block == Blocks.IRON_ORE || block == Blocks.DEEPSLATE_IRON_ORE
					|| block == Blocks.COPPER_ORE || block == Blocks.DEEPSLATE_COPPER_ORE
					|| block == Blocks.GOLD_ORE || block == Blocks.DEEPSLATE_GOLD_ORE
					|| block == Blocks.REDSTONE_ORE || block == Blocks.DEEPSLATE_REDSTONE_ORE
					|| block == Blocks.LAPIS_ORE || block == Blocks.DEEPSLATE_LAPIS_ORE
					|| block == Blocks.DIAMOND_ORE || block == Blocks.DEEPSLATE_DIAMOND_ORE
					|| block == Blocks.EMERALD_ORE || block == Blocks.DEEPSLATE_EMERALD_ORE
					|| block == Blocks.NETHER_GOLD_ORE || block == Blocks.NETHER_QUARTZ_ORE
					|| block == Blocks.ANCIENT_DEBRIS;
		}

		public static void beginBlock(BlockState state) {
			FADE_CURRENT_BLOCK.set(shouldMakeTransparent(state));
		}

		public static void endBlock() {
			FADE_CURRENT_BLOCK.remove();
		}

		/**
		 * Wraps block vertices so their original texture/tint is preserved while alpha is
		 * multiplied by the configured opacity. Wrappers are cached per render thread.
		 */
		public static VertexConsumer wrapVertexConsumer(VertexConsumer original) {
			if (!FADE_CURRENT_BLOCK.get()) return original;
			IdentityHashMap<VertexConsumer, VertexConsumer> cache = WRAPPERS.get();
			// Vertex consumers are reused for many blocks while a chunk is rebuilt. Keep a
			// small per-thread cache so Xray does not allocate a reflection proxy per block.
			if (cache.size() > 64) cache.clear();
			return cache.computeIfAbsent(original, Xray::createAlphaConsumer);
		}

		private static float opacityFactor() {
			Xray module = ModuleManager.get(Xray.class);
			return module == null ? 0.15f : (100f - module.transparency.f()) / 100f;
		}

		private static VertexConsumer createAlphaConsumer(VertexConsumer delegate) {
			InvocationHandler handler = (proxy, method, args) -> {
				String name = method.getName();
				if (args != null) {
					if (name.equals("color") && args.length == 1 && args[0] instanceof Integer argb) {
						args[0] = scaleAlpha(argb, opacityFactor());
					} else if (name.equals("color") && args.length == 4 && args[3] instanceof Float a) {
						args[3] = a * opacityFactor();
					} else if (name.equals("color") && args.length == 4 && args[3] instanceof Integer a) {
						args[3] = Math.max(0, Math.min(255, Math.round(a * opacityFactor())));
					} else if (name.equals("vertex") && args.length == 11 && args[3] instanceof Integer argb) {
						args[3] = scaleAlpha(argb, opacityFactor());
					} else if (name.equals("quad") && args.length == 9 && args[6] instanceof Float a) {
						args[6] = a * opacityFactor();
					} else if (name.equals("quad") && args.length == 8 && args[5] instanceof Float a) {
						args[5] = a * opacityFactor();
					}
				}

				try {
					Object result = method.invoke(delegate, args);
					return result == delegate ? proxy : result;
				} catch (java.lang.reflect.InvocationTargetException e) {
					throw e.getCause();
				}
			};
			return (VertexConsumer) Proxy.newProxyInstance(VertexConsumer.class.getClassLoader(),
					new Class<?>[]{VertexConsumer.class}, handler);
		}

		private static int scaleAlpha(int argb, float multiplier) {
			int a = (argb >>> 24) & 0xFF;
			int scaled = Math.max(0, Math.min(255, Math.round(a * multiplier)));
			return (argb & 0x00FFFFFF) | (scaled << 24);
		}

		private void refreshChunks() {
			if (mc.world != null && mc.worldRenderer != null) mc.worldRenderer.reload();
		}

		@Override
		public void onEnable() {
			refreshChunks();
		}

		@Override
		public void onDisable() {
			refreshChunks();
		}
	}

	// ---------- Animations ----------

	public static class Animations extends Module {
		final Setting.Mode anim = mode("Animation", "Smoothstep", Anims.NAMES);
		final Setting.Num speed = num("Attack speed", 1.0, 0.25, 4.0, 0.05);

		public Animations() {
			super("Animations", "60+ custom first-person swing animations and speed control", Category.RENDER);
		}

		@Override
		public String suffix() {
			return anim.value;
		}

		@Override
		public void onEnable() {
			Anims.active = true;
		}

		@Override
		public void onDisable() {
			Anims.active = false;
			Anims.index = 0;
			Anims.speed = 1.0;
		}

		@Override
		public void onTick() {
			Anims.active = true;
			Anims.index = Anims.indexOf(anim.value);
			Anims.speed = speed.get();
		}
	}
}
