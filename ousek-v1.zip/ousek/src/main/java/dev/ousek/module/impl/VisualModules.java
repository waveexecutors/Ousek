package dev.ousek.module.impl;

import dev.ousek.gui.Theme;
import dev.ousek.module.Anims;
import dev.ousek.module.Category;
import dev.ousek.module.Module;
import dev.ousek.setting.Setting;
import net.minecraft.block.Block;
import net.minecraft.block.BlockState;
import net.minecraft.block.Blocks;
import net.minecraft.client.gui.DrawContext;
import net.minecraft.entity.effect.StatusEffectInstance;
import net.minecraft.entity.effect.StatusEffects;
import net.minecraft.item.BlockItem;
import net.minecraft.item.ItemStack;
import net.minecraft.registry.Registries;
import net.minecraft.registry.tag.ItemTags;
import net.minecraft.util.Arm;

import java.util.ArrayList;
import java.util.Comparator;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

public final class VisualModules {
	private VisualModules() {
	}

	public static void register(List<Module> list) {
		list.add(new Xray());
		list.add(new Animations());
	}


	/** Tiny 4x4 matrix stack that replays vanilla's first-person hand/item transforms. */
	static final class Mx {
		final double[] m = {1, 0, 0, 0, 0, 1, 0, 0, 0, 0, 1, 0, 0, 0, 0, 1};

		Mx mul(double[] b) {
			double[] r = new double[16];
			for (int i = 0; i < 4; i++)
				for (int j = 0; j < 4; j++) {
					double s = 0;
					for (int k = 0; k < 4; k++) s += m[i * 4 + k] * b[k * 4 + j];
					r[i * 4 + j] = s;
				}
			System.arraycopy(r, 0, m, 0, 16);
			return this;
		}

		Mx tr(double x, double y, double z) {
			return mul(new double[]{1, 0, 0, x, 0, 1, 0, y, 0, 0, 1, z, 0, 0, 0, 1});
		}

		Mx sc(double k) {
			return mul(new double[]{k, 0, 0, 0, 0, k, 0, 0, 0, 0, k, 0, 0, 0, 0, 1});
		}

		Mx rx(double deg) {
			double a = Math.toRadians(deg), c = Math.cos(a), s = Math.sin(a);
			return mul(new double[]{1, 0, 0, 0, 0, c, -s, 0, 0, s, c, 0, 0, 0, 0, 1});
		}

		Mx ry(double deg) {
			double a = Math.toRadians(deg), c = Math.cos(a), s = Math.sin(a);
			return mul(new double[]{c, 0, s, 0, 0, 1, 0, 0, -s, 0, c, 0, 0, 0, 0, 1});
		}

		Mx rz(double deg) {
			double a = Math.toRadians(deg), c = Math.cos(a), s = Math.sin(a);
			return mul(new double[]{c, -s, 0, 0, s, c, 0, 0, 0, 0, 1, 0, 0, 0, 0, 1});
		}

		double[] apply(double x, double y, double z) {
			return new double[]{
					m[0] * x + m[1] * y + m[2] * z + m[3],
					m[4] * x + m[5] * y + m[6] * z + m[7],
					m[8] * x + m[9] * y + m[10] * z + m[11]};
		}
	}

	/**
	 * Outlines your first-person hand / held item. It replays the exact transforms vanilla uses
	 * (equip offset, swing offset, display transform, arm model box) and projects the real 3D shape
	 * to the screen, so the outline follows the hand and the item through every swing animation
	 * (including the Animations module).
	 */
	// ======================= Xray =======================

	/**
	 * Vape-style Xray: every non-ore block stops rendering, every ore (all *_ore + ancient debris) is
	 * drawn on all sides. Hooked in BlockMixin (Block.shouldDrawSide).
	 */
	public static class Xray extends Module {
		public static boolean active;
		private static final Map<Block, Boolean> CACHE = new HashMap<>();

		final Setting.Bool fullbright = bool("Fullbright", true);
		final Setting.Bool debris = bool("Ancient debris", true);
		boolean addedNv;

		public Xray() {
			super("Xray", "Hides every block and shows all ores (Vape style)", Category.RENDER);
		}

		public static boolean visible(BlockState s) {
			Block b = s.getBlock();
			Boolean v = CACHE.get(b);
			if (v == null) {
				String path = Registries.BLOCK.getId(b).getPath();
				v = path.endsWith("_ore") || b == Blocks.ANCIENT_DEBRIS;
				CACHE.put(b, v);
			}
			if (v && b == Blocks.ANCIENT_DEBRIS) {
				Xray x = dev.ousek.module.ModuleManager.get(Xray.class);
				return x == null || x.debris.on();
			}
			return v;
		}

		static void reloadWorld() {
			try {
				if (mc.worldRenderer != null) mc.worldRenderer.reload();
			} catch (Throwable ignored) {
			}
		}

		@Override
		public void onEnable() {
			active = true;
			reloadWorld();
		}

		@Override
		public void onDisable() {
			active = false;
			reloadWorld();
			if (addedNv && mc.player != null) mc.player.removeStatusEffect(StatusEffects.NIGHT_VISION);
			addedNv = false;
		}

		@Override
		public void onTick() {
			active = true;
			if (fullbright.on()) {
				if (!mc.player.hasStatusEffect(StatusEffects.NIGHT_VISION)) addedNv = true;
				mc.player.addStatusEffect(new StatusEffectInstance(StatusEffects.NIGHT_VISION, 400, 0, false, false, false));
			}
		}
	}

	// ======================= Animations =======================

	public static class Animations extends Module {
		final Setting.Mode anim = mode("Animation", "Smoothstep", Anims.NAMES);
		final Setting.Num speed = num("Attack speed", 1.0, 0.25, 4.0, 0.05);

		public Animations() {
			super("Animations", Anims.NAMES.length + " attack animations and adjustable swing speed", Category.RENDER);
		}

		@Override
		public String suffix() {
			return anim.value;
		}

		@Override
		public void onEnable() {
			Anims.active = true;
		}

		@Override
		public void onDisable() {
			Anims.active = false;
		}

		@Override
		public void onTick() {
			Anims.active = true;
			Anims.index = Anims.indexOf(anim.value);
			Anims.speed = speed.get();
		}
	}
}
