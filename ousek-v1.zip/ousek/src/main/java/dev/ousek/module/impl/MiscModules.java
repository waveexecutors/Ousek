package dev.ousek.module.impl;

import dev.ousek.module.Category;
import dev.ousek.module.Module;
import dev.ousek.module.ModuleManager;
import dev.ousek.setting.Setting;
import net.minecraft.text.Text;

import java.util.List;
import java.util.Random;

public final class MiscModules {
	private MiscModules() {
	}

	public static void register(List<Module> list) {
		list.add(new ChatSpam());
		list.add(new AutoGG());
		list.add(new AutoLog());
		list.add(new AntiAFK());
		list.add(new Panic());
	}

	public static class ChatSpam extends Module {
		final Setting.Mode text = mode("Message", "gg", "gg", "Ousek v1", "hello", "ez");
		final Setting.Num delay = num("Delay (s)", 5, 1, 30, 1);
		int ticks;

		public ChatSpam() {
			super("ChatSpam", "Repeats a chat message", Category.MISC);
		}

		@Override
		public void onTick() {
			if (++ticks >= delay.i() * 20) {
				ticks = 0;
				if (mc.getNetworkHandler() != null) mc.getNetworkHandler().sendChatMessage(text.value);
			}
		}
	}

	public static class AutoGG extends Module {
		final Setting.Num delay = num("Delay (ticks)", 20, 0, 100, 5);

		public AutoGG() {
			super("AutoGG", "Says gg when a game ends", Category.MISC);
		}

		@Override
		public void onChat(String m) {
			String l = m.toLowerCase();
			if (l.contains("won the game") || l.contains("winner") || l.contains("victory")) {
				ModuleManager.later(delay.i(), () -> {
					if (mc.getNetworkHandler() != null) mc.getNetworkHandler().sendChatMessage("gg");
				});
			}
		}
	}

	public static class AutoLog extends Module {
		final Setting.Num health = num("Health", 6, 1, 19, 1);

		public AutoLog() {
			super("AutoLog", "Disconnects at low health", Category.MISC);
		}

		@Override
		public void onTick() {
			if (mc.player.getHealth() <= health.f() && mc.getNetworkHandler() != null) {
				mc.getNetworkHandler().getConnection().disconnect(Text.literal("[Ousek] AutoLog at low health"));
				setEnabled(false);
			}
		}
	}

	public static class AntiAFK extends Module {
		final Random rng = new Random();
		int ticks;

		public AntiAFK() {
			super("AntiAFK", "Stops you being kicked for idling", Category.MISC);
		}

		@Override
		public void onTick() {
			if (++ticks < 200) return;
			ticks = 0;
			if (rng.nextBoolean()) mc.player.jump();
			else mc.player.setYaw(mc.player.getYaw() + rng.nextInt(40) - 20);
		}
	}

	public static class Panic extends Module {
		public Panic() {
			super("Panic", "Turns every module off", Category.MISC);
		}

		@Override
		public void onEnable() {
			for (Module m : ModuleManager.modules) {
				if (m != this && m.category != Category.HUD && m.category != Category.CLIENT) m.setEnabled(false);
			}
			enabled = false;
		}
	}
}
