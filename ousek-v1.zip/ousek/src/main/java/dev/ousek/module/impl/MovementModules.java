package dev.ousek.module.impl;

import dev.ousek.mixin.LivingEntityAccessor;
import dev.ousek.module.Category;
import dev.ousek.module.Module;
import dev.ousek.module.Util;
import dev.ousek.setting.Setting;
import net.minecraft.entity.attribute.EntityAttributeInstance;
import net.minecraft.entity.attribute.EntityAttributes;
import net.minecraft.network.packet.c2s.play.PlayerMoveC2SPacket;
import net.minecraft.util.math.Box;
import net.minecraft.util.math.Vec3d;

import java.util.List;

public final class MovementModules {
	private MovementModules() {
	}

	public static void register(List<Module> list) {
		list.add(new Sprint());
		list.add(new Fly());
		list.add(new Speed());
		list.add(new BHop());
		list.add(new Step());
		list.add(new NoFall());
		list.add(new Jesus());
		list.add(new Spider());
		list.add(new Glide());
		list.add(new HighJump());
		list.add(new LongJump());
		list.add(new AutoWalk());
		list.add(new Sneak());
		list.add(new NoJumpDelay());
		list.add(new Parkour());
		list.add(new AirJump());
	}

	public static class Sprint extends Module {
		public Sprint() {
			super("Sprint", "Always sprint while moving forward", Category.MOVEMENT);
		}

		@Override
		public void onTick() {
			if (mc.options.forwardKey.isPressed() && !mc.player.horizontalCollision && !mc.player.isSneaking()) {
				mc.player.setSprinting(true);
			}
		}
	}

	public static class Fly extends Module {
		final Setting.Mode mode = mode("Mode", "Motion", "Motion", "Vanilla");
		final Setting.Num speed = num("Speed", 1.0, 0.1, 5, 0.1);

		public Fly() {
			super("Fly", "Lets you fly", Category.MOVEMENT);
		}

		@Override
		public String suffix() {
			return mode.value;
		}

		@Override
		public void onDisable() {
			if (mc.player != null && !mc.player.isCreative() && !mc.player.isSpectator()) {
				mc.player.getAbilities().allowFlying = false;
				mc.player.getAbilities().flying = false;
			}
		}

		@Override
		public void onTick() {
			if (mode.is("Vanilla")) {
				mc.player.getAbilities().allowFlying = true;
				mc.player.getAbilities().flying = true;
				mc.player.getAbilities().setFlySpeed(speed.f() / 10f);
				return;
			}
			double y = mc.options.jumpKey.isPressed() ? speed.get() * 0.5
					: mc.options.sneakKey.isPressed() ? -speed.get() * 0.5 : 0;
			Util.setSpeed(speed.get());
			Vec3d v = mc.player.getVelocity();
			mc.player.setVelocity(v.x, y, v.z);
			mc.player.fallDistance = 0;
		}
	}

	public static class Speed extends Module {
		final Setting.Num speed = num("Speed", 0.35, 0.1, 2, 0.01);
		final Setting.Bool ground = bool("Only on ground", false);

		public Speed() {
			super("Speed", "Moves faster", Category.MOVEMENT);
		}

		@Override
		public void onTick() {
			if (!Util.moving()) return;
			if (ground.on() && !mc.player.isOnGround()) return;
			Util.setSpeed(speed.get());
		}
	}

	public static class BHop extends Module {
		final Setting.Num speed = num("Speed", 0.4, 0.1, 2, 0.01);

		public BHop() {
			super("BHop", "Bunny hops automatically", Category.MOVEMENT);
		}

		@Override
		public void onTick() {
			if (!Util.moving()) return;
			if (mc.player.isOnGround()) mc.player.jump();
			Util.setSpeed(speed.get());
		}
	}

	public static class Step extends Module {
		final Setting.Num height = num("Height", 1.0, 0.6, 2.5, 0.1);

		public Step() {
			super("Step", "Step up blocks", Category.MOVEMENT);
		}

		@Override
		public void onTick() {
			EntityAttributeInstance a = mc.player.getAttributeInstance(EntityAttributes.STEP_HEIGHT);
			if (a != null) a.setBaseValue(height.get());
		}

		@Override
		public void onDisable() {
			if (mc.player == null) return;
			EntityAttributeInstance a = mc.player.getAttributeInstance(EntityAttributes.STEP_HEIGHT);
			if (a != null) a.setBaseValue(0.6);
		}
	}

	public static class NoFall extends Module {
		public NoFall() {
			super("NoFall", "Prevents fall damage", Category.MOVEMENT);
		}

		@Override
		public void onTick() {
			if (mc.player.fallDistance > 2.5 && !mc.player.isOnGround() && mc.getNetworkHandler() != null) {
				mc.getNetworkHandler().sendPacket(new PlayerMoveC2SPacket.OnGroundOnly(true, mc.player.horizontalCollision));
				mc.player.fallDistance = 0;
			}
		}
	}

	public static class Jesus extends Module {
		public Jesus() {
			super("Jesus", "Walk on liquids", Category.MOVEMENT);
		}

		@Override
		public void onTick() {
			if (mc.player.isSneaking()) return;
			if (mc.player.isTouchingWater() || mc.player.isInLava()) {
				Vec3d v = mc.player.getVelocity();
				mc.player.setVelocity(v.x, Math.max(v.y, 0.12), v.z);
			}
		}
	}

	public static class Spider extends Module {
		public Spider() {
			super("Spider", "Climb walls", Category.MOVEMENT);
		}

		@Override
		public void onTick() {
			if (mc.player.horizontalCollision) {
				Vec3d v = mc.player.getVelocity();
				mc.player.setVelocity(v.x, 0.22, v.z);
			}
		}
	}

	public static class Glide extends Module {
		final Setting.Num fall = num("Fall speed", 0.05, 0.01, 0.5, 0.01);

		public Glide() {
			super("Glide", "Slows your fall", Category.MOVEMENT);
		}

		@Override
		public void onTick() {
			Vec3d v = mc.player.getVelocity();
			if (v.y < -fall.get() && !mc.player.isOnGround() && !mc.player.getAbilities().flying) {
				mc.player.setVelocity(v.x, -fall.get(), v.z);
			}
		}
	}

	public static class HighJump extends Module {
		final Setting.Num height = num("Power", 0.8, 0.42, 3, 0.01);

		public HighJump() {
			super("HighJump", "Jump higher", Category.MOVEMENT);
		}

		@Override
		public void onTick() {
			if (mc.options.jumpKey.isPressed() && mc.player.isOnGround()) {
				Vec3d v = mc.player.getVelocity();
				mc.player.setVelocity(v.x, height.get(), v.z);
			}
		}
	}

	public static class LongJump extends Module {
		final Setting.Num boost = num("Boost", 0.8, 0.2, 3, 0.05);

		public LongJump() {
			super("LongJump", "Jump farther", Category.MOVEMENT);
		}

		@Override
		public void onTick() {
			if (mc.options.jumpKey.isPressed() && mc.player.isOnGround() && Util.moving()) {
				Util.setSpeed(boost.get());
			}
		}
	}

	public static class AutoWalk extends Module {
		public AutoWalk() {
			super("AutoWalk", "Holds the forward key", Category.MOVEMENT);
		}

		@Override
		public void onTick() {
			mc.options.forwardKey.setPressed(true);
		}

		@Override
		public void onDisable() {
			mc.options.forwardKey.setPressed(false);
		}
	}

	public static class Sneak extends Module {
		public Sneak() {
			super("Sneak", "Holds the sneak key", Category.MOVEMENT);
		}

		@Override
		public void onTick() {
			mc.options.sneakKey.setPressed(true);
		}

		@Override
		public void onDisable() {
			mc.options.sneakKey.setPressed(false);
		}
	}

	public static class NoJumpDelay extends Module {
		public NoJumpDelay() {
			super("NoJumpDelay", "Removes the jump cooldown", Category.MOVEMENT);
		}

		@Override
		public void onTick() {
			((LivingEntityAccessor) mc.player).ousek$setJumpingCooldown(0);
		}
	}

	public static class Parkour extends Module {
		public Parkour() {
			super("Parkour", "Jumps at the edge of blocks", Category.MOVEMENT);
		}

		@Override
		public void onTick() {
			if (!mc.player.isOnGround() || mc.player.isSneaking() || !Util.moving()) return;
			Vec3d v = mc.player.getVelocity();
			Box next = mc.player.getBoundingBox().offset(v.x * 2, -1.0, v.z * 2);
			if (!mc.world.getBlockCollisions(mc.player, next).iterator().hasNext()) {
				mc.player.jump();
			}
		}
	}

	public static class AirJump extends Module {
		boolean prev;

		public AirJump() {
			super("AirJump", "Jump again in mid-air", Category.MOVEMENT);
		}

		@Override
		public void onTick() {
			boolean down = mc.options.jumpKey.isPressed();
			if (down && !prev && !mc.player.isOnGround() && mc.currentScreen == null) {
				Vec3d v = mc.player.getVelocity();
				mc.player.setVelocity(v.x, 0.42, v.z);
				mc.player.fallDistance = 0;
			}
			prev = down;
		}
	}
}
