package dev.ousek.module.impl;

import net.minecraft.client.MinecraftClient;
import net.minecraft.network.packet.Packet;
import net.minecraft.network.packet.c2s.play.PlayerMoveC2SPacket;

import java.util.ArrayList;
import java.util.List;

/** Holds outgoing packets for FakeLag. The hook lives in ClientConnectionMixin. */
public final class PacketDelay {
	public static final List<Packet<?>> queue = new ArrayList<>();
	public static volatile boolean active;
	public static volatile boolean releasing;
	public static boolean movementOnly;

	private PacketDelay() {
	}

	public static boolean shouldHold(Packet<?> p) {
		if (!active || releasing) return false;
		return !movementOnly || p instanceof PlayerMoveC2SPacket;
	}

	public static void hold(Packet<?> p) {
		synchronized (queue) {
			queue.add(p);
		}
	}

	public static void flush() {
		List<Packet<?>> copy;
		synchronized (queue) {
			copy = new ArrayList<>(queue);
			queue.clear();
		}
		var handler = MinecraftClient.getInstance().getNetworkHandler();
		if (handler == null || copy.isEmpty()) return;
		releasing = true;
		try {
			for (Packet<?> p : copy) handler.sendPacket(p);
		} finally {
			releasing = false;
		}
	}

	public static int size() {
		synchronized (queue) {
			return queue.size();
		}
	}
}
