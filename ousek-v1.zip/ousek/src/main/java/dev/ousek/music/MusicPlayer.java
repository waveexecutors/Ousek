package dev.ousek.music;

import com.google.gson.JsonArray;
import com.google.gson.JsonElement;
import com.google.gson.JsonObject;
import com.google.gson.JsonParser;
import dev.ousek.module.impl.WindowModules;
import javazoom.jl.decoder.Bitstream;
import javazoom.jl.decoder.Decoder;
import javazoom.jl.decoder.Header;
import javazoom.jl.decoder.SampleBuffer;

import net.fabricmc.loader.api.FabricLoader;
import org.lwjgl.openal.AL10;
import org.lwjgl.openal.ALC10;

import javax.sound.sampled.AudioFormat;
import javax.sound.sampled.AudioSystem;
import javax.sound.sampled.SourceDataLine;
import java.io.BufferedInputStream;
import java.io.ByteArrayOutputStream;
import java.io.InputStream;
import java.nio.ByteBuffer;
import java.nio.ByteOrder;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.StandardOpenOption;
import java.util.ArrayDeque;
import java.util.function.BooleanSupplier;
import java.net.URI;
import java.net.URLEncoder;
import java.net.http.HttpClient;
import java.net.http.HttpRequest;
import java.net.http.HttpResponse;
import java.nio.charset.StandardCharsets;
import java.time.Duration;
import java.util.ArrayList;
import java.util.List;
import java.util.concurrent.atomic.AtomicInteger;

/**
 * Streams MP3s from free, key-less APIs: Audius (full songs, includes NCS) and Deezer (30s previews
 * of commercial songs). Decoding is done with JLayer, output through javax.sound.
 */
public final class MusicPlayer {
	public record Track(String title, String artist, int seconds, String url, String source) {
	}

	private static final String APP = "OUSEK";
	private static final HttpClient HTTP = HttpClient.newBuilder()
			.followRedirects(HttpClient.Redirect.NORMAL)
			.connectTimeout(Duration.ofSeconds(10))
			.build();
	private static final AtomicInteger GEN = new AtomicInteger();

	public static volatile List<Track> results = List.of();
	public static volatile String status = "Type something and press Enter";
	public static volatile boolean searching;
	public static volatile Track current;
	public static volatile int currentIndex = -1;
	public static volatile boolean paused;
	public static volatile boolean playing;
	public static volatile long posMs;
	public static volatile long totalMs;

	private MusicPlayer() {
	}

	// ---------- search ----------

	public static void search(String query, String source) {
		String q = query == null ? "" : query.trim();
		if (q.isEmpty()) {
			status = "Type a song or artist first";
			return;
		}
		searching = true;
		status = q.startsWith("@") ? "Loading..." : "Searching...";
		Thread t = new Thread(() -> {
			List<Track> out = new ArrayList<>();
			String err = "";
			if (q.startsWith("@")) {
				try {
					out.addAll(browse(q));
				} catch (Throwable e) {
					err = " (" + brief(e) + ")";
				}
				results = List.copyOf(out);
				searching = false;
				status = out.isEmpty() ? "Nothing loaded." + err : out.size() + " tracks";
				return;
			}
			boolean audius = !source.startsWith("Deezer");
			boolean deezer = !source.startsWith("Audius");
			if (audius) {
				try {
					out.addAll(audius(q));
				} catch (Throwable e) {
					err += " Audius failed.";
				}
			}
			if (deezer && (source.startsWith("Deezer") || out.size() < 25)) {
				try {
					out.addAll(deezer(q));
				} catch (Throwable e) {
					err += " Deezer failed.";
				}
			}
			results = List.copyOf(out);
			searching = false;
			status = out.isEmpty() ? "No results." + err : out.size() + " results" + err;
		}, "ousek-music-search");
		t.setDaemon(true);
		t.start();
	}

	private static String get(String url) throws Exception {
		HttpRequest req = HttpRequest.newBuilder(URI.create(url))
				.timeout(Duration.ofSeconds(12))
				.header("User-Agent", "Ousek/1.0")
				.GET().build();
		HttpResponse<String> r = HTTP.send(req, HttpResponse.BodyHandlers.ofString(StandardCharsets.UTF_8));
		if (r.statusCode() != 200) throw new IllegalStateException("HTTP " + r.statusCode());
		return r.body();
	}

	private static String enc(String s) {
		return URLEncoder.encode(s, StandardCharsets.UTF_8);
	}

	/** Keyless charts: Audius trending, Deezer global chart and Deezer playlists (TikTok / viral / hits, 30s previews). */
	private static List<Track> browse(String q) throws Exception {
		switch (q) {
			case "@trending": {
				String body = get("https://api.audius.co/v1/tracks/trending?limit=40&app_name=" + APP);
				return audiusList(body);
			}
			case "@charts":
				return deezerList(get("https://api.deezer.com/chart/0/tracks?limit=50"));
			case "@tiktok":
				return deezerPlaylist("tiktok viral", "tiktok");
			case "@phonk":
				return deezerPlaylist("phonk viral", "phonk");
			case "@hits":
			default:
				return deezerPlaylist("top hits 2026", "hits");
		}
	}

	private static List<Track> deezerPlaylist(String query, String must) throws Exception {
		JsonObject root = JsonParser.parseString(get("https://api.deezer.com/search/playlist?q=" + enc(query) + "&limit=10")).getAsJsonObject();
		if (!root.has("data")) return new ArrayList<>();
		JsonObject pick = null;
		long best = -1;
		for (JsonElement el : root.getAsJsonArray("data")) {
			JsonObject o = el.getAsJsonObject();
			String title = o.has("title") ? o.get("title").getAsString().toLowerCase() : "";
			long fans = o.has("nb_tracks") && !o.get("nb_tracks").isJsonNull() ? o.get("nb_tracks").getAsLong() : 0;
			long sc = (title.contains(must) ? 1_000_000L : 0) + fans;
			if (fans >= 10 && sc > best) {
				best = sc;
				pick = o;
			}
		}
		if (pick == null) return new ArrayList<>();
		return deezerList(get("https://api.deezer.com/playlist/" + pick.get("id").getAsString() + "/tracks?limit=60"));
	}

	private static List<Track> audius(String q) throws Exception {
		return audiusList(get("https://api.audius.co/v1/tracks/search?query=" + enc(q) + "&limit=25&app_name=" + APP));
	}

	private static List<Track> audiusList(String body) throws Exception {
		JsonObject root = JsonParser.parseString(body).getAsJsonObject();
		List<Track> out = new ArrayList<>();
		if (!root.has("data") || !root.get("data").isJsonArray()) return out;
		for (JsonElement el : root.getAsJsonArray("data")) {
			JsonObject o = el.getAsJsonObject();
			if (o.has("is_streamable") && !o.get("is_streamable").isJsonNull() && !o.get("is_streamable").getAsBoolean()) continue;
			if (!o.has("id")) continue;
			String id = o.get("id").getAsString();
			String title = o.has("title") ? o.get("title").getAsString() : "?";
			String artist = o.has("user") && o.get("user").isJsonObject() && o.getAsJsonObject("user").has("name")
					? o.getAsJsonObject("user").get("name").getAsString() : "?";
			int dur = o.has("duration") && !o.get("duration").isJsonNull() ? o.get("duration").getAsInt() : 0;
			out.add(new Track(title, artist, dur,
					"https://api.audius.co/v1/tracks/" + id + "/stream?app_name=" + APP, "Audius"));
		}
		return out;
	}

	private static List<Track> deezer(String q) throws Exception {
		return deezerList(get("https://api.deezer.com/search?q=" + enc(q) + "&limit=25"));
	}

	private static List<Track> deezerList(String body) throws Exception {
		JsonObject root = JsonParser.parseString(body).getAsJsonObject();
		List<Track> out = new ArrayList<>();
		if (!root.has("data") || !root.get("data").isJsonArray()) return out;
		JsonArray arr = root.getAsJsonArray("data");
		for (JsonElement el : arr) {
			JsonObject o = el.getAsJsonObject();
			if (!o.has("preview") || o.get("preview").isJsonNull() || o.get("preview").getAsString().isEmpty()) continue;
			String title = o.has("title") ? o.get("title").getAsString() : "?";
			String artist = o.has("artist") && o.get("artist").isJsonObject() && o.getAsJsonObject("artist").has("name")
					? o.getAsJsonObject("artist").get("name").getAsString() : "?";
			out.add(new Track(title, artist, 30, o.get("preview").getAsString(), "Deezer 30s"));
		}
		return out;
	}

	// ---------- playback ----------

	public static void play(int index) {
		List<Track> r = results;
		if (index < 0 || index >= r.size()) return;
		Track t = r.get(index);
		currentIndex = index;
		current = t;
		paused = false;
		posMs = 0;
		totalMs = t.seconds() * 1000L;
		status = "Loading " + t.title() + "...";
		int gen = GEN.incrementAndGet();
		Thread th = new Thread(() -> stream(t, gen), "ousek-music-play");
		th.setDaemon(true);
		th.start();
	}

	public static void next() {
		List<Track> r = results;
		if (r.isEmpty()) return;
		play((currentIndex + 1) % r.size());
	}

	public static void prev() {
		List<Track> r = results;
		if (r.isEmpty()) return;
		play((currentIndex - 1 + r.size()) % r.size());
	}

	public static void togglePause() {
		if (current != null) paused = !paused;
	}

	public static void stop() {
		GEN.incrementAndGet();
		paused = false;
		playing = false;
		current = null;
		currentIndex = -1;
		posMs = 0;
		status = "Stopped";
	}

	private static float volume() {
		WindowModules.Music m = WindowModules.music();
		return m == null ? 0.5f : (float) (m.volume.get() / 100.0);
	}

	// ---------- audio output ----------
	// Primary output is OpenAL (the same audio system Minecraft itself uses, so it also works on
	// PojavLauncher/Android where javax.sound does not exist). javax.sound is only a fallback.

	private interface Sink {
		void write(byte[] b, int len, float vol, BooleanSupplier alive) throws Exception;

		void pause(boolean p);

		void drain(BooleanSupplier alive) throws Exception;

		void close();
	}

	private static final class AlSink implements Sink {
		private static final int NBUF = 8, FIRST = 8192, CHUNK = 32768;
		private final int source, format, rate;
		private final int[] bufs = new int[NBUF];
		private final ArrayDeque<Integer> free = new ArrayDeque<>();
		private final ByteArrayOutputStream acc = new ByteArrayOutputStream(CHUNK + 8192);
		private boolean paused, firstDone;

		AlSink(int rate, int channels) {
			if (ALC10.alcGetCurrentContext() == 0L) throw new IllegalStateException("no OpenAL context (game sound off?)");
			this.rate = rate;
			this.format = channels == 1 ? AL10.AL_FORMAT_MONO16 : AL10.AL_FORMAT_STEREO16;
			AL10.alGetError();
			source = AL10.alGenSources();
			for (int i = 0; i < NBUF; i++) {
				bufs[i] = AL10.alGenBuffers();
				free.add(bufs[i]);
			}
			AL10.alSourcei(source, AL10.AL_SOURCE_RELATIVE, AL10.AL_TRUE);
			AL10.alSource3f(source, AL10.AL_POSITION, 0f, 0f, 0f);
			int err = AL10.alGetError();
			if (err != AL10.AL_NO_ERROR) {
				close();
				throw new IllegalStateException("OpenAL error " + err);
			}
		}

		private void reclaim() {
			int n = AL10.alGetSourcei(source, AL10.AL_BUFFERS_PROCESSED);
			while (n-- > 0) free.add(AL10.alSourceUnqueueBuffers(source));
		}

		private void submit(BooleanSupplier alive) throws Exception {
			if (acc.size() == 0) return;
			reclaim();
			while (free.isEmpty()) {
				if (!alive.getAsBoolean()) return;
				Thread.sleep(15);
				reclaim();
			}
			byte[] d = acc.toByteArray();
			acc.reset();
			ByteBuffer bb = ByteBuffer.allocateDirect(d.length).order(ByteOrder.nativeOrder());
			bb.put(d);
			bb.flip();
			int b = free.poll();
			AL10.alBufferData(b, format, bb, rate);
			AL10.alSourceQueueBuffers(source, b);
			firstDone = true;
			if (!paused && AL10.alGetSourcei(source, AL10.AL_SOURCE_STATE) != AL10.AL_PLAYING) AL10.alSourcePlay(source);
		}

		@Override
		public void write(byte[] b, int len, float vol, BooleanSupplier alive) throws Exception {
			AL10.alSourcef(source, AL10.AL_GAIN, vol);
			acc.write(b, 0, len);
			if (acc.size() >= (firstDone ? CHUNK : FIRST)) submit(alive);
		}

		@Override
		public void pause(boolean p) {
			paused = p;
			if (p) AL10.alSourcePause(source);
			else if (AL10.alGetSourcei(source, AL10.AL_BUFFERS_QUEUED) > 0) AL10.alSourcePlay(source);
		}

		@Override
		public void drain(BooleanSupplier alive) throws Exception {
			submit(alive);
			while (alive.getAsBoolean() && AL10.alGetSourcei(source, AL10.AL_SOURCE_STATE) == AL10.AL_PLAYING) Thread.sleep(50);
		}

		@Override
		public void close() {
			try {
				AL10.alSourceStop(source);
				AL10.alSourcei(source, AL10.AL_BUFFER, 0);
				AL10.alDeleteSources(source);
				for (int b : bufs) if (b != 0) AL10.alDeleteBuffers(b);
			} catch (Throwable ignored) {
			}
		}
	}

	private static final class JxSink implements Sink {
		private final SourceDataLine line;
		private boolean stopped;

		JxSink(int rate, int channels) throws Exception {
			AudioFormat fmt = new AudioFormat(rate, 16, channels, true, false);
			line = AudioSystem.getSourceDataLine(fmt);
			line.open(fmt);
			line.start();
		}

		@Override
		public void write(byte[] b, int len, float vol, BooleanSupplier alive) {
			// software volume on the 16-bit little-endian samples
			for (int i = 0; i + 1 < len; i += 2) {
				int v = (short) ((b[i] & 0xFF) | (b[i + 1] << 8));
				v = (int) (v * vol);
				b[i] = (byte) (v & 0xFF);
				b[i + 1] = (byte) ((v >> 8) & 0xFF);
			}
			line.write(b, 0, len);
		}

		@Override
		public void pause(boolean p) {
			if (p) line.stop();
			else line.start();
		}

		@Override
		public void drain(BooleanSupplier alive) {
			line.drain();
		}

		@Override
		public void close() {
			try {
				line.stop();
				line.close();
			} catch (Throwable ignored) {
			}
		}
	}

	private static String brief(Throwable e) {
		String m = e.getMessage();
		String s = e.getClass().getSimpleName() + (m == null ? "" : ": " + m);
		return s.length() > 90 ? s.substring(0, 90) : s;
	}

	private static void log(String s) {
		try {
			Path dir = FabricLoader.getInstance().getGameDir().resolve("ousek");
			Files.createDirectories(dir);
			Files.writeString(dir.resolve("music.log"), java.time.LocalTime.now() + " " + s + System.lineSeparator(),
					StandardCharsets.UTF_8, StandardOpenOption.CREATE, StandardOpenOption.APPEND);
		} catch (Throwable ignored) {
		}
	}

	private static Sink openSink(int rate, int channels) {
		String why;
		try {
			return new AlSink(rate, channels);
		} catch (Throwable e) {
			why = "OpenAL " + brief(e);
			log(why);
		}
		try {
			return new JxSink(rate, channels);
		} catch (Throwable e) {
			log("javax.sound " + brief(e));
			throw new IllegalStateException("No audio output. " + why);
		}
	}

	private static void stream(Track t, int gen) {
		Sink sink = null;
		boolean natural = false;
		BooleanSupplier alive = () -> GEN.get() == gen;
		try {
			HttpRequest req = HttpRequest.newBuilder(URI.create(t.url()))
					.timeout(Duration.ofSeconds(20))
					.header("User-Agent", "Ousek/1.0")
					.GET().build();
			HttpResponse<InputStream> r = HTTP.send(req, HttpResponse.BodyHandlers.ofInputStream());
			if (r.statusCode() / 100 != 2) {
				log("stream HTTP " + r.statusCode() + " " + t.url());
				if (alive.getAsBoolean()) status = "Stream error (HTTP " + r.statusCode() + ")";
				return;
			}
			try (InputStream in = new BufferedInputStream(r.body(), 1 << 16)) {
				Bitstream bs = new Bitstream(in);
				Decoder dec = new Decoder();
				playing = true;
				while (alive.getAsBoolean()) {
					Header h = bs.readFrame();
					if (h == null) {
						natural = true;
						break;
					}
					SampleBuffer out = (SampleBuffer) dec.decodeFrame(h, bs);
					if (sink == null) {
						sink = openSink(dec.getOutputFrequency(), dec.getOutputChannels());
						if (alive.getAsBoolean()) status = "Playing: " + t.title();
					}
					if (paused) {
						sink.pause(true);
						while (paused && alive.getAsBoolean()) Thread.sleep(40);
						sink.pause(false);
					}
					if (!alive.getAsBoolean()) break;

					short[] s = out.getBuffer();
					int len = out.getBufferLength();
					byte[] b = new byte[len * 2];
					for (int i = 0; i < len; i++) {
						b[i * 2] = (byte) (s[i] & 0xFF);
						b[i * 2 + 1] = (byte) ((s[i] >> 8) & 0xFF);
					}
					sink.write(b, b.length, volume(), alive);
					posMs += (long) h.ms_per_frame();
					if (posMs > totalMs) totalMs = posMs;
					bs.closeFrame();
				}
			}
			if (sink != null && natural && alive.getAsBoolean()) sink.drain(alive);
		} catch (Throwable e) {
			log("playback " + t.url() + " -> " + e);
			if (alive.getAsBoolean()) status = "Playback error: " + brief(e);
		} finally {
			if (sink != null) sink.close();
			if (alive.getAsBoolean()) {
				playing = false;
				if (natural) next();
			}
		}
	}
}
