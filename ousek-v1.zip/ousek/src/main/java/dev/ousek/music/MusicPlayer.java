package dev.ousek.music;

import com.google.gson.JsonArray;
import com.google.gson.JsonElement;
import com.google.gson.JsonObject;
import com.google.gson.JsonParser;
import dev.ousek.module.impl.WindowModules;
import javazoom.jl.decoder.Bitstream;
import javazoom.jl.decoder.Decoder;
import javazoom.jl.decoder.Header;
import javazoom.jl.decoder.SampleBuffer;

import javax.sound.sampled.AudioFormat;
import javax.sound.sampled.AudioSystem;
import javax.sound.sampled.SourceDataLine;
import java.io.BufferedInputStream;
import java.io.InputStream;
import java.net.URI;
import java.net.URLEncoder;
import java.net.http.HttpClient;
import java.net.http.HttpRequest;
import java.net.http.HttpResponse;
import java.nio.charset.StandardCharsets;
import java.time.Duration;
import java.util.ArrayList;
import java.util.List;
import java.util.concurrent.atomic.AtomicInteger;

/**
 * Streams MP3s from free, key-less APIs: Audius (full songs, includes NCS) and Deezer (30s previews
 * of commercial songs). Decoding is done with JLayer, output through javax.sound.
 */
public final class MusicPlayer {
	public record Track(String title, String artist, int seconds, String url, String source) {
	}

	private static final String APP = "OUSEK";
	private static final HttpClient HTTP = HttpClient.newBuilder()
			.followRedirects(HttpClient.Redirect.NORMAL)
			.connectTimeout(Duration.ofSeconds(10))
			.build();
	private static final AtomicInteger GEN = new AtomicInteger();

	public static volatile List<Track> results = List.of();
	public static volatile String status = "Type something and press Enter";
	public static volatile boolean searching;
	public static volatile Track current;
	public static volatile int currentIndex = -1;
	public static volatile boolean paused;
	public static volatile boolean playing;
	public static volatile long posMs;
	public static volatile long totalMs;

	private MusicPlayer() {
	}

	// ---------- search ----------

	public static void search(String query, String source) {
		String q = query == null ? "" : query.trim();
		if (q.isEmpty()) {
			status = "Type a song or artist first";
			return;
		}
		searching = true;
		status = "Searching...";
		Thread t = new Thread(() -> {
			List<Track> out = new ArrayList<>();
			String err = "";
			boolean audius = !source.startsWith("Deezer");
			boolean deezer = !source.startsWith("Audius");
			if (audius) {
				try {
					out.addAll(audius(q));
				} catch (Throwable e) {
					err += " Audius failed.";
				}
			}
			if (deezer && (source.startsWith("Deezer") || out.size() < 25)) {
				try {
					out.addAll(deezer(q));
				} catch (Throwable e) {
					err += " Deezer failed.";
				}
			}
			results = List.copyOf(out);
			searching = false;
			status = out.isEmpty() ? "No results." + err : out.size() + " results" + err;
		}, "ousek-music-search");
		t.setDaemon(true);
		t.start();
	}

	private static String get(String url) throws Exception {
		HttpRequest req = HttpRequest.newBuilder(URI.create(url))
				.timeout(Duration.ofSeconds(12))
				.header("User-Agent", "Ousek/1.0")
				.GET().build();
		HttpResponse<String> r = HTTP.send(req, HttpResponse.BodyHandlers.ofString(StandardCharsets.UTF_8));
		if (r.statusCode() != 200) throw new IllegalStateException("HTTP " + r.statusCode());
		return r.body();
	}

	private static String enc(String s) {
		return URLEncoder.encode(s, StandardCharsets.UTF_8);
	}

	private static List<Track> audius(String q) throws Exception {
		String body = get("https://api.audius.co/v1/tracks/search?query=" + enc(q) + "&limit=25&app_name=" + APP);
		JsonObject root = JsonParser.parseString(body).getAsJsonObject();
		List<Track> out = new ArrayList<>();
		if (!root.has("data") || !root.get("data").isJsonArray()) return out;
		for (JsonElement el : root.getAsJsonArray("data")) {
			JsonObject o = el.getAsJsonObject();
			if (o.has("is_streamable") && !o.get("is_streamable").isJsonNull() && !o.get("is_streamable").getAsBoolean()) continue;
			if (!o.has("id")) continue;
			String id = o.get("id").getAsString();
			String title = o.has("title") ? o.get("title").getAsString() : "?";
			String artist = o.has("user") && o.get("user").isJsonObject() && o.getAsJsonObject("user").has("name")
					? o.getAsJsonObject("user").get("name").getAsString() : "?";
			int dur = o.has("duration") && !o.get("duration").isJsonNull() ? o.get("duration").getAsInt() : 0;
			out.add(new Track(title, artist, dur,
					"https://api.audius.co/v1/tracks/" + id + "/stream?app_name=" + APP, "Audius"));
		}
		return out;
	}

	private static List<Track> deezer(String q) throws Exception {
		String body = get("https://api.deezer.com/search?q=" + enc(q) + "&limit=25");
		JsonObject root = JsonParser.parseString(body).getAsJsonObject();
		List<Track> out = new ArrayList<>();
		if (!root.has("data") || !root.get("data").isJsonArray()) return out;
		JsonArray arr = root.getAsJsonArray("data");
		for (JsonElement el : arr) {
			JsonObject o = el.getAsJsonObject();
			if (!o.has("preview") || o.get("preview").isJsonNull() || o.get("preview").getAsString().isEmpty()) continue;
			String title = o.has("title") ? o.get("title").getAsString() : "?";
			String artist = o.has("artist") && o.get("artist").isJsonObject() && o.getAsJsonObject("artist").has("name")
					? o.getAsJsonObject("artist").get("name").getAsString() : "?";
			out.add(new Track(title, artist, 30, o.get("preview").getAsString(), "Deezer 30s"));
		}
		return out;
	}

	// ---------- playback ----------

	public static void play(int index) {
		List<Track> r = results;
		if (index < 0 || index >= r.size()) return;
		Track t = r.get(index);
		currentIndex = index;
		current = t;
		paused = false;
		posMs = 0;
		totalMs = t.seconds() * 1000L;
		status = "Loading " + t.title() + "...";
		int gen = GEN.incrementAndGet();
		Thread th = new Thread(() -> stream(t, gen), "ousek-music-play");
		th.setDaemon(true);
		th.start();
	}

	public static void next() {
		List<Track> r = results;
		if (r.isEmpty()) return;
		play((currentIndex + 1) % r.size());
	}

	public static void prev() {
		List<Track> r = results;
		if (r.isEmpty()) return;
		play((currentIndex - 1 + r.size()) % r.size());
	}

	public static void togglePause() {
		if (current != null) paused = !paused;
	}

	public static void stop() {
		GEN.incrementAndGet();
		paused = false;
		playing = false;
		current = null;
		currentIndex = -1;
		posMs = 0;
		status = "Stopped";
	}

	private static float volume() {
		WindowModules.Music m = WindowModules.music();
		return m == null ? 0.5f : (float) (m.volume.get() / 100.0);
	}

	private static void stream(Track t, int gen) {
		SourceDataLine line = null;
		boolean natural = false;
		try {
			HttpRequest req = HttpRequest.newBuilder(URI.create(t.url()))
					.timeout(Duration.ofSeconds(20))
					.header("User-Agent", "Ousek/1.0")
					.GET().build();
			HttpResponse<InputStream> r = HTTP.send(req, HttpResponse.BodyHandlers.ofInputStream());
			if (r.statusCode() != 200) {
				if (GEN.get() == gen) status = "Stream error (HTTP " + r.statusCode() + ")";
				return;
			}
			try (InputStream in = new BufferedInputStream(r.body(), 1 << 16)) {
				Bitstream bs = new Bitstream(in);
				Decoder dec = new Decoder();
				playing = true;
				while (GEN.get() == gen) {
					Header h = bs.readFrame();
					if (h == null) {
						natural = true;
						break;
					}
					SampleBuffer out = (SampleBuffer) dec.decodeFrame(h, bs);
					if (line == null) {
						AudioFormat fmt = new AudioFormat(dec.getOutputFrequency(), 16, dec.getOutputChannels(), true, false);
						line = AudioSystem.getSourceDataLine(fmt);
						line.open(fmt);
						line.start();
						status = "Playing: " + t.title();
					}
					boolean wasPaused = false;
					while (paused && GEN.get() == gen) {
						if (!wasPaused) {
							line.stop();
							wasPaused = true;
						}
						Thread.sleep(40);
					}
					if (wasPaused) line.start();
					if (GEN.get() != gen) break;

					short[] s = out.getBuffer();
					int len = out.getBufferLength();
					float vol = volume();
					byte[] b = new byte[len * 2];
					for (int i = 0; i < len; i++) {
						int v = (int) (s[i] * vol);
						b[i * 2] = (byte) (v & 0xFF);
						b[i * 2 + 1] = (byte) ((v >> 8) & 0xFF);
					}
					line.write(b, 0, b.length);
					posMs += (long) h.ms_per_frame();
					if (posMs > totalMs) totalMs = posMs;
					bs.closeFrame();
				}
			}
			if (line != null) {
				if (natural && GEN.get() == gen) line.drain();
			}
		} catch (Throwable e) {
			if (GEN.get() == gen) {
				String m = e.getClass().getSimpleName();
				status = (e instanceof LinkageError || e instanceof IllegalArgumentException || e instanceof SecurityException)
						? "Audio output unavailable on this platform (" + m + ")"
						: "Playback error: " + m;
			}
		} finally {
			try {
				if (line != null) {
					line.stop();
					line.close();
				}
			} catch (Throwable ignored) {
			}
			if (GEN.get() == gen) {
				playing = false;
				if (natural) next();
			}
		}
	}
}
