package dev.ousek.mixin;

import dev.ousek.module.impl.VisualModules.HandGlow;
import net.minecraft.client.render.command.OrderedRenderCommandQueueImpl;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.ModifyVariable;

@Mixin(OrderedRenderCommandQueueImpl.class)
public abstract class OrderedRenderCommandQueueImplMixin {
	@ModifyVariable(method = "submitItem", at = @At("HEAD"), argsOnly = true, index = 5)
	private int ousek$outlineHeldItem(int original) {
		int color = HandGlow.currentOutlineColor();
		return color == 0 ? original : color;
	}

	@ModifyVariable(method = "submitModelPart", at = @At("HEAD"), argsOnly = true, index = 11)
	private int ousek$outlineHeldArm(int original) {
		int color = HandGlow.currentOutlineColor();
		return color == 0 ? original : color;
	}
}
