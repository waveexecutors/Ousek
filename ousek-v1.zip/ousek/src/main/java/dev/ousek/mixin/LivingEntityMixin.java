package dev.ousek.mixin;

import dev.ousek.module.Anims;
import net.minecraft.client.MinecraftClient;
import net.minecraft.entity.LivingEntity;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfoReturnable;

@Mixin(LivingEntity.class)
public abstract class LivingEntityMixin {
	@Inject(method = "getHandSwingProgress", at = @At("RETURN"), cancellable = true, require = 0)
	private void ousek$swingProgress(float tickProgress, CallbackInfoReturnable<Float> cir) {
		if (!Anims.active || (Object) this != MinecraftClient.getInstance().player) return;
		float t = cir.getReturnValueF();
		if (t <= 0f || t >= 1f) return;
		cir.setReturnValue((float) Anims.apply(Anims.index, t));
	}

	@Inject(method = "getHandSwingDuration", at = @At("HEAD"), cancellable = true, require = 0)
	private void ousek$swingDuration(CallbackInfoReturnable<Integer> cir) {
		if (!Anims.active || (Object) this != MinecraftClient.getInstance().player) return;
		cir.setReturnValue(Math.max(1, (int) Math.round(6.0 / Anims.speed)));
	}
}
