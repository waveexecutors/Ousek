package dev.ousek.mixin;

import dev.ousek.module.impl.VisualModules.Xray;
import net.minecraft.block.BlockState;
import net.minecraft.client.render.BlockRenderLayer;
import net.minecraft.client.render.BlockRenderLayers;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfoReturnable;

@Mixin(BlockRenderLayers.class)
public abstract class BlockRenderLayersMixin {
	@Inject(method = "getBlockLayer", at = @At("HEAD"), cancellable = true)
	private static void ousek$putTerrainInTranslucentPass(BlockState state,
	                                                       CallbackInfoReturnable<BlockRenderLayer> cir) {
		if (Xray.shouldMakeTransparent(state)) cir.setReturnValue(BlockRenderLayer.TRANSLUCENT);
	}
}
