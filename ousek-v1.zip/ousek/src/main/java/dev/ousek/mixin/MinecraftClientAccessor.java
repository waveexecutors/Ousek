package dev.ousek.mixin;

import net.minecraft.client.MinecraftClient;
import net.minecraft.client.session.Session;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Mutable;
import org.spongepowered.asm.mixin.gen.Accessor;

@Mixin(MinecraftClient.class)
public interface MinecraftClientAccessor {
	@Accessor("session")
	@Mutable
	void ousek$setSession(Session session);

	@Accessor("itemUseCooldown")
	void ousek$setItemUseCooldown(int value);
}
