package dev.ousek.mixin;

import net.minecraft.client.network.ClientPlayerInteractionManager;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.gen.Accessor;

@Mixin(ClientPlayerInteractionManager.class)
public interface InteractionManagerAccessor {
	@Accessor("blockBreakingCooldown")
	void ousek$setBlockBreakingCooldown(int value);

	@Accessor("blockBreakingCooldown")
	int ousek$getBlockBreakingCooldown();

	@Accessor("currentBreakingProgress")
	float ousek$getBreakProgress();

	@Accessor("currentBreakingProgress")
	void ousek$setBreakProgress(float value);
}
