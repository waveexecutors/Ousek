package dev.ousek.mixin;

import dev.ousek.module.impl.VisualModules;
import net.minecraft.block.Block;
import net.minecraft.block.BlockState;
import net.minecraft.util.math.Direction;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfoReturnable;

@Mixin(Block.class)
public abstract class BlockMixin {
	@Inject(method = "shouldDrawSide(Lnet/minecraft/block/BlockState;Lnet/minecraft/block/BlockState;Lnet/minecraft/util/math/Direction;)Z",
			at = @At("HEAD"), cancellable = true, require = 0)
	private static void ousek$xray(BlockState state, BlockState neighbor, Direction side, CallbackInfoReturnable<Boolean> cir) {
		if (VisualModules.Xray.active) cir.setReturnValue(VisualModules.Xray.visible(state));
	}
}
