package dev.ousek.mixin;

import dev.ousek.module.impl.VisualModules.Xray;
import net.minecraft.block.BlockState;
import net.minecraft.client.render.VertexConsumer;
import net.minecraft.client.render.block.BlockRenderManager;
import net.minecraft.client.util.math.MatrixStack;
import net.minecraft.util.math.BlockPos;
import net.minecraft.world.BlockRenderView;
import net.minecraft.client.render.model.BlockModelPart;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.ModifyArg;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

import java.util.List;

@Mixin(BlockRenderManager.class)
public abstract class BlockRenderManagerMixin {
	@Inject(method = "renderBlock", at = @At("HEAD"))
	private void ousek$beginBlock(BlockState state, BlockPos pos, BlockRenderView world,
	                              MatrixStack matrices, VertexConsumer consumer, boolean cull,
	                              List<BlockModelPart> parts, CallbackInfo ci) {
		Xray.beginBlock(state);
	}

	@ModifyArg(method = "renderBlock", at = @At(value = "INVOKE", target =
			"Lnet/minecraft/client/render/block/BlockModelRenderer;render(Lnet/minecraft/world/BlockRenderView;Ljava/util/List;Lnet/minecraft/block/BlockState;Lnet/minecraft/util/math/BlockPos;Lnet/minecraft/client/util/math/MatrixStack;Lnet/minecraft/client/render/VertexConsumer;ZI)V"), index = 5)
	private VertexConsumer ousek$fadeTerrain(VertexConsumer original) {
		return Xray.wrapVertexConsumer(original);
	}

	@Inject(method = "renderBlock", at = @At("RETURN"))
	private void ousek$endBlock(BlockState state, BlockPos pos, BlockRenderView world,
	                            MatrixStack matrices, VertexConsumer consumer, boolean cull,
	                            List<BlockModelPart> parts, CallbackInfo ci) {
		Xray.endBlock();
	}
}
