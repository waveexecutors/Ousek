package dev.ousek.mixin;

import dev.ousek.module.impl.PacketDelay;
import net.minecraft.network.ClientConnection;
import net.minecraft.network.packet.Packet;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

@Mixin(ClientConnection.class)
public class ClientConnectionMixin {
	@Inject(method = "send(Lnet/minecraft/network/packet/Packet;)V", at = @At("HEAD"), cancellable = true, require = 0)
	private void ousek$hold(Packet<?> packet, CallbackInfo ci) {
		if (PacketDelay.shouldHold(packet)) {
			PacketDelay.hold(packet);
			ci.cancel();
		}
	}
}
