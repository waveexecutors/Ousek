package dev.ousek.mixin;

import dev.ousek.module.impl.VisualModules;
import net.minecraft.block.AbstractBlock;
import net.minecraft.block.BlockRenderType;
import net.minecraft.block.BlockState;
import net.minecraft.util.math.BlockPos;
import net.minecraft.world.BlockView;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfoReturnable;

/**
 * When Xray is active in Transparent/Both mode, non-ore solid blocks report as non-opaque
 * so the world draws more see-through and ores stay visible.
 */
@Mixin(AbstractBlock.AbstractBlockState.class)
public abstract class BlockStateMixin {

	@Inject(method = "isOpaque", at = @At("HEAD"), cancellable = true, require = 0)
	private void ousek$xrayOpaque(CallbackInfoReturnable<Boolean> cir) {
		if (!VisualModules.Xray.active) return;
		BlockState self = (BlockState) (Object) this;
		if (VisualModules.Xray.isOre(self)) {
			cir.setReturnValue(true);
			return;
		}
		if (!self.isAir()) {
			cir.setReturnValue(false);
		}
	}

	@Inject(method = "getOpacity", at = @At("HEAD"), cancellable = true, require = 0)
	private void ousek$xrayOpacity(CallbackInfoReturnable<Integer> cir) {
		if (!VisualModules.Xray.active) return;
		BlockState self = (BlockState) (Object) this;
		if (VisualModules.Xray.isOre(self)) return;
		if (!self.isAir()) {
			cir.setReturnValue(0);
		}
	}

	@Inject(method = "isOpaqueFullCube", at = @At("HEAD"), cancellable = true, require = 0)
	private void ousek$xrayFullCube(CallbackInfoReturnable<Boolean> cir) {
		if (!VisualModules.Xray.active) return;
		BlockState self = (BlockState) (Object) this;
		if (VisualModules.Xray.isOre(self)) return;
		if (!self.isAir()) {
			cir.setReturnValue(false);
		}
	}
}
