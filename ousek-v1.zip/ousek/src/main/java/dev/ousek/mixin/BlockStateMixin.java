package dev.ousek.mixin;

import dev.ousek.module.impl.VisualModules;
import net.minecraft.block.AbstractBlock;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfoReturnable;

/** While Xray is on no block counts as an opaque cube, so the chunk visibility graph does not hide ores behind rock. */
@Mixin(AbstractBlock.AbstractBlockState.class)
public abstract class BlockStateMixin {
	@Inject(method = "isOpaqueFullCube()Z", at = @At("HEAD"), cancellable = true, require = 0)
	private void ousek$xrayOpaque(CallbackInfoReturnable<Boolean> cir) {
		if (VisualModules.Xray.active) cir.setReturnValue(false);
	}
}
