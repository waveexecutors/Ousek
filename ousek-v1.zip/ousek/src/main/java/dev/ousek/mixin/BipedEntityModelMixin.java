package dev.ousek.mixin;

import dev.ousek.emote.EmoteData;
import dev.ousek.emote.EmoteManager;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.model.ModelPart;
import net.minecraft.client.render.entity.model.BipedEntityModel;
import net.minecraft.entity.LivingEntity;
import org.spongepowered.asm.mixin.Final;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Shadow;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

/**
 * Applies active emote part rotations to the local player's biped model.
 */
@Mixin(BipedEntityModel.class)
public abstract class BipedEntityModelMixin<T extends LivingEntity> {

	@Shadow @Final public ModelPart head;
	@Shadow @Final public ModelPart body;
	@Shadow @Final public ModelPart rightArm;
	@Shadow @Final public ModelPart leftArm;
	@Shadow @Final public ModelPart rightLeg;
	@Shadow @Final public ModelPart leftLeg;

	@Inject(method = "setAngles", at = @At("RETURN"), require = 0)
	private void ousek$emote(T entity, float limbAngle, float limbDistance, float animationProgress, float headYaw, float headPitch, CallbackInfo ci) {
		if (EmoteManager.playing == null) return;
		MinecraftClient mc = MinecraftClient.getInstance();
		if (mc.player == null || entity != mc.player) return;

		apply("head", head);
		apply("torso", body);
		apply("rightArm", rightArm);
		apply("leftArm", leftArm);
		apply("rightLeg", rightLeg);
		apply("leftLeg", leftLeg);
	}

	private void apply(String which, ModelPart part) {
		if (part == null) return;
		EmoteData.Part p = EmoteManager.pose(which);
		if (p == null) return;
		// EmoteCraft stores radians when degrees=false
		part.pitch += p.pitch;
		part.yaw += p.yaw;
		part.roll += p.roll;
	}
}
