package dev.ousek.mixin;

import dev.ousek.emote.EmoteData;
import dev.ousek.emote.EmoteManager;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.model.ModelPart;
import net.minecraft.client.network.ClientPlayerEntity;
import net.minecraft.client.render.entity.model.BipedEntityModel;
import net.minecraft.client.render.entity.state.BipedEntityRenderState;
import net.minecraft.client.render.entity.state.PlayerEntityRenderState;
import org.spongepowered.asm.mixin.Final;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Shadow;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

/**
 * Applies active emote part rotations after biped angles are set.
 * 1.21.11: setAngles(BipedEntityRenderState) — not the old LivingEntity + float signature.
 */
@Mixin(BipedEntityModel.class)
public abstract class BipedEntityModelMixin {

	@Shadow @Final public ModelPart head;
	@Shadow @Final public ModelPart body;
	@Shadow @Final public ModelPart rightArm;
	@Shadow @Final public ModelPart leftArm;
	@Shadow @Final public ModelPart rightLeg;
	@Shadow @Final public ModelPart leftLeg;

	@Inject(method = "setAngles(Lnet/minecraft/client/render/entity/state/BipedEntityRenderState;)V", at = @At("RETURN"), require = 0)
	private void ousek$emote(BipedEntityRenderState state, CallbackInfo ci) {
		if (EmoteManager.playing == null) return;
		MinecraftClient mc = MinecraftClient.getInstance();
		ClientPlayerEntity player = mc.player;
		if (player == null) return;

		// Only apply to the local player's model (PlayerEntityRenderState.id == entity id)
		if (state instanceof PlayerEntityRenderState playerState) {
			if (playerState.id != player.getId()) return;
		} else {
			// Non-player bipeds: skip
			return;
		}

		apply("head", head);
		apply("torso", body);
		apply("rightArm", rightArm);
		apply("leftArm", leftArm);
		apply("rightLeg", rightLeg);
		apply("leftLeg", leftLeg);
	}

	private void apply(String which, ModelPart part) {
		if (part == null) return;
		EmoteData.Part p = EmoteManager.pose(which);
		if (p == null) return;
		part.pitch += p.pitch;
		part.yaw += p.yaw;
		part.roll += p.roll;
	}
}
