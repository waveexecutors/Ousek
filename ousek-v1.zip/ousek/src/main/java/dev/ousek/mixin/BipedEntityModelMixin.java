package dev.ousek.mixin;

import dev.ousek.emote.EmoteData;
import dev.ousek.emote.EmoteManager;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.model.ModelPart;
import net.minecraft.client.network.ClientPlayerEntity;
import net.minecraft.client.render.entity.model.BipedEntityModel;
import net.minecraft.client.render.entity.state.BipedEntityRenderState;
import net.minecraft.client.render.entity.state.PlayerEntityRenderState;
import org.spongepowered.asm.mixin.Final;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Shadow;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

/**
 * Applies active emote part rotations after biped angles are set.
 * Safe for first and third person; only touches local player model.
 */
@Mixin(BipedEntityModel.class)
public abstract class BipedEntityModelMixin {

	@Shadow @Final public ModelPart head;
	@Shadow @Final public ModelPart body;
	@Shadow @Final public ModelPart rightArm;
	@Shadow @Final public ModelPart leftArm;
	@Shadow @Final public ModelPart rightLeg;
	@Shadow @Final public ModelPart leftLeg;

	@Inject(method = "setAngles(Lnet/minecraft/client/render/entity/state/BipedEntityRenderState;)V", at = @At("RETURN"), require = 0)
	private void ousek$emote(BipedEntityRenderState state, CallbackInfo ci) {
		try {
			if (EmoteManager.playing == null) return;
			MinecraftClient mc = MinecraftClient.getInstance();
			if (mc == null) return;
			ClientPlayerEntity player = mc.player;
			if (player == null) return;

			// Only local player (works in third person too)
			if (!(state instanceof PlayerEntityRenderState playerState)) return;
			if (playerState.id != player.getId()) return;

			apply("head", head);
			apply("torso", body);
			apply("rightArm", rightArm);
			apply("leftArm", leftArm);
			apply("rightLeg", rightLeg);
			apply("leftLeg", leftLeg);
		} catch (Throwable ignored) {
			// never crash renderer
		}
	}

	private void apply(String which, ModelPart part) {
		if (part == null) return;
		EmoteData.Part p = EmoteManager.pose(which);
		if (p == null) return;
		part.pitch += p.pitch;
		part.yaw += p.yaw;
		part.roll += p.roll;
	}
}
