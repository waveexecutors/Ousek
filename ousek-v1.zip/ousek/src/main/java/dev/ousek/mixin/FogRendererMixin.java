package dev.ousek.mixin;

import dev.ousek.module.impl.AtmosphereModule;
import net.minecraft.client.render.fog.FogRenderer;
import org.joml.Vector4f;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfoReturnable;

/** Atmosphere: recolours the fog / horizon. */
@Mixin(FogRenderer.class)
public class FogRendererMixin {
	@Inject(method = "getFogColor(Lnet/minecraft/client/render/Camera;FLnet/minecraft/client/world/ClientWorld;IF)Lorg/joml/Vector4f;", at = @At("RETURN"), require = 0)
	private void ousek$fog(net.minecraft.client.render.Camera camera, float tickProgress, net.minecraft.client.world.ClientWorld world, int viewDistance, float skyDarkness, CallbackInfoReturnable<Vector4f> cir) {
		Vector4f v = cir.getReturnValue();
		if (v == null) return;
		float[] c = {v.x, v.y, v.z};
		AtmosphereModule.fog(c);
		v.set(c[0], c[1], c[2], v.w);
	}
}
