package dev.ousek.mixin;

import dev.ousek.emote.EmoteManager;
import net.minecraft.client.render.entity.model.PlayerEntityModel;
import net.minecraft.client.render.entity.state.PlayerEntityRenderState;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

@Mixin(PlayerEntityModel.class)
public abstract class PlayerEntityModelMixin {
	@Inject(method = "setAngles(Lnet/minecraft/client/render/entity/state/PlayerEntityRenderState;)V",
			at = @At("TAIL"), require = 0)
	private void ousek$emote(PlayerEntityRenderState state, CallbackInfo ci) {
		try {
			EmoteManager.apply((PlayerEntityModel) (Object) this, state.x, state.y, state.z);
		} catch (Throwable ignored) {
		}
	}
}
