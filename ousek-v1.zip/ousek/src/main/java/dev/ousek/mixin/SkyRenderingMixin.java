package dev.ousek.mixin;

import dev.ousek.module.impl.AtmosphereModule;
import net.minecraft.client.render.SkyRendering;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.ModifyVariable;

/** Atmosphere: recolours the sky dome. */
@Mixin(SkyRendering.class)
public class SkyRenderingMixin {
	@ModifyVariable(method = "renderTopSky(I)V", at = @At("HEAD"), argsOnly = true, require = 0)
	private int ousek$sky(int color) {
		return AtmosphereModule.sky(color);
	}
}
