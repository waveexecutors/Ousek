package dev.ousek.mixin;

import dev.ousek.Ousek;
import dev.ousek.gui.Theme;
import net.minecraft.client.gui.DrawContext;
import net.minecraft.client.gui.screen.TitleScreen;
import net.minecraft.client.gui.screen.Screen;
import net.minecraft.text.Text;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

/**
 * Draws the Ousek logo text over the vanilla Minecraft logo area on the title screen.
 */
@Mixin(TitleScreen.class)
public abstract class TitleScreenMixin extends Screen {

	protected TitleScreenMixin(Text title) {
		super(title);
	}

	@Inject(method = "render", at = @At("RETURN"), require = 0)
	private void ousek$logo(DrawContext context, int mouseX, int mouseY, float delta, CallbackInfo ci) {
		int cx = this.width / 2;
		int top = 28;
		String brand = Ousek.NAME.toUpperCase();
		String ver = Ousek.VERSION;

		// soft glow behind logo
		int accent = Theme.accent();
		for (int i = 4; i >= 1; i--) {
			int a = 18 * i;
			int col = (a << 24) | (accent & 0xFFFFFF);
			int pad = i * 3;
			context.fill(cx - 70 - pad, top - 4 - pad / 2, cx + 70 + pad, top + 28 + pad / 2, col);
		}

		// main logo bar
		context.fill(cx - 72, top - 2, cx + 72, top + 26, 0xE0101218);
		context.fill(cx - 72, top - 2, cx + 72, top, accent);
		context.fill(cx - 72, top + 24, cx + 72, top + 26, Theme.alpha(accent, 0x80));

		int tw = this.textRenderer.getWidth(brand);
		context.drawText(this.textRenderer, brand, cx - tw / 2, top + 4, 0xFFFFFFFF, true);
		int vw = this.textRenderer.getWidth(ver);
		context.drawText(this.textRenderer, ver, cx - vw / 2, top + 14, Theme.alpha(accent, 0xFF), false);
	}
}
