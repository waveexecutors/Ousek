package dev.ousek.mixin;

import dev.ousek.gui.Theme;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.gui.DrawContext;
import net.minecraft.client.gui.screen.TitleScreen;
import org.joml.Matrix3x2fStack;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

@Mixin(TitleScreen.class)
public abstract class TitleScreenMixin {
	@Inject(method = "render", at = @At("TAIL"))
	private void ousek$replaceMinecraftLogo(DrawContext context, int mouseX, int mouseY,
	                                        float delta, CallbackInfo ci) {
		MinecraftClient client = MinecraftClient.getInstance();
		if (client.textRenderer == null) return;

		int center = context.getScaledWindowWidth() / 2;
		int y = 18;
		int width = 272;
		int left = center - width / 2;
		Theme.rrect(context, left, y, width, 58, 7, 0xF20B0D12);
		context.fill(left + 10, y + 54, left + width - 10, y + 56, Theme.accent());

		String logo = "OUSEK";
		float scale = 3.0f;
		float scaledWidth = client.textRenderer.getWidth(logo) * scale;
		Matrix3x2fStack matrices = context.getMatrices();
		matrices.pushMatrix();
		matrices.translate(center - scaledWidth / 2.0f, y + 8.0f);
		matrices.scale(scale, scale);
		context.drawText(client.textRenderer, logo, 0, 0, 0xFFFFFFFF, true);
		matrices.popMatrix();

		String subtitle = "FABRIC CLIENT";
		context.drawText(client.textRenderer, subtitle,
				center - client.textRenderer.getWidth(subtitle) / 2, y + 43, 0xFF9A9AA5, false);
	}
}
