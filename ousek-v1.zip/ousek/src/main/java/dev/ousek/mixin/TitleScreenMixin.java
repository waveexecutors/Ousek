package dev.ousek.mixin;

import dev.ousek.gui.OusekMenu;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.gui.screen.Screen;
import net.minecraft.client.gui.screen.TitleScreen;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.ModifyVariable;

/** Swaps the vanilla title screen for the Ousek main menu. */
@Mixin(MinecraftClient.class)
public class TitleScreenMixin {
	@ModifyVariable(method = "setScreen(Lnet/minecraft/client/gui/screen/Screen;)V", at = @At("HEAD"), argsOnly = true, require = 0)
	private Screen ousek$replaceTitle(Screen screen) {
		return screen instanceof TitleScreen ? new OusekMenu() : screen;
	}
}
