package dev.ousek.accessory;

import dev.ousek.module.impl.WindowModules;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.model.Model;
import net.minecraft.client.model.ModelData;
import net.minecraft.client.model.ModelPart;
import net.minecraft.client.model.ModelPartBuilder;
import net.minecraft.client.model.ModelPartData;
import net.minecraft.client.model.ModelTransform;
import net.minecraft.client.model.TexturedModelData;
import net.minecraft.client.render.command.OrderedRenderCommandQueue;
import net.minecraft.client.render.entity.feature.FeatureRenderer;
import net.minecraft.client.render.entity.feature.FeatureRendererContext;
import net.minecraft.client.render.entity.model.PlayerEntityModel;
import net.minecraft.client.render.entity.state.PlayerEntityRenderState;
import net.minecraft.client.util.math.MatrixStack;
import net.minecraft.util.Identifier;

import java.lang.reflect.Field;
import java.lang.reflect.Modifier;
import java.util.ArrayList;
import java.util.Collections;
import java.util.HashMap;
import java.util.IdentityHashMap;
import java.util.List;
import java.util.Map;
import java.util.Set;
import java.util.WeakHashMap;

/**
 * Draws the equipped accessories on your player model. It is a vanilla FeatureRenderer (same mechanism as
 * capes/elytra), added to the player renderers at runtime by {@link #tick()} so it needs no mixin.
 */
public final class AccessoryFeature extends FeatureRenderer<PlayerEntityRenderState, PlayerEntityModel> {
	private static final Identifier TEX = Identifier.of("ousek", "textures/accessories/palette.png");
	private static final Set<Object> PATCHED = Collections.newSetFromMap(new WeakHashMap<>());
	private static final Map<Catalog.Item, Built> BUILT = new IdentityHashMap<>();
	private static int counter;
	private static boolean warned;

	private static final class Built {
		Model<Object> model;
		ModelPart root;
		final Map<String, ModelPart> parts = new HashMap<>();
	}

	public AccessoryFeature(FeatureRendererContext<PlayerEntityRenderState, PlayerEntityModel> context) {
		super(context);
	}

	// ---------------- install into the player renderers ----------------

	/** Called every client tick; every 2s it makes sure each player renderer has the accessory feature. */
	public static void tick() {
		if (++counter % 40 != 0) return;
		try {
			MinecraftClient mc = MinecraftClient.getInstance();
			Object disp = mc.getEntityRenderDispatcher();
			if (disp == null) return;
			for (Class<?> c = disp.getClass(); c != null && c != Object.class; c = c.getSuperclass()) {
				for (Field f : c.getDeclaredFields()) {
					if (Modifier.isStatic(f.getModifiers()) || !Map.class.isAssignableFrom(f.getType())) continue;
					f.setAccessible(true);
					Object v = f.get(disp);
					if (v instanceof Map<?, ?> map) {
						for (Object r : new ArrayList<>(map.values())) patch(r);
					}
				}
			}
		} catch (Throwable t) {
			warn("install", t);
		}
	}

	@SuppressWarnings("unchecked")
	private static void patch(Object r) throws Exception {
		if (r == null || PATCHED.contains(r) || !(r instanceof FeatureRendererContext<?, ?> ctx)) return;
		Object cm = ctx.getModel();
		if (!(cm instanceof PlayerEntityModel)) return;
		for (Class<?> c = r.getClass(); c != null && c != Object.class; c = c.getSuperclass()) {
			for (Field f : c.getDeclaredFields()) {
				if (Modifier.isStatic(f.getModifiers()) || !List.class.isAssignableFrom(f.getType())) continue;
				f.setAccessible(true);
				Object lv = f.get(r);
				if (lv instanceof List<?> l && !l.isEmpty() && l.get(0) instanceof FeatureRenderer) {
					((List<Object>) lv).add(new AccessoryFeature((FeatureRendererContext<PlayerEntityRenderState, PlayerEntityModel>) r));
					PATCHED.add(r);
					return;
				}
			}
		}
	}

	private static void warn(String what, Throwable t) {
		if (warned) return;
		warned = true;
		System.err.println("[Ousek] accessories " + what + " failed: " + t);
		t.printStackTrace();
	}

	// ---------------- model building ----------------

	private static ModelTransform none() {
		try {
			for (Field f : ModelTransform.class.getDeclaredFields()) {
				if (Modifier.isStatic(f.getModifiers()) && f.getType() == ModelTransform.class) {
					f.setAccessible(true);
					return (ModelTransform) f.get(null);
				}
			}
		} catch (Throwable ignored) {
		}
		return null;
	}

	private static Built build(Catalog.Item it, PlayerEntityModel pm) {
		Built b = BUILT.get(it);
		if (b != null) return b;
		ModelTransform id = none();
		if (id == null) throw new IllegalStateException("ModelTransform identity not found");
		ModelData md = new ModelData();
		ModelPartData root = md.getRoot();
		for (Catalog.Grp g : it.grps) {
			ModelPartBuilder pb = ModelPartBuilder.create();
			for (Catalog.Box bx : it.boxes) {
				if (!bx.g().equals(g.name())) continue;
				int u = (bx.c() % 8) * 32, v = (bx.c() / 8) * 32;
				pb.uv(u, v).cuboid(bx.x(), bx.y(), bx.z(), bx.dx(), bx.dy(), bx.dz());
			}
			root.addChild(g.name(), pb, id);
		}
		b = new Built();
		b.root = TexturedModelData.of(md, 256, 256).createModel();
		for (Catalog.Grp g : it.grps) b.parts.put(g.name(), b.root.getChild(g.name()));
		final ModelPart rp = b.root;
		b.model = new Model<Object>(rp, pm::getLayer) {
		};
		BUILT.put(it, b);
		return b;
	}

	private static void pose(Catalog.Item it, Built b, PlayerEntityModel pm) {
		MinecraftClient mc = MinecraftClient.getInstance();
		ModelPart a = it.head ? pm.head : pm.body;
		ModelPart r = b.root;
		r.originX = a.originX;
		r.originY = a.originY;
		r.originZ = a.originZ;
		r.pitch = a.pitch;
		r.yaw = a.yaw;
		r.roll = a.roll;
		double t = System.nanoTime() / 50_000_000.0;
		boolean air = mc.player != null && !mc.player.isOnGround();
		double speed = mc.player == null ? 0 : Math.sqrt(mc.player.getVelocity().horizontalLengthSquared());
		for (Catalog.Grp g : it.grps) {
			ModelPart p = b.parts.get(g.name());
			if (p == null) continue;
			p.originX = g.px();
			p.originY = g.py();
			p.originZ = g.pz();
			p.pitch = 0f;
			p.yaw = 0f;
			p.roll = 0f;
			switch (g.anim()) {
				case 1, 2 -> {
					double flap = air ? Math.sin(t * 0.9) * 0.55 : Math.sin(t * 0.12) * 0.1;
					float ang = (float) (0.55 + (air ? 0.25 : 0.0) + flap);
					p.yaw = g.anim() == 1 ? ang : -ang;
					p.roll = (float) (g.anim() == 1 ? -0.15 : 0.15);
				}
				case 3 -> p.yaw = (float) (t * 0.05);
				case 4 -> p.pitch = (float) (0.08 + Math.min(0.7, speed * 2.2) + Math.sin(t * 0.12) * (0.02 + speed * 0.1)
						+ (air ? 0.2 : 0.0));
				default -> {
				}
			}
		}
	}

	// ---------------- render ----------------

	@Override
	public void render(MatrixStack matrices, OrderedRenderCommandQueue queue, int light, PlayerEntityRenderState state,
					   float limbAngle, float limbDistance) {
		try {
			MinecraftClient mc = MinecraftClient.getInstance();
			if (mc.player == null) return;
			double dx = state.x - mc.player.getX(), dy = state.y - mc.player.getY(), dz = state.z - mc.player.getZ();
			if (dx * dx + dy * dy + dz * dz > 1.5) return; // only your own character
			WindowModules.Wardrobe w = WindowModules.wardrobe();
			if (w == null) return;
			PlayerEntityModel pm = getContextModel();
			for (Catalog.Cat c : Catalog.Cat.values()) {
				Catalog.Item it = w.equipped(c);
				if (it == null) continue;
				Built b = build(it, pm);
				pose(it, b, pm);
				renderModel(b.model, TEX, matrices, queue, light, state, 0xFFFFFFFF, 1);
			}
		} catch (Throwable t) {
			warn("render", t);
		}
	}
}
