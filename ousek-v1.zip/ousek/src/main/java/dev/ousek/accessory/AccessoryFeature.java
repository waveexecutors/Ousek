package dev.ousek.accessory;

import dev.ousek.module.impl.WindowModules;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.model.Model;
import net.minecraft.client.model.ModelData;
import net.minecraft.client.model.ModelPart;
import net.minecraft.client.model.ModelPartBuilder;
import net.minecraft.client.model.ModelPartData;
import net.minecraft.client.model.ModelTransform;
import net.minecraft.client.model.TexturedModelData;
import net.minecraft.client.render.command.OrderedRenderCommandQueue;
import net.minecraft.client.render.entity.feature.FeatureRenderer;
import net.minecraft.client.render.entity.feature.FeatureRendererContext;
import net.minecraft.client.render.entity.model.PlayerEntityModel;
import net.minecraft.client.render.entity.state.PlayerEntityRenderState;
import net.minecraft.client.util.math.MatrixStack;
import net.minecraft.util.Identifier;

import java.lang.reflect.Field;
import java.lang.reflect.Modifier;
import java.util.ArrayList;
import java.util.Collections;
import java.util.HashMap;
import java.util.IdentityHashMap;
import java.util.List;
import java.util.Map;
import java.util.Set;
import java.util.WeakHashMap;

/**
 * Draws the equipped accessories on your player model. It is a vanilla FeatureRenderer (same mechanism as
 * capes/elytra), added to the player renderers at runtime by {@link #tick()} so it needs no mixin.
 */
public final class AccessoryFeature extends FeatureRenderer<PlayerEntityRenderState, PlayerEntityModel> {
	private static final Identifier TEX = Identifier.of("ousek", "textures/accessories/palette.png");
	private static final Set<Object> PATCHED = Collections.newSetFromMap(new WeakHashMap<>());
	private static final Map<Catalog.Item, Built> BUILT = new IdentityHashMap<>();
	private static int counter;
	private static boolean warned;

	/**
	 * Vanilla calls model.setAngles(state) right before drawing, and the default implementation resets every part
	 * to its default pose. That wiped our pose (so accessories neither animated nor followed the body). Here
	 * setAngles re-applies the pose instead.
	 */
	private static final class Posed extends Model<Object> {
		Runnable pose;

		Posed(ModelPart root, java.util.function.Function<Identifier, net.minecraft.client.render.RenderLayer> f) {
			super(root, f);
		}

		@Override
		public void setAngles(Object state) {
			if (pose != null) pose.run();
		}
	}

	private static final class Built {
		Identifier tex = TEX;
		Posed model;
		ModelPart root;
		final Map<String, ModelPart> parts = new HashMap<>();
	}

	public AccessoryFeature(FeatureRendererContext<PlayerEntityRenderState, PlayerEntityModel> context) {
		super(context);
	}

	// ---------------- install into the player renderers ----------------

	/** Called every client tick; every 2s it makes sure each player renderer has the accessory feature. */
	public static void tick() {
		if (++counter % 40 != 0) return;
		try {
			MinecraftClient mc = MinecraftClient.getInstance();
			Object disp = mc.getEntityRenderDispatcher();
			if (disp == null) return;
			for (Class<?> c = disp.getClass(); c != null && c != Object.class; c = c.getSuperclass()) {
				for (Field f : c.getDeclaredFields()) {
					if (Modifier.isStatic(f.getModifiers()) || !Map.class.isAssignableFrom(f.getType())) continue;
					f.setAccessible(true);
					Object v = f.get(disp);
					if (v instanceof Map<?, ?> map) {
						for (Object r : new ArrayList<>(map.values())) patch(r);
					}
				}
			}
		} catch (Throwable t) {
			warn("install", t);
		}
	}

	@SuppressWarnings("unchecked")
	private static void patch(Object r) throws Exception {
		if (r == null || PATCHED.contains(r) || !(r instanceof FeatureRendererContext<?, ?> ctx)) return;
		Object cm = ctx.getModel();
		if (!(cm instanceof PlayerEntityModel)) return;
		for (Class<?> c = r.getClass(); c != null && c != Object.class; c = c.getSuperclass()) {
			for (Field f : c.getDeclaredFields()) {
				if (Modifier.isStatic(f.getModifiers()) || !List.class.isAssignableFrom(f.getType())) continue;
				f.setAccessible(true);
				Object lv = f.get(r);
				if (lv instanceof List<?> l && !l.isEmpty() && l.get(0) instanceof FeatureRenderer) {
					((List<Object>) lv).add(new AccessoryFeature((FeatureRendererContext<PlayerEntityRenderState, PlayerEntityModel>) r));
					PATCHED.add(r);
					return;
				}
			}
		}
	}

	private static void warn(String what, Throwable t) {
		if (warned) return;
		warned = true;
		System.err.println("[Ousek] accessories " + what + " failed: " + t);
		t.printStackTrace();
	}

	// ---------------- model building ----------------

	private static ModelTransform none() {
		try {
			for (Field f : ModelTransform.class.getDeclaredFields()) {
				if (Modifier.isStatic(f.getModifiers()) && f.getType() == ModelTransform.class) {
					f.setAccessible(true);
					return (ModelTransform) f.get(null);
				}
			}
		} catch (Throwable ignored) {
		}
		return null;
	}

	private static Built build(Catalog.Item it, PlayerEntityModel pm) {
		Built b = BUILT.get(it);
		if (b != null) return b;
		ModelTransform id = none();
		if (id == null) throw new IllegalStateException("ModelTransform identity not found");
		ModelData md = new ModelData();
		ModelPartData root = md.getRoot();
		for (Catalog.Grp g : it.grps) {
			ModelPartBuilder pb = ModelPartBuilder.create();
			if (it.tex != null) {
				for (Catalog.TBox bx : it.tboxes) {
					if (!bx.g().equals(g.name())) continue;
					pb.uv(bx.u(), bx.v()).mirrored(bx.mirror()).cuboid(bx.x(), bx.y(), bx.z(), bx.dx(), bx.dy(), bx.dz());
				}
			} else {
				for (Catalog.Box bx : it.boxes) {
					if (!bx.g().equals(g.name())) continue;
					int u = (bx.c() % 8) * 32, v = (bx.c() / 8) * 32;
					pb.uv(u, v).cuboid(bx.x(), bx.y(), bx.z(), bx.dx(), bx.dy(), bx.dz());
				}
			}
			int sl = g.name().indexOf('/');
			if (sl < 0) root.addChild(g.name(), pb, id);
			else root.getChild(g.name().substring(0, sl)).addChild(g.name().substring(sl + 1), pb, id);
		}
		b = new Built();
		if (it.tex != null) b.tex = Identifier.of("ousek", "textures/accessories/" + it.tex + ".png");
		b.root = TexturedModelData.of(md, it.tw, it.th).createModel();
		for (Catalog.Grp g : it.grps) {
			int sl = g.name().indexOf('/');
			b.parts.put(g.name(), sl < 0 ? b.root.getChild(g.name())
					: b.root.getChild(g.name().substring(0, sl)).getChild(g.name().substring(sl + 1)));
		}
		final ModelPart rp = b.root;
		b.model = new Posed(rp, pm::getLayer);
		BUILT.put(it, b);
		return b;
	}

	private static void pose(Catalog.Item it, Built b, float[] a6) {
		MinecraftClient mc = MinecraftClient.getInstance();
		WindowModules.Wardrobe w = WindowModules.wardrobe();
		ModelPart r = b.root;
		r.originX = a6[0];
		r.originY = a6[1];
		r.originZ = a6[2];
		r.pitch = a6[3];
		r.yaw = a6[4];
		r.roll = a6[5];
		WindowModules.Wardrobe cfg = WindowModules.wardrobe();
		double t = System.nanoTime() / 50_000_000.0;
		boolean air = mc.player != null && !mc.player.isOnGround();
		double speed = mc.player == null ? 0 : Math.sqrt(mc.player.getVelocity().horizontalLengthSquared());
		for (Catalog.Grp g : it.grps) {
			ModelPart p = b.parts.get(g.name());
			if (p == null) continue;
			float ox = g.px(), oy = g.py(), oz = g.pz();
			if (cfg != null) {
				if (g.anim() == 20 || g.anim() == 21) {
					ox = (g.anim() == 20 ? -1f : 1f) * (float) cfg.wingSpread.get();
					oy = (float) cfg.wingHeight.get();
					oz = (float) cfg.wingBack.get();
				} else if (it.tex != null && it.cat == Catalog.Cat.BANDANAS) {
					oy = g.py() + (float) cfg.bandanaHeight.get();
				}
				// plates of one bandana overlap at the corners; tiny height steps stop them z-fighting (the random flicker)
				if (it.cat == Catalog.Cat.BANDANAS) {
					oy += g.anim() == 11 ? 0.012f : g.anim() == 10 ? 0.024f : g.anim() == 12 ? 0.036f : 0f;
				}
			}
			p.originX = ox;
			p.originY = oy;
			p.originZ = oz;
			p.pitch = 0f;
			p.yaw = 0f;
			p.roll = 0f;
			switch (g.anim()) {
				case 1, 2 -> {
					double flap = air ? Math.sin(t * 0.9) * 0.55 : Math.sin(t * 0.12) * 0.1;
					float ang = (float) (0.55 + (air ? 0.25 : 0.0) + flap);
					p.yaw = g.anim() == 1 ? ang : -ang;
					p.roll = (float) (g.anim() == 1 ? -0.15 : 0.15);
				}
				case 10 -> p.yaw = (float) (-Math.PI / 2);
				case 12 -> p.yaw = (float) Math.PI;
				case 11 -> p.yaw = (float) (Math.PI / 2);
				case 20, 21, 22, 23 -> {
					double sp = w == null ? 1.0 : w.flapSpeed.get();
					double f = (System.currentTimeMillis() * sp % 1000.0) / 1000.0 * Math.PI * 2.0;
					double extra = w == null ? 0 : Math.toRadians(w.wingAngle.get());
					float s = g.anim() % 2 == 0 ? 1f : -1f;
					if (g.anim() < 22) {
						p.pitch = (float) (Math.toRadians(-80.0) + extra - Math.cos(f) * 0.2);
						p.yaw = s * (float) (Math.toRadians(20.0 + (cfg == null ? 0 : cfg.wingAngle.get())) + Math.sin(f) * 0.4);
						p.roll = s * (float) Math.toRadians(20.0);
					} else {
						p.roll = s * (float) (-(Math.sin(f + 2.0) + 0.5) * 0.75);
					}
				}
				case 3 -> p.yaw = (float) (t * 0.05);
				case 4 -> p.pitch = (float) (0.08 + Math.min(0.7, speed * 2.2) + Math.sin(t * 0.12) * (0.02 + speed * 0.1)
						+ (air ? 0.2 : 0.0));
				default -> {
				}
			}
		}
	}

	// ---------------- render ----------------

	@Override
	public void render(MatrixStack matrices, OrderedRenderCommandQueue queue, int light, PlayerEntityRenderState state,
					   float limbAngle, float limbDistance) {
		try {
			MinecraftClient mc = MinecraftClient.getInstance();
			if (mc.player == null) return;
			double dx = state.x - mc.player.getX(), dy = state.y - mc.player.getY(), dz = state.z - mc.player.getZ();
			if (dx * dx + dy * dy + dz * dz > 1.5) return; // only your own character
			WindowModules.Wardrobe w = WindowModules.wardrobe();
			if (w == null) return;
			PlayerEntityModel pm = getContextModel();
			for (Catalog.Cat c : Catalog.Cat.values()) {
				Catalog.Item it = w.equipped(c);
				if (it == null) continue;
				Built b = build(it, pm);
				final Built fb = b;
				final Catalog.Item fit = it;
				final PlayerEntityModel fpm = pm;
				b.model.pose = () -> pose(fit, fb, fpm);
				pose(it, b, pm);
				renderModel(b.model, b.tex, matrices, queue, light, state, 0xFFFFFFFF, 1);
			}
		} catch (Throwable t) {
			warn("render", t);
		}
	}
}
