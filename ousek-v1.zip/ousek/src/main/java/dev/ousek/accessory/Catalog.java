package dev.ousek.accessory;

import java.util.ArrayList;
import java.util.List;

/**
 * The wearable accessories as plain data (boxes in player-model pixel space). No Minecraft classes here,
 * so this can be loaded before the game is ready. Colors index the 8x8 palette in textures/accessories/palette.png.
 * Coordinates: x+ = your left, y+ = down, z+ = behind you (same as the vanilla player model).
 */
public final class Catalog {
	public enum Cat {
		WINGS("Wings"), CAPES("Capes"), BANDANAS("Bandanas"), HALOS("Halos");
		public final String label;

		Cat(String label) {
			this.label = label;
		}
	}

	public static final int WHITE = 12, BLACK = 13, GOLD = 14, GRAY = 15, LGRAY = 16, CREAM = 17, PINK = 18, CYAN = 19, ORANGE = 20;

	public record Box(String g, int c, float x, float y, float z, float dx, float dy, float dz) {
	}

	/** anim: 0 none, 3 spin, 10-12 bandana plates, 20-23 wings, 30+i cape segment i. */
	public record Grp(String name, float px, float py, float pz, int anim) {
	}

	/** Box with an explicit texel origin (u,v) for items that use their own PNG instead of the palette. */
	public record TBox(String g, int u, int v, float x, float y, float z, float dx, float dy, float dz, boolean mirror) {
	}

	public static final class Item {
		public String tex;
		public int tw = 256, th = 256;
		public final List<TBox> tboxes = new ArrayList<>();
		public final Cat cat;
		public final String name;
		public final boolean head;
		public final int c1, c2, c3;
		public final List<Grp> grps = new ArrayList<>();
		public final List<Box> boxes = new ArrayList<>();

		Item(Cat cat, String name, boolean head, int c1, int c2, int c3) {
			this.cat = cat;
			this.name = name;
			this.head = head;
			this.c1 = c1;
			this.c2 = c2;
			this.c3 = c3;
		}

		Item g(String n, float px, float py, float pz, int anim) {
			grps.add(new Grp(n, px, py, pz, anim));
			return this;
		}

		Item b(String g, int c, float x, float y, float z, float dx, float dy, float dz) {
			boxes.add(new Box(g, c, x, y, z, dx, dy, dz));
			return this;
		}

		Item tex(String name, int w, int h) {
			tex = name;
			tw = w;
			th = h;
			return this;
		}

		Item t(String g, int u, int v, float x, float y, float z, float dx, float dy, float dz, boolean mirror) {
			tboxes.add(new TBox(g, u, v, x, y, z, dx, dy, dz, mirror));
			return this;
		}

		/** Box on the right wing group plus its mirror on the left group. */
		Item pair(int c, float x, float y, float z, float dx, float dy, float dz) {
			b("r", c, x, y, z, dx, dy, dz);
			b("l", c, -(x + dx), y, z, dx, dy, dz);
			return this;
		}

		/** Box mirrored around x=0 inside the same group. */
		Item sym(String g, int c, float x, float y, float z, float dx, float dy, float dz) {
			b(g, c, x, y, z, dx, dy, dz);
			b(g, c, -(x + dx), y, z, dx, dy, dz);
			return this;
		}
	}

	static final String[] WING_FILES = {"blue", "green", "rainbow", "pink", "neon_gradient", "yellow", "golden_angel", "silver",
			"ice", "fire", "red", "white_angel", "purple", "magenta", "cyan", "orange"};
	static final String[] WING_NAMES = {"Blue Wings", "Green Wings", "Rainbow Wings", "Pink Wings", "Neon Wings", "Yellow Wings",
			"Golden Angel Wings", "Silver Wings", "Ice Wings", "Fire Wings", "Red Wings", "White Angel Wings", "Purple Wings",
			"Magenta Wings", "Cyan Wings", "Orange Wings"};
	static final String[] BAND_FILES = {"band_nyan", "band_antlers", "band_wreath", "band_naruto", "band_glasses", "band_lava",
			"band_pride", "band_nike", "band_x_apple","band_x_wordmark","band_x_wolf","band_x_nordic"};
	static final String[] BAND_NAMES = {"Nyan Band", "Antlers & Lights", "Wreath Band", "Shinobi Band", "Pixel Shades", "Lava Band",
			"Pride Band", "Sport Band", "Black Apple","Red Wordmark","Wolf Band","Nordic Red"};
	static final float[] BAND_Y = {-7f, -9f, -7f, -7f, -5.2f, -7f, -7f, -7f, -7f, -7f, -7f, -7f};
	static final String[] CAPE_FILES = {"black_darkness","black_logo","black_white_heart","boykisser_furry","cape_of","cartoon_ben","cat_pet","funny_cursed","glass_transparent","gold_minecraft","hacks_cheating","human_face_screenshot","labymod_labywolf","lunar_client_lunarred","lunar_lunar_client","minecraft_fox","moon_dark","of_classic_optifine","optifine_application","optifine_black","optifine_kitten","optifine_of","pepe_green","person_human_face","pig_cartoon","rickroll_meme","square_screenshot","switch_pride","uno_reverse"};
	static final String[] CAPE_NAMES = {"Dark Void Cape","Black Emblem Cape","Heart Cape","Boykisser Cape","Plain Cape","Ben Cape","Cat Cape","Cursed Cape","Glass Cape","Gold Cape","Hacker Cape","Face Cape","Wolf Cape","Moon Red Cape","Green Moon Cape","Fox Cape","Dark Moon Cape","Classic Cape","Application Cape","Black Classic Cape","Kitten Cape","Classic Alt Cape","Pepe Cape","Person Cape","Pig Cape","Rickroll Cape","Square Cape","Pride Cape","Uno Reverse Cape"};
	public static final int CAPE_SEGS = 32;

	public static final List<Item> ALL = new ArrayList<>();
	private static final List<List<Item>> BY_CAT = new ArrayList<>();

	static {
		for (int i = 0; i < Cat.values().length; i++) BY_CAT.add(new ArrayList<>());
		for (int i = 0; i < WING_FILES.length; i++) add(realWing(WING_NAMES[i], WING_FILES[i]));
		for (int i = 0; i < CAPE_FILES.length; i++) add(cape(CAPE_NAMES[i], "cape_" + CAPE_FILES[i]));
		for (int i = 0; i < BAND_FILES.length; i++) add(labyBand(BAND_NAMES[i], BAND_FILES[i], BAND_Y[i]));
		add(halo("Gold Halo", GOLD, CREAM, 0));
		add(halo("Double Halo", WHITE, CYAN, 1));
		add(halo("Spiked Halo", ORANGE, GOLD, 2));
		add(halo("Large Halo", PINK, WHITE, 3));
	}

	/** WingsMod 1.2 geometry: two bone boxes + double-sided 10x10 skin planes, a wing tip child, 30x30 texel space. */
	private static Item realWing(String name, String file) {
		Item it = new Item(Cat.WINGS, name, false, 0, 0, 0).tex("wings_" + file, 30, 30);
		it.g("r", -2, 3, 2.8f, 20).g("r/t", -10, 0, 0, 22).g("l", 2, 3, 2.8f, 21).g("l/t", 10, 0, 0, 23);
		it.t("r", 0, 0, -10, -1, -1, 10, 2, 2, false).t("r", -10, 8, -10, 0, 0.5f, 10, 0, 10, false);
		it.t("r/t", 0, 5, -10, -0.5f, -0.5f, 10, 1, 1, false).t("r/t", -10, 18, -10, 0, 0.5f, 10, 0, 10, false);
		it.t("l", 0, 0, 0, -1, -1, 10, 2, 2, true).t("l", -10, 8, 0, 0, 0.5f, 10, 0, 10, true);
		it.t("l/t", 0, 5, 0, -0.5f, -0.5f, 10, 1, 1, true).t("l/t", -10, 18, 0, 0, 0.5f, 10, 0, 10, true);
		return it;
	}

	/** LabyMod-format 400x320 atlas (20x16 units). */
	private static Item labyBand(String name, String file, float y) {
		Item it = new Item(Cat.BANDANAS, name, true, 0, 0, 0).tex(file, 20, 16);
		// rows of the atlas: 0 = front, 1 = right side, 2 = left side, 3 = back. Each is a plate whose front face is x20..200.
		it.g("f", 0, y, 0, 0).g("a", 0, y, 0, 11).g("c", 0, y, 0, 10).g("b", 0, y, 0, 12);
		// the atlas is four 9x3x1 boxes: uv origin (0, 4*row), outer face x 1..10, inner face x 11..20
		it.t("f", 0, 0, -4.5f, 0, -5.2f, 9, 3, 1, false);
		it.t("a", 0, 4, -4.5f, 0, -5.2f, 9, 3, 1, false);
		it.t("c", 0, 8, -4.5f, 0, -5.2f, 9, 3, 1, false);
		it.t("b", 0, 12, -4.5f, 0, -5.2f, 9, 3, 1, false);
		return it;
	}

	/**
	 * Textured cape in the vanilla/OptiFine 22x17 layout, cut into CAPE_SEGS thin strips (0.5 model units high). The texture is
	 * addressed at 4x so strips can be half a unit; each strip part is drawn at scale 0.25. Strips are independent parts: Cloth
	 * computes where each one hangs, so the cape bends in a smooth curve. The outer face is the +z face (texture x 12..22).
	 */
	private static Item cape(String name, String file) {
		Item it = new Item(Cat.CAPES, name, false, 0, 0, 0).tex(file, 88, 68);
		int h4 = 64 / CAPE_SEGS;
		for (int i = 0; i < CAPE_SEGS; i++) {
			it.g("s" + i, 0, 0, 2.4f, 30 + i);
			it.t("s" + i, 0, h4 * i, -20, 0, 0, 40, h4, 4, false);
		}
		return it;
	}

	private static void add(Item i) {
		ALL.add(i);
		BY_CAT.get(i.cat.ordinal()).add(i);
	}

	public static List<Item> of(Cat c) {
		return BY_CAT.get(c.ordinal());
	}

	public static String[] names(Cat c) {
		List<Item> l = of(c);
		String[] out = new String[l.size() + 1];
		out[0] = "None";
		for (int i = 0; i < l.size(); i++) out[i + 1] = l.get(i).name;
		return out;
	}

	// ---------------- halos ----------------

	private static Item halo(String name, int c1, int c2, int style) {
		Item it = new Item(Cat.HALOS, name, true, c1, c2, c1).g("h", 0, -11, 0, 3);
		if (style == 3) {
			it.b("h", c1, -4, 0, -4, 8, 1, 1).b("h", c1, -4, 0, 3, 8, 1, 1)
					.b("h", c1, -4, 0, -3, 1, 1, 6).b("h", c1, 3, 0, -3, 1, 1, 6);
			return it;
		}
		it.b("h", c1, -3, 0, -3, 6, 1, 1).b("h", c1, -3, 0, 2, 6, 1, 1)
				.b("h", c1, -3, 0, -2, 1, 1, 4).b("h", c1, 2, 0, -2, 1, 1, 4);
		if (style == 1) {
			it.b("h", c2, -2, 1.5f, -2, 4, 1, 1).b("h", c2, -2, 1.5f, 1, 4, 1, 1)
					.b("h", c2, -2, 1.5f, -1, 1, 1, 2).b("h", c2, 1, 1.5f, -1, 1, 1, 2);
		} else if (style == 2) {
			it.b("h", c2, -3, -2, -3, 1, 2, 1).b("h", c2, 2, -2, -3, 1, 2, 1)
					.b("h", c2, -3, -2, 2, 1, 2, 1).b("h", c2, 2, -2, 2, 1, 2, 1);
		}
		return it;
	}
}
