package dev.ousek.accessory;

import java.util.ArrayList;
import java.util.List;

/**
 * The 68 wearable accessories as plain data (boxes in player-model pixel space). No Minecraft classes here,
 * so this can be loaded before the game is ready. Colors index the 8x8 palette in textures/accessories/palette.png.
 * Coordinates: x+ = your left, y+ = down, z+ = behind you (same as the vanilla player model).
 */
public final class Catalog {
	public enum Cat {
		WINGS("Wings"), MASKS("Masks"), CAPES("Capes"), BANDANAS("Bandanas"), HALOS("Halos");
		public final String label;

		Cat(String label) {
			this.label = label;
		}
	}

	public static final int WHITE = 12, BLACK = 13, GOLD = 14, GRAY = 15, LGRAY = 16, CREAM = 17, PINK = 18, CYAN = 19, ORANGE = 20;
	public static final String[] WAY_NAMES = {"Crimson", "Azure", "Emerald", "Violet"};

	public record Box(String g, int c, float x, float y, float z, float dx, float dy, float dz) {
	}

	/** anim: 0 none, 1 right wing flap, 2 left wing flap, 3 spin, 4 cape sway. */
	public record Grp(String name, float px, float py, float pz, int anim) {
	}

	/** Box with an explicit texel origin (u,v) for items that use their own PNG instead of the palette. */
	public record TBox(String g, int u, int v, float x, float y, float z, float dx, float dy, float dz, boolean mirror) {
	}

	public static final class Item {
		public String tex;
		public int tw = 256, th = 256;
		public final List<TBox> tboxes = new ArrayList<>();
		public final Cat cat;
		public final String name;
		public final boolean head;
		public final int c1, c2, c3;
		public final List<Grp> grps = new ArrayList<>();
		public final List<Box> boxes = new ArrayList<>();

		Item(Cat cat, String name, boolean head, int c1, int c2, int c3) {
			this.cat = cat;
			this.name = name;
			this.head = head;
			this.c1 = c1;
			this.c2 = c2;
			this.c3 = c3;
		}

		Item g(String n, float px, float py, float pz, int anim) {
			grps.add(new Grp(n, px, py, pz, anim));
			return this;
		}

		Item b(String g, int c, float x, float y, float z, float dx, float dy, float dz) {
			boxes.add(new Box(g, c, x, y, z, dx, dy, dz));
			return this;
		}

		Item tex(String name, int w, int h) {
			tex = name;
			tw = w;
			th = h;
			return this;
		}

		Item t(String g, int u, int v, float x, float y, float z, float dx, float dy, float dz, boolean mirror) {
			tboxes.add(new TBox(g, u, v, x, y, z, dx, dy, dz, mirror));
			return this;
		}

		/** Box on the right wing group plus its mirror on the left group. */
		Item pair(int c, float x, float y, float z, float dx, float dy, float dz) {
			b("r", c, x, y, z, dx, dy, dz);
			b("l", c, -(x + dx), y, z, dx, dy, dz);
			return this;
		}

		/** Box mirrored around x=0 inside the same group. */
		Item sym(String g, int c, float x, float y, float z, float dx, float dy, float dz) {
			b(g, c, x, y, z, dx, dy, dz);
			b(g, c, -(x + dx), y, z, dx, dy, dz);
			return this;
		}
	}

	public static final List<Item> ALL = new ArrayList<>();
	private static final List<List<Item>> BY_CAT = new ArrayList<>();

	static {
		for (int i = 0; i < Cat.values().length; i++) BY_CAT.add(new ArrayList<>());
		for (int i = 0; i < WING_FILES.length; i++) add(realWing(WING_NAMES[i], WING_FILES[i]));
		for (int w = 0; w < 4; w++) {
			int p = w * 3, d = w * 3 + 1, l = w * 3 + 2;
			String n = WAY_NAMES[w];
			add(domino(n, p, d, l));
			add(bandit(n, p, d, l));
			add(fullMask(n, p, d, l));
			add(foxMask(n, p, d, l));
		}
		for (int w = 0; w < 4; w++) {
			int p = w * 3, d = w * 3 + 1, l = w * 3 + 2;
			String n = WAY_NAMES[w];
			add(classicCape(n, p, d, l));
			add(royalCape(n, p, d, l));
			add(shortCape(n, p, d, l));
			add(mantle(n, p, d, l));
		}
		for (int w = 0; w < 4; w++) {
			int p = w * 3, d = w * 3 + 1, l = w * 3 + 2;
			String n = WAY_NAMES[w];
			add(headband(n, p, d, l));
			add(pirate(n, p, d, l));
			add(neck(n, p, d, l));
			add(scarf(n, p, d, l));
		}
		for (int i = 0; i < BAND_FILES.length; i++) add(labyBand(BAND_NAMES[i], BAND_FILES[i], BAND_Y[i]));
		add(halo("Gold Halo", GOLD, CREAM, 0));
		add(halo("Double Halo", WHITE, CYAN, 1));
		add(halo("Spiked Halo", ORANGE, GOLD, 2));
		add(halo("Large Halo", PINK, WHITE, 3));
	}

	static final String[] WING_FILES = {"blue", "green", "rainbow", "pink", "neon_gradient", "yellow", "golden_angel", "silver",
			"ice", "fire", "red", "white_angel", "purple", "magenta", "cyan", "orange"};
	static final String[] WING_NAMES = {"Blue Wings", "Green Wings", "Rainbow Wings", "Pink Wings", "Neon Wings", "Yellow Wings",
			"Golden Angel Wings", "Silver Wings", "Ice Wings", "Fire Wings", "Red Wings", "White Angel Wings", "Purple Wings",
			"Magenta Wings", "Cyan Wings", "Orange Wings"};
	static final String[] BAND_FILES = {"band_nyan", "band_antlers", "band_wreath", "band_naruto", "band_glasses", "band_lava",
			"band_pride", "band_nike"};
	static final String[] BAND_NAMES = {"Nyan Band", "Antlers & Lights", "Wreath Band", "Shinobi Band", "Pixel Shades", "Lava Band",
			"Pride Band", "Sport Band"};
	static final float[] BAND_Y = {-7f, -7f, -7f, -7f, -5.2f, -7f, -7f, -7f};

	/** WingsMod 1.2 geometry: two bone boxes + double-sided 10x10 skin planes, a wing tip child, 30x30 texel space. */
	private static Item realWing(String name, String file) {
		Item it = new Item(Cat.WINGS, name, false, 0, 0, 0).tex("wings_" + file, 30, 30);
		it.g("r", -2, 3, 2.8f, 20).g("r/t", -10, 0, 0, 22).g("l", 2, 3, 2.8f, 21).g("l/t", 10, 0, 0, 23);
		it.t("r", 0, 0, -10, -1, -1, 10, 2, 2, false).t("r", -10, 8, -10, 0, 0.5f, 10, 0, 10, false);
		it.t("r/t", 0, 5, -10, -0.5f, -0.5f, 10, 1, 1, false).t("r/t", -10, 18, -10, 0, 0.5f, 10, 0, 10, false);
		it.t("l", 0, 0, 0, -1, -1, 10, 2, 2, true).t("l", -10, 8, 0, 0, 0.5f, 10, 0, 10, true);
		it.t("l/t", 0, 5, 0, -0.5f, -0.5f, 10, 1, 1, true).t("l/t", -10, 18, 0, 0, 0.5f, 10, 0, 10, true);
		return it;
	}

	/** LabyMod-format 400x320 atlas (20x16 units): first 80px row, front face = x20..200, back face = x220..400. */
	private static Item labyBand(String name, String file, float y) {
		Item it = new Item(Cat.BANDANAS, name, true, 0, 0, 0).tex(file, 20, 16);
		it.g("f", 0, y, 0, 0).g("b", 0, y, 0, 0).g("a", 0, y, 0, 10).g("c", 0, y, 0, 11);
		it.t("f", 0, 0, -4.5f, 0, -4.75f, 9, 3, 1, false);
		it.t("b", 0, 0, -4.5f, 0, 3.75f, 9, 3, 1, false);
		it.t("a", 0, 0, -4.5f, 0, 3.75f, 9, 3, 1, false);
		it.t("c", 0, 0, -4.5f, 0, 3.75f, 9, 3, 1, false);
		return it;
	}

	private static void add(Item i) {
		ALL.add(i);
		BY_CAT.get(i.cat.ordinal()).add(i);
	}

	public static List<Item> of(Cat c) {
		return BY_CAT.get(c.ordinal());
	}

	public static String[] names(Cat c) {
		List<Item> l = of(c);
		String[] out = new String[l.size() + 1];
		out[0] = "None";
		for (int i = 0; i < l.size(); i++) out[i + 1] = l.get(i).name;
		return out;
	}

	// ---------------- wings ----------------

	private static Item wingBase(String style, String way, int p, int d, int l) {
		return new Item(Cat.WINGS, style + " Wings " + way, false, p, d, l)
				.g("r", -1.5f, 1f, 2.6f, 1).g("l", 1.5f, 1f, 2.6f, 2);
	}

	private static Item angel(String w, int p, int d, int l) {
		Item it = wingBase("Angel", w, p, d, l);
		float[] len = {14, 13, 11, 8};
		for (int i = 0; i < 4; i++) it.pair(i % 2 == 0 ? WHITE : l, -len[i], i * 3 - 1, 0, len[i], 3, 1);
		it.pair(d, -12, -2, 0, 12, 1, 1);
		return it;
	}

	private static Item bat(String w, int p, int d, int l) {
		Item it = wingBase("Bat", w, p, d, l);
		it.pair(d, -15, -1, 0, 15, 1, 1);
		it.pair(p, -14, 0, 0, 14, 3, 1);
		it.pair(p, -11, 3, 0, 11, 3, 1);
		it.pair(d, -7, 6, 0, 7, 3, 1);
		it.pair(l, -2, 9, 0, 2, 2, 1);
		return it;
	}

	private static Item dragon(String w, int p, int d, int l) {
		Item it = wingBase("Dragon", w, p, d, l);
		it.pair(d, -15, -2, 0, 15, 2, 1);
		it.pair(p, -14, 0, 0, 14, 4, 1);
		it.pair(p, -11, 4, 0, 11, 4, 1);
		it.pair(d, -7, 8, 0, 7, 3, 1);
		it.pair(GOLD, -15, -3, 0, 2, 1, 1);
		it.pair(l, -9, 3, -1, 2, 2, 1);
		return it;
	}

	private static Item butterfly(String w, int p, int d, int l) {
		Item it = wingBase("Butterfly", w, p, d, l);
		it.pair(p, -13, -2, 0, 13, 7, 1);
		it.pair(l, -9, 5, 0, 9, 6, 1);
		it.pair(WHITE, -9, 0, -1, 3, 3, 1);
		it.pair(BLACK, -13, -2, 1, 13, 1, 1);
		return it;
	}

	// ---------------- masks (anchored to the head) ----------------

	private static Item maskBase(String style, String way, int p, int d, int l) {
		return new Item(Cat.MASKS, style + " Mask " + way, true, p, d, l).g("h", 0, 0, 0, 0);
	}

	private static Item domino(String w, int p, int d, int l) {
		return maskBase("Domino", w, p, d, l)
				.b("h", p, -5, -5.5f, -5.2f, 10, 2, 1)
				.b("h", d, -5, -5.5f, -4.2f, 1, 2, 8).b("h", d, 4, -5.5f, -4.2f, 1, 2, 8)
				.b("h", l, -5, -6.5f, -5.2f, 3, 1, 1).b("h", l, 2, -6.5f, -5.2f, 3, 1, 1);
	}

	private static Item bandit(String w, int p, int d, int l) {
		return maskBase("Bandit", w, p, d, l)
				.b("h", p, -5, -3.5f, -5.2f, 10, 4, 1)
				.b("h", d, -5, -3.5f, -4.2f, 1, 4, 8).b("h", d, 4, -3.5f, -4.2f, 1, 4, 8)
				.b("h", l, -5, -4.5f, -5.2f, 10, 1, 1);
	}

	private static Item fullMask(String w, int p, int d, int l) {
		return maskBase("Full", w, p, d, l)
				.b("h", p, -5, -9, -5.2f, 10, 3, 1)
				.b("h", p, -5, -6, -5.2f, 2, 3, 1).b("h", p, 3, -6, -5.2f, 2, 3, 1)
				.b("h", d, -5, -3, -5.2f, 10, 4, 1)
				.b("h", l, -1, -4, -5.8f, 2, 2, 1);
	}

	private static Item foxMask(String w, int p, int d, int l) {
		return maskBase("Fox", w, p, d, l)
				.b("h", p, -5, -9, -5.2f, 10, 3, 1)
				.b("h", p, -5, -6, -5.2f, 2, 3, 1).b("h", p, 3, -6, -5.2f, 2, 3, 1)
				.b("h", WHITE, -5, -3, -5.2f, 10, 4, 1)
				.b("h", BLACK, -1, -4, -5.8f, 2, 2, 1)
				.b("h", p, -5, -12, -2, 3, 3, 2).b("h", p, 2, -12, -2, 3, 3, 2)
				.b("h", l, -4, -11, -2.5f, 1, 2, 1).b("h", l, 3, -11, -2.5f, 1, 2, 1)
				.b("h", d, -8, -3, -5.2f, 3, 1, 1).b("h", d, 5, -3, -5.2f, 3, 1, 1);
	}

	// ---------------- capes (anchored to the body) ----------------

	private static Item capeBase(String style, String way, int p, int d, int l) {
		return new Item(Cat.CAPES, style + " Cape " + way, false, p, d, l).g("c", 0, 0, 2.4f, 4).g("s", 0, 0, 0, 0);
	}

	private static Item classicCape(String w, int p, int d, int l) {
		return capeBase("Classic", w, p, d, l).b("c", p, -5, 0, 0, 10, 16, 1).b("c", d, -5, 15, 0, 10, 1, 1);
	}

	private static Item royalCape(String w, int p, int d, int l) {
		return capeBase("Royal", w, p, d, l)
				.b("c", p, -5, 0, 0, 10, 16, 1).b("c", GOLD, -5, 14, 1, 10, 2, 1)
				.b("c", WHITE, -6, -1, -0.5f, 12, 2, 2).b("c", l, -1, 3, 1, 2, 10, 1);
	}

	private static Item shortCape(String w, int p, int d, int l) {
		return capeBase("Short", w, p, d, l)
				.b("c", p, -5, 0, 0, 10, 9, 1)
				.b("c", d, -5, 9, 0, 3, 2, 1).b("c", d, -1.5f, 9, 0, 3, 2, 1).b("c", d, 2, 9, 0, 3, 2, 1);
	}

	private static Item mantle(String w, int p, int d, int l) {
		return capeBase("Mantle", w, p, d, l)
				.b("c", p, -5, 0, 0, 10, 14, 1).b("c", l, -5, 13, 0, 10, 1, 1)
				.sym("s", d, 4, -1.5f, -2.5f, 4, 2, 5).sym("s", l, 4, -2.5f, -2f, 3, 1, 4);
	}

	// ---------------- bandanas ----------------

	private static Item headband(String w, int p, int d, int l) {
		return new Item(Cat.BANDANAS, "Headband " + w, true, p, d, l).g("h", 0, 0, 0, 0)
				.b("h", p, -5, -7, -5, 10, 2, 1).b("h", p, -5, -7, 4, 10, 2, 1)
				.b("h", p, -5, -7, -4, 1, 2, 8).b("h", p, 4, -7, -4, 1, 2, 8)
				.b("h", l, -1, -7, 5, 2, 5, 1);
	}

	private static Item pirate(String w, int p, int d, int l) {
		return new Item(Cat.BANDANAS, "Pirate " + w, true, p, d, l).g("h", 0, 0, 0, 0)
				.b("h", p, -5, -9.4f, -5, 10, 2, 5).b("h", p, -5, -9.4f, 0, 10, 2, 5)
				.b("h", p, -5, -7.4f, -5, 10, 3, 1).b("h", p, -5, -7.4f, 4, 10, 3, 1)
				.b("h", p, -5, -7.4f, -4, 1, 3, 8).b("h", p, 4, -7.4f, -4, 1, 3, 8)
				.b("h", d, 4, -6.4f, -1, 2, 2, 2)
				.b("h", l, 5, -4.4f, -1, 1, 4, 1).b("h", l, 5, -4.4f, 0.5f, 1, 3, 1);
	}

	private static Item neck(String w, int p, int d, int l) {
		return new Item(Cat.BANDANAS, "Neck Bandana " + w, false, p, d, l).g("n", 0, 0, 0, 0)
				.b("n", p, -4.5f, -1, -2.6f, 9, 3, 1).b("n", p, -4.5f, -1, 1.6f, 9, 3, 1)
				.sym("n", p, 3.5f, -1, -2.5f, 1, 3, 5)
				.b("n", d, -3, 2, -2.8f, 6, 2, 1).b("n", d, -2, 4, -2.8f, 4, 2, 1).b("n", l, -1, 6, -2.8f, 2, 2, 1);
	}

	private static Item scarf(String w, int p, int d, int l) {
		return new Item(Cat.BANDANAS, "Scarf " + w, false, p, d, l).g("n", 0, 0, 0, 0).g("t", 0, 0, 2.4f, 4)
				.b("n", p, -4.5f, -1, -2.6f, 9, 3, 1).b("n", p, -4.5f, -1, 1.6f, 9, 3, 1)
				.sym("n", p, 3.5f, -1, -2.5f, 1, 3, 5)
				.b("t", d, 1, 1, 0, 3, 12, 1).b("t", l, 1, 11, 0, 3, 1, 1);
	}

	// ---------------- halos ----------------

	private static Item halo(String name, int c1, int c2, int style) {
		Item it = new Item(Cat.HALOS, name, true, c1, c2, c1).g("h", 0, -11, 0, 3);
		if (style == 3) {
			it.b("h", c1, -4, 0, -4, 8, 1, 1).b("h", c1, -4, 0, 3, 8, 1, 1)
					.b("h", c1, -4, 0, -3, 1, 1, 6).b("h", c1, 3, 0, -3, 1, 1, 6);
			return it;
		}
		it.b("h", c1, -3, 0, -3, 6, 1, 1).b("h", c1, -3, 0, 2, 6, 1, 1)
				.b("h", c1, -3, 0, -2, 1, 1, 4).b("h", c1, 2, 0, -2, 1, 1, 4);
		if (style == 1) {
			it.b("h", c2, -2, 1.5f, -2, 4, 1, 1).b("h", c2, -2, 1.5f, 1, 4, 1, 1)
					.b("h", c2, -2, 1.5f, -1, 1, 1, 2).b("h", c2, 1, 1.5f, -1, 1, 1, 2);
		} else if (style == 2) {
			it.b("h", c2, -3, -2, -3, 1, 2, 1).b("h", c2, 2, -2, -3, 1, 2, 1)
					.b("h", c2, -3, -2, 2, 1, 2, 1).b("h", c2, 2, -2, 2, 1, 2, 1);
		}
		return it;
	}
}
