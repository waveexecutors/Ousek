package dev.ousek.accessory;

import net.minecraft.client.MinecraftClient;
import net.minecraft.util.math.Vec3d;

/**
 * Cape physics. A few spring nodes (top to bottom) are pushed by the wind your movement makes (forward speed, falling,
 * strafing, turning); each lower node follows the one above with a delay, so a wave runs down the cape. The node angles are
 * then interpolated smoothly over all {@link Catalog#CAPE_SEGS} thin strips, and the strips are chained end to end, so the
 * cape is one continuous curve instead of blocks. It integrates in real time on smoothed per-frame positions, so it is
 * fluid at any FPS and never steps with ticks.
 */
final class Cloth {
	private static final int N = Catalog.CAPE_SEGS;
	private static final int M = 6; // spring nodes
	private static final float STRIP = 16f / N; // model units per strip
	private static final float[] A = new float[M], AV = new float[M]; // pitch + velocity
	private static final float[] R = new float[M], RV = new float[M]; // roll + velocity
	private static final float[] SP = new float[N], SR = new float[N]; // per strip angles
	private static final float[] PX = new float[N], PY = new float[N], PZ = new float[N]; // per strip hinge offsets
	private static Vec3d lastPos;
	private static long lastNs;
	private static double vx, vy, vz;
	private static float lastYaw;
	private static double yawRate;

	private Cloth() {
	}

	static float pitch(int i) {
		return SP[i];
	}

	static float roll(int i) {
		return SR[i];
	}

	static float px(int i) {
		return PX[i];
	}

	static float py(int i) {
		return PY[i];
	}

	static float pz(int i) {
		return PZ[i];
	}

	private static float sample(float[] v, float s) {
		int i = Math.min(M - 2, (int) s);
		float f = s - i;
		f = f * f * (3f - 2f * f); // smoothstep between nodes
		return v[i] + (v[i + 1] - v[i]) * f;
	}

	static void update(MinecraftClient mc, double swing) {
		if (mc.player == null) return;
		long now = System.nanoTime();
		double dt = (now - lastNs) / 1e9;
		if (dt < 0.0015) return; // already stepped this frame (the feature can render more than once)
		boolean first = lastPos == null || dt > 0.5;
		lastNs = now;
		Vec3d pos = mc.player.getLerpedPos(mc.getRenderTickCounter().getTickProgress(false));
		float yaw = mc.player.getYaw();
		if (first) {
			lastPos = pos;
			lastYaw = yaw;
			shape();
			return;
		}
		dt = Math.min(dt, 0.05);
		// velocity from the interpolated position, low-passed so it is smooth between ticks
		double k = 1.0 - Math.exp(-dt * 14.0);
		vx += ((pos.x - lastPos.x) / dt - vx) * k;
		vy += ((pos.y - lastPos.y) / dt - vy) * k;
		vz += ((pos.z - lastPos.z) / dt - vz) * k;
		double dy = ((yaw - lastYaw + 540.0) % 360.0) - 180.0;
		yawRate += (dy / dt - yawRate) * (1.0 - Math.exp(-dt * 10.0));
		lastPos = pos;
		lastYaw = yaw;

		double yr = Math.toRadians(yaw);
		double fwd = vx * -Math.sin(yr) + vz * Math.cos(yr);
		double right = vx * -Math.cos(yr) + vz * -Math.sin(yr);
		double t = now / 1e9;
		double wind = 0.07 + Math.max(0.0, fwd) * 0.085 + Math.max(0.0, -vy) * 0.022 - Math.max(0.0, vy) * 0.01
				+ Math.sin(t * 1.7) * 0.012 + Math.sin(t * 2.9 + 1.3) * 0.008;
		double side = -right * 0.05 - Math.toRadians(yawRate) * 0.035;
		float tp = (float) Math.max(0.0, Math.min(1.1, wind * swing));
		float tr = (float) Math.max(-0.45, Math.min(0.45, side * swing));

		int steps = Math.max(1, (int) Math.ceil(dt / 0.008));
		float h = (float) (dt / steps);
		for (int s = 0; s < steps; s++) {
			for (int i = 0; i < M; i++) {
				float k2 = i == 0 ? 90f : 60f, c2 = i == 0 ? 13f : 9.5f;
				// lower nodes follow the one above and are blown a little further out
				float tgtP = i == 0 ? tp : A[i - 1] + tp * 0.05f;
				float tgtR = i == 0 ? tr : R[i - 1];
				AV[i] += (k2 * (tgtP - A[i]) - c2 * AV[i]) * h;
				A[i] += AV[i] * h;
				if (A[i] < 0.0f) { // the body is in the way
					A[i] = 0.0f;
					if (AV[i] < 0.0f) AV[i] = 0.0f;
				}
				if (A[i] > 1.4f) {
					A[i] = 1.4f;
					AV[i] = 0f;
				}
				RV[i] += (k2 * (tgtR - R[i]) - c2 * RV[i]) * h;
				R[i] += RV[i] * h;
			}
		}
		shape();
	}

	/** Absolute angle of node j is the sum of the bends above it; strips take smooth values between nodes and chain together. */
	private static void shape() {
		float ox = 0f, oy = 0f, oz = 0f;
		for (int i = 0; i < N; i++) {
			float s = (i + 0.5f) / N * (M - 1);
			float a = sample(A, s), r = sample(R, s);
			// cumulative: node angles are already absolute, but the cape may never bend into the body
			SP[i] = Math.max(0f, a);
			SR[i] = r;
			PX[i] = ox;
			PY[i] = oy;
			PZ[i] = oz;
			// strip direction for pitch a (about x) then roll r (about z)
			float ca = (float) Math.cos(SP[i]), sa = (float) Math.sin(SP[i]);
			ox += -ca * (float) Math.sin(r) * STRIP;
			oy += ca * (float) Math.cos(r) * STRIP;
			oz += sa * STRIP;
		}
	}
}
