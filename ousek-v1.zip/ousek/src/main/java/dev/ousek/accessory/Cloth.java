package dev.ousek.accessory;

import net.minecraft.client.MinecraftClient;
import net.minecraft.util.math.Vec3d;

/**
 * Cape physics: a chain of {@link Catalog#CAPE_SEGS} springs. The top strip is pushed by the wind your movement makes
 * (forward speed, falling, strafing), every lower strip follows the one above with a delay, so a wave runs down the cape.
 * It integrates in real time on smoothed per-frame positions, so it stays fluid at any FPS and does not step with ticks.
 */
final class Cloth {
	private static final int N = Catalog.CAPE_SEGS;
	private static final float[] A = new float[N], AV = new float[N]; // absolute pitch + velocity
	private static final float[] R = new float[N], RV = new float[N]; // absolute roll + velocity
	private static Vec3d lastPos;
	private static long lastNs;
	private static double vx, vy, vz;
	private static float lastYaw;
	private static double yawRate;

	private Cloth() {
	}

	static float relPitch(int i) {
		return i == 0 ? A[0] : A[i] - A[i - 1];
	}

	static float relRoll(int i) {
		return i == 0 ? R[0] : R[i] - R[i - 1];
	}

	static void update(MinecraftClient mc, double swing) {
		if (mc.player == null) return;
		long now = System.nanoTime();
		double dt = (now - lastNs) / 1e9;
		if (dt < 0.0015) return; // already stepped this frame (the feature can render more than once)
		boolean first = lastPos == null || dt > 0.5;
		lastNs = now;
		Vec3d pos = mc.player.getLerpedPos(mc.getRenderTickCounter().getTickProgress(false));
		float yaw = mc.player.getYaw();
		if (first) {
			lastPos = pos;
			lastYaw = yaw;
			return;
		}
		dt = Math.min(dt, 0.05);
		// velocity from the interpolated position, low-passed so it is smooth between ticks
		double k = 1.0 - Math.exp(-dt * 14.0);
		vx += ((pos.x - lastPos.x) / dt - vx) * k;
		vy += ((pos.y - lastPos.y) / dt - vy) * k;
		vz += ((pos.z - lastPos.z) / dt - vz) * k;
		double dy = ((yaw - lastYaw + 540.0) % 360.0) - 180.0;
		yawRate += (dy / dt - yawRate) * (1.0 - Math.exp(-dt * 10.0));
		lastPos = pos;
		lastYaw = yaw;

		double yr = Math.toRadians(yaw);
		double fwd = vx * -Math.sin(yr) + vz * Math.cos(yr);
		double right = vx * -Math.cos(yr) + vz * -Math.sin(yr);
		double t = now / 1e9;
		double wind = 0.07 + Math.max(0.0, fwd) * 0.085 + Math.max(0.0, -vy) * 0.022 - Math.max(0.0, vy) * 0.01
				+ Math.sin(t * 1.7) * 0.012 + Math.sin(t * 2.9 + 1.3) * 0.008;
		double side = -right * 0.05 - Math.toRadians(yawRate) * 0.035;
		float tp = (float) Math.max(0.0, Math.min(1.25, wind * swing));
		float tr = (float) Math.max(-0.5, Math.min(0.5, side * swing));

		int steps = Math.max(1, (int) Math.ceil(dt / 0.008));
		float h = (float) (dt / steps);
		for (int s = 0; s < steps; s++) {
			for (int i = 0; i < N; i++) {
				float k2 = i == 0 ? 70f : 46f, c2 = i == 0 ? 11f : 7.5f;
				float tgtP = i == 0 ? tp : A[i - 1] + tp * 0.04f;
				float tgtR = i == 0 ? tr : R[i - 1];
				AV[i] += (k2 * (tgtP - A[i]) - c2 * AV[i]) * h;
				A[i] += AV[i] * h;
				if (A[i] < 0.0f) { // the body is in the way
					A[i] = 0.0f;
					if (AV[i] < 0.0f) AV[i] = 0.0f;
				}
				if (A[i] > 1.5f) {
					A[i] = 1.5f;
					AV[i] = 0f;
				}
				RV[i] += (k2 * (tgtR - R[i]) - c2 * RV[i]) * h;
				R[i] += RV[i] * h;
			}
		}
	}
}
