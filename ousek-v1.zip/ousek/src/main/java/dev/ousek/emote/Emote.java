package dev.ousek.emote;

import com.google.gson.JsonArray;
import com.google.gson.JsonElement;
import com.google.gson.JsonObject;
import com.google.gson.JsonParser;
import dev.ousek.module.Anims;

import java.util.ArrayList;
import java.util.List;

/** One Emotecraft-format emote (.json): keyframes per body part and axis. */
public final class Emote {
	public static final String[] PARTS = {"head", "body", "rightArm", "leftArm", "rightLeg", "leftLeg"};
	public static final String[] PARAMS = {"x", "y", "z", "pitch", "yaw", "roll"};

	static final class Track {
		int[] ticks;
		float[] vals;
		int[] ease; // -1 linear, -2 constant, else Anims.NAMES index
	}

	public final String id, name, author, description;
	public final String icon; // Tex path or null
	public final int begin, end, stop, ret;
	public final boolean loop;
	final Track[][] tracks = new Track[PARTS.length][PARAMS.length];

	private Emote(String id, JsonObject root, String icon) {
		JsonObject e = root.getAsJsonObject("emote");
		this.id = id;
		this.icon = icon;
		this.name = clean(str(root, "name", id));
		this.author = clean(str(root, "author", ""));
		this.description = clean(str(root, "description", ""));
		this.begin = num(e, "beginTick", 0);
		int endTick = num(e, "endTick", 1);
		this.end = Math.max(1, endTick);
		this.stop = Math.max(this.end, num(e, "stopTick", endTick));
		this.ret = Math.max(0, Math.min(this.end - 1, num(e, "returnTick", 0)));
		this.loop = e.has("isLoop") && e.get("isLoop").getAsBoolean();
		boolean degrees = e.has("degrees") && e.get("degrees").getAsBoolean();

		@SuppressWarnings("unchecked")
		List<double[]>[][] raw = new List[PARTS.length][PARAMS.length];
		JsonArray moves = e.has("moves") ? e.getAsJsonArray("moves") : new JsonArray();
		for (JsonElement el : moves) {
			JsonObject mv = el.getAsJsonObject();
			int tick = mv.has("tick") ? mv.get("tick").getAsInt() : 0;
			int ease = easeIndex(mv.has("easing") ? mv.get("easing").getAsString() : "linear");
			for (int p = 0; p < PARTS.length; p++) {
				JsonObject part = null;
				if (mv.has(PARTS[p]) && mv.get(PARTS[p]).isJsonObject()) part = mv.getAsJsonObject(PARTS[p]);
				else if (p == 1 && mv.has("torso") && mv.get("torso").isJsonObject()) part = mv.getAsJsonObject("torso");
				if (part == null) continue;
				for (int q = 0; q < PARAMS.length; q++) {
					if (!part.has(PARAMS[q]) || !part.get(PARAMS[q]).isJsonPrimitive()) continue;
					double v = part.get(PARAMS[q]).getAsDouble();
					if (degrees && q >= 3) v = Math.toRadians(v);
					if (raw[p][q] == null) raw[p][q] = new ArrayList<>();
					raw[p][q].add(new double[]{tick, v, ease});
				}
			}
		}
		for (int p = 0; p < PARTS.length; p++) {
			for (int q = 0; q < PARAMS.length; q++) {
				List<double[]> l = raw[p][q];
				if (l == null || l.isEmpty()) continue;
				l.sort((a, b) -> Double.compare(a[0], b[0]));
				Track t = new Track();
				t.ticks = new int[l.size()];
				t.vals = new float[l.size()];
				t.ease = new int[l.size()];
				for (int i = 0; i < l.size(); i++) {
					t.ticks[i] = (int) l.get(i)[0];
					t.vals[i] = (float) l.get(i)[1];
					t.ease[i] = (int) l.get(i)[2];
				}
				tracks[p][q] = t;
			}
		}
	}

	public static Emote parse(String id, String json, String icon) {
		try {
			JsonObject root = JsonParser.parseString(json).getAsJsonObject();
			if (!root.has("emote")) return null;
			return new Emote(id, root, icon);
		} catch (Throwable t) {
			return null;
		}
	}

	private static String str(JsonObject o, String k, String d) {
		return o.has(k) && o.get(k).isJsonPrimitive() ? o.get(k).getAsString() : d;
	}

	private static int num(JsonObject o, String k, int d) {
		return o.has(k) && o.get(k).isJsonPrimitive() ? o.get(k).getAsInt() : d;
	}

	private static String clean(String s) {
		return s.replaceAll("§.", "").trim();
	}

	/** Emotecraft easing names (LINEAR, CONSTANT, INSINE, OUTQUAD, INOUTBACK ...) -> Anims curve index. */
	static int easeIndex(String raw) {
		String s = raw.toLowerCase().replace("_", "");
		if (s.equals("linear")) return -1;
		if (s.equals("constant")) return -2;
		String mode;
		String rest;
		if (s.startsWith("inout")) {
			mode = "InOut";
			rest = s.substring(5);
		} else if (s.startsWith("in")) {
			mode = "In";
			rest = s.substring(2);
		} else if (s.startsWith("out")) {
			mode = "Out";
			rest = s.substring(3);
		} else {
			return -1;
		}
		String fam = switch (rest) {
			case "sine" -> "Sine";
			case "quad" -> "Quad";
			case "cubic" -> "Cubic";
			case "quart" -> "Quart";
			case "quint" -> "Quint";
			case "expo" -> "Expo";
			case "circ" -> "Circ";
			case "back" -> "Back";
			case "elastic" -> "Elastic";
			case "bounce" -> "Bounce";
			default -> null;
		};
		if (fam == null) return -1;
		int i = Anims.indexOf(fam + " " + mode);
		return i <= 0 ? -1 : i;
	}

	public boolean hasTrack(int part) {
		for (int q = 0; q < PARAMS.length; q++) if (tracks[part][q] != null) return true;
		return false;
	}

	/** Value of one track at a tick (float), or NaN if this emote does not animate it. */
	public float sample(int part, int param, float tick) {
		Track t = tracks[part][param];
		if (t == null) return Float.NaN;
		int n = t.ticks.length;
		if (tick <= t.ticks[0]) {
			// Emotecraft starts every track from the default pose (0) at tick 0 and eases into the first keyframe
			if (t.ticks[0] <= 0) return t.vals[0];
			if (tick <= 0) return 0f;
			float f0 = tick / t.ticks[0];
			int ez0 = t.ease[0];
			if (ez0 == -2) f0 = 0f;
			else if (ez0 >= 0) f0 = (float) Anims.raw(ez0, f0);
			return t.vals[0] * f0;
		}
		if (tick >= t.ticks[n - 1]) return t.vals[n - 1];
		int i = 1;
		while (i < n && t.ticks[i] < tick) i++;
		int a = i - 1;
		float span = t.ticks[i] - t.ticks[a];
		if (span <= 0) return t.vals[i];
		float f = (tick - t.ticks[a]) / span;
		int ez = t.ease[i];
		if (ez == -2) f = 0f;
		else if (ez >= 0) f = (float) Anims.raw(ez, f);
		return t.vals[a] + (t.vals[i] - t.vals[a]) * f;
	}
}
