package dev.ousek.emote;

import java.util.ArrayList;
import java.util.List;

/** Parsed EmoteCraft-style JSON emote. */
public final class EmoteData {
	public String id;
	public String name;
	public String author;
	public String description;
	public String iconPath; // resource path relative to assets, or absolute file for texture id
	public int beginTick;
	public int endTick;
	public int stopTick;
	public boolean isLoop;
	public boolean degrees;
	public final List<KeyFrame> moves = new ArrayList<>();

	public static final class KeyFrame {
		public int tick;
		public String easing = "Linear";
		public Part head;
		public Part torso;
		public Part rightArm;
		public Part leftArm;
		public Part rightLeg;
		public Part leftLeg;
	}

	public static final class Part {
		public float x, y, z;
		public float pitch, yaw, roll;
	}
}
