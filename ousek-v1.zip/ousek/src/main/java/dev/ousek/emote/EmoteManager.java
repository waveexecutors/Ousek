package dev.ousek.emote;

import dev.ousek.gui.Tex;
import dev.ousek.module.Util;
import dev.ousek.module.impl.WindowModules;
import net.fabricmc.loader.api.FabricLoader;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.model.ModelPart;
import net.minecraft.client.option.Perspective;
import net.minecraft.client.render.entity.model.PlayerEntityModel;

import java.io.BufferedReader;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.nio.charset.StandardCharsets;
import java.nio.file.Files;
import java.nio.file.Path;
import java.util.ArrayList;
import java.util.List;
import java.util.stream.Stream;

/** Loads the emote JSONs and plays one on the local player's model (hooked in PlayerEntityModelMixin). */
public final class EmoteManager {
	public static final List<Emote> ALL = new ArrayList<>();
	public static volatile Emote current;
	private static long startNs, stopNs;
	private static boolean stopping;
	private static Perspective savedPerspective;
	private static boolean switched;
	private static boolean loaded;

	private EmoteManager() {
	}

	public static synchronized void load() {
		if (loaded) return;
		loaded = true;
		try (InputStream in = EmoteManager.class.getResourceAsStream("/assets/ousek/emotes/index.txt")) {
			if (in != null) {
				BufferedReader r = new BufferedReader(new InputStreamReader(in, StandardCharsets.UTF_8));
				String id;
				while ((id = r.readLine()) != null) {
					id = id.trim();
					if (id.isEmpty()) continue;
					try (InputStream js = EmoteManager.class.getResourceAsStream("/assets/ousek/emotes/" + id + ".json")) {
						if (js == null) continue;
						String icon = Tex.has("emotes/" + id) ? "emotes/" + id : null;
						Emote e = Emote.parse(id, new String(js.readAllBytes(), StandardCharsets.UTF_8), icon);
						if (e != null) ALL.add(e);
					}
				}
			}
		} catch (Throwable ignored) {
		}
		// extra emotes: drop any Emotecraft .json into <game dir>/ousek/emotes
		try {
			Path dir = FabricLoader.getInstance().getGameDir().resolve("ousek").resolve("emotes");
			Files.createDirectories(dir);
			try (Stream<Path> s = Files.walk(dir, 2)) {
				s.filter(p -> p.toString().toLowerCase().endsWith(".json")).sorted().forEach(p -> {
					try {
						String id = "user_" + p.getFileName().toString().replaceAll("(?i)\\.json$", "");
						Emote e = Emote.parse(id, Files.readString(p, StandardCharsets.UTF_8), null);
						if (e != null) ALL.add(e);
					} catch (Throwable ignored) {
					}
				});
			}
		} catch (Throwable ignored) {
		}
	}

	public static boolean isPlaying(Emote e) {
		return current == e && !stopping;
	}

	public static void play(Emote e) {
		MinecraftClient mc = MinecraftClient.getInstance();
		if (e == null || mc.player == null) return;
		current = e;
		stopping = false;
		startNs = System.nanoTime();
		WindowModules.Emotes cfg = WindowModules.emotes();
		if (cfg != null && cfg.thirdPerson.on() && mc.options.getPerspective().isFirstPerson()) {
			savedPerspective = mc.options.getPerspective();
			mc.options.setPerspective(Perspective.THIRD_PERSON_BACK);
			switched = true;
		}
	}

	public static void stop() {
		if (current != null && !stopping) {
			stopping = true;
			stopNs = System.nanoTime();
		}
	}

	private static void finish() {
		current = null;
		stopping = false;
		MinecraftClient mc = MinecraftClient.getInstance();
		if (switched && savedPerspective != null && mc.options.getPerspective() == Perspective.THIRD_PERSON_BACK) {
			mc.options.setPerspective(savedPerspective);
		}
		switched = false;
		savedPerspective = null;
	}

	public static void tick() {
		MinecraftClient mc = MinecraftClient.getInstance();
		if (current == null) return;
		if (mc.player == null || mc.world == null) {
			current = null;
			stopping = false;
			switched = false;
			return;
		}
		WindowModules.Emotes cfg = WindowModules.emotes();
		boolean whileMoving = cfg == null || cfg.whileMoving.on();
		if (!whileMoving && !stopping) {
			boolean moving = Util.moving() || mc.options.jumpKey.isPressed() || !mc.player.isOnGround();
			if (moving) stop();
		}
		if (stopping && (System.nanoTime() - stopNs) / 50_000_000.0 > 5.0) finish();
	}

	private static double speed() {
		WindowModules.Emotes cfg = WindowModules.emotes();
		return cfg == null ? 1.0 : cfg.speed.get();
	}

	private static boolean loop(Emote e) {
		WindowModules.Emotes cfg = WindowModules.emotes();
		return cfg == null ? e.loop : cfg.loop.on();
	}

	/** Called at the end of PlayerEntityModel.setAngles. x,y,z = render state position. */
	public static void apply(PlayerEntityModel model, double sx, double sy, double sz) {
		Emote e = current;
		MinecraftClient mc = MinecraftClient.getInstance();
		if (e == null || mc.player == null) return;
		double dx = sx - mc.player.getX(), dy = sy - mc.player.getY(), dz = sz - mc.player.getZ();
		if (dx * dx + dy * dy + dz * dz > 1.5) return; // not the local player

		double ticks = (System.nanoTime() - startNs) / 50_000_000.0 * speed();
		float w = (float) Math.min(1.0, ticks / 4.0);
		float tick = (float) ticks;
		boolean lp = loop(e);
		if (lp && e.end > e.ret) {
			if (tick >= e.end) {
				float len = e.end - e.ret;
				tick = e.ret + ((tick - e.ret) % len);
			}
		} else if (tick > e.stop) {
			if (!stopping) stop();
			tick = e.stop;
		}
		if (stopping) {
			float out = (float) ((System.nanoTime() - stopNs) / 50_000_000.0 / 5.0);
			w = Math.min(w, Math.max(0f, 1f - out));
		}
		if (w <= 0f) return;

		ModelPart[] parts = {model.head, model.body, model.rightArm, model.leftArm, model.rightLeg, model.leftLeg};
		float[][] v = new float[6][6];
		for (int p = 0; p < 6; p++) for (int q = 0; q < 6; q++) v[p][q] = e.sample(p, q, tick);

		// torso moves the head and arms with it (legs stay on the ground)
		float bx = nz(v[1][0]) * 16f, by = -nz(v[1][1]) * 16f, bz = nz(v[1][2]) * 16f;
		float bp = nz(v[1][3]), by2 = nz(v[1][4]), br = nz(v[1][5]);
		boolean bodyMoves = e.hasTrack(1);

		for (int p = 0; p < 6; p++) {
			ModelPart mp = parts[p];
			if (mp == null) continue;
			float px = mp.pivotX, py = mp.pivotY, pz = mp.pivotZ;
			float tx = px + (Float.isNaN(v[p][0]) ? 0f : v[p][0] * 16f);
			float ty = py + (Float.isNaN(v[p][1]) ? 0f : -v[p][1] * 16f);
			float tz = pz + (Float.isNaN(v[p][2]) ? 0f : v[p][2] * 16f);
			float rp = Float.isNaN(v[p][3]) ? mp.pitch : v[p][3];
			float ry = Float.isNaN(v[p][4]) ? mp.yaw : v[p][4];
			float rr = Float.isNaN(v[p][5]) ? mp.roll : v[p][5];
			if (p == 0) { // head keeps following your look direction, the emote adds on top
				rp = mp.pitch + nz(v[p][3]);
				ry = mp.yaw + nz(v[p][4]);
				rr = mp.roll + nz(v[p][5]);
			}
			if (bodyMoves && (p == 0 || p == 2 || p == 3)) {
				float[] r = rotate(tx, ty, tz, bp, by2, br);
				tx = r[0] + bx;
				ty = r[1] + by;
				tz = r[2] + bz;
				rp += bp;
				ry += by2;
				rr += br;
			} else if (p == 1) {
				tx = px + bx;
				ty = py + by;
				tz = pz + bz;
			}
			mp.pivotX = px + (tx - px) * w;
			mp.pivotY = py + (ty - py) * w;
			mp.pivotZ = pz + (tz - pz) * w;
			mp.pitch = mp.pitch + (rp - mp.pitch) * w;
			mp.yaw = mp.yaw + (ry - mp.yaw) * w;
			mp.roll = mp.roll + (rr - mp.roll) * w;
		}

		// overlay layers (hat, jacket, sleeves, pants) must follow the parts they sit on
		copy(model, "hat", parts[0]);
		copy(model, "jacket", parts[1]);
		copy(model, "right_sleeve", parts[2]);
		copy(model, "left_sleeve", parts[3]);
		copy(model, "right_pants", parts[4]);
		copy(model, "left_pants", parts[5]);
	}

	private static float nz(float f) {
		return Float.isNaN(f) ? 0f : f;
	}

	private static void copy(PlayerEntityModel model, String name, ModelPart src) {
		try {
			model.getRootPart().getChild(name).copyTransform(src);
		} catch (Throwable ignored) {
		}
	}

	/** Same order as ModelPart: pitch (X) first, then yaw (Y), then roll (Z). */
	private static float[] rotate(float x, float y, float z, float pitch, float yaw, float roll) {
		float c = (float) Math.cos(pitch), s = (float) Math.sin(pitch);
		float y1 = y * c - z * s, z1 = y * s + z * c;
		c = (float) Math.cos(yaw);
		s = (float) Math.sin(yaw);
		float x2 = x * c + z1 * s, z2 = -x * s + z1 * c;
		c = (float) Math.cos(roll);
		s = (float) Math.sin(roll);
		float x3 = x2 * c - y1 * s, y3 = x2 * s + y1 * c;
		return new float[]{x3, y3, z2};
	}
}
