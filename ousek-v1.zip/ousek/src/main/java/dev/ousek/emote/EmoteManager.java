package dev.ousek.emote;

import com.google.gson.JsonArray;
import com.google.gson.JsonElement;
import com.google.gson.JsonObject;
import com.google.gson.JsonParser;
import net.minecraft.client.MinecraftClient;
import net.minecraft.resource.Resource;
import net.minecraft.resource.ResourceManager;
import net.minecraft.util.Identifier;

import java.io.InputStream;
import java.io.InputStreamReader;
import java.nio.charset.StandardCharsets;
import java.util.ArrayList;
import java.util.List;
import java.util.Optional;

public final class EmoteManager {
	public static final List<EmoteData> EMOTES = new ArrayList<>();
	public static EmoteData playing;
	public static int tick;
	public static boolean loop = true;
	public static boolean allowMove = true;
	public static boolean loaded;

	private static final String[] FOLDERS = {
			"caramelldansen", "bloodpop", "jumpstyle", "miku", "phuthon", "sadcat1", "sadcat2"
	};

	private EmoteManager() {
	}

	public static void ensureLoaded() {
		if (loaded) return;
		loaded = true;
		EMOTES.clear();
		MinecraftClient mc = MinecraftClient.getInstance();
		if (mc == null) return;
		ResourceManager rm = mc.getResourceManager();

		for (String folder : FOLDERS) {
			// paths must be [a-z0-9/._-] only
			Identifier id = Identifier.of("ousek", "emotes/" + folder + "/emote.json");
			try {
				Optional<Resource> res = rm.getResource(id);
				if (res.isEmpty()) continue;
				try (InputStream in = res.get().getInputStream();
					 InputStreamReader reader = new InputStreamReader(in, StandardCharsets.UTF_8)) {
					JsonObject root = JsonParser.parseReader(reader).getAsJsonObject();
					EmoteData e = parse(root, folder);
					if (e != null) EMOTES.add(e);
				}
			} catch (Throwable t) {
				// skip broken emote, never crash title screen
			}
		}
	}

	static EmoteData parse(JsonObject root, String folder) {
		EmoteData e = new EmoteData();
		e.id = folder;
		e.name = root.has("name") ? root.get("name").getAsString() : folder;
		e.author = root.has("author") ? root.get("author").getAsString() : "";
		e.description = root.has("description") ? root.get("description").getAsString() : "";
		e.iconPath = "ousek:emotes/" + folder + "/icon.png";
		if (!root.has("emote")) return e;
		JsonObject em = root.getAsJsonObject("emote");
		e.beginTick = em.has("beginTick") ? em.get("beginTick").getAsInt() : 0;
		e.endTick = em.has("endTick") ? em.get("endTick").getAsInt() : 20;
		e.stopTick = em.has("stopTick") ? em.get("stopTick").getAsInt() : e.endTick;
		e.isLoop = em.has("isLoop") && em.get("isLoop").getAsBoolean();
		e.degrees = em.has("degrees") && em.get("degrees").getAsBoolean();
		if (em.has("moves") && em.get("moves").isJsonArray()) {
			JsonArray arr = em.getAsJsonArray("moves");
			for (JsonElement el : arr) {
				if (!el.isJsonObject()) continue;
				JsonObject m = el.getAsJsonObject();
				EmoteData.KeyFrame kf = new EmoteData.KeyFrame();
				kf.tick = m.has("tick") ? m.get("tick").getAsInt() : 0;
				kf.easing = m.has("easing") ? m.get("easing").getAsString() : "Linear";
				kf.head = part(m, "head");
				kf.torso = part(m, "torso");
				kf.rightArm = part(m, "rightArm");
				kf.leftArm = part(m, "leftArm");
				kf.rightLeg = part(m, "rightLeg");
				kf.leftLeg = part(m, "leftLeg");
				e.moves.add(kf);
			}
		}
		return e;
	}

	static EmoteData.Part part(JsonObject m, String key) {
		if (!m.has(key) || !m.get(key).isJsonObject()) return null;
		JsonObject p = m.getAsJsonObject(key);
		EmoteData.Part part = new EmoteData.Part();
		part.x = f(p, "x");
		part.y = f(p, "y");
		part.z = f(p, "z");
		part.pitch = f(p, "pitch");
		part.yaw = f(p, "yaw");
		part.roll = f(p, "roll");
		return part;
	}

	static float f(JsonObject o, String k) {
		return o.has(k) ? o.get(k).getAsFloat() : 0f;
	}

	public static void play(EmoteData e) {
		playing = e;
		tick = e != null ? e.beginTick : 0;
	}

	public static void stop() {
		playing = null;
		tick = 0;
	}

	public static void tickClient() {
		if (playing == null) return;
		try {
			tick++;
			int end = Math.max(playing.endTick, playing.stopTick);
			if (tick > end) {
				if (loop || playing.isLoop) {
					tick = playing.beginTick;
				} else {
					stop();
				}
			}
		} catch (Throwable ignored) {
			stop();
		}
	}

	/** Current interpolated part pose for the active emote, or null. */
	public static EmoteData.Part pose(String which) {
		if (playing == null || playing.moves.isEmpty()) return null;
		try {
			EmoteData.KeyFrame a = null, b = null;
			for (EmoteData.KeyFrame kf : playing.moves) {
				if (kf.tick <= tick) a = kf;
				if (kf.tick >= tick && b == null) b = kf;
			}
			if (a == null) a = playing.moves.get(0);
			if (b == null) b = a;
			float t = 0f;
			if (a != b && b.tick != a.tick) {
				t = (tick - a.tick) / (float) (b.tick - a.tick);
				t = Math.max(0f, Math.min(1f, t));
			}
			EmoteData.Part pa = pick(a, which);
			EmoteData.Part pb = pick(b, which);
			if (pa == null && pb == null) return null;
			if (pa == null) return pb;
			if (pb == null) return pa;
			EmoteData.Part out = new EmoteData.Part();
			out.pitch = pa.pitch + (pb.pitch - pa.pitch) * t;
			out.yaw = pa.yaw + (pb.yaw - pa.yaw) * t;
			out.roll = pa.roll + (pb.roll - pa.roll) * t;
			out.x = pa.x + (pb.x - pa.x) * t;
			out.y = pa.y + (pb.y - pa.y) * t;
			out.z = pa.z + (pb.z - pa.z) * t;
			return out;
		} catch (Throwable ignored) {
			return null;
		}
	}

	static EmoteData.Part pick(EmoteData.KeyFrame kf, String which) {
		return switch (which) {
			case "head" -> kf.head;
			case "torso" -> kf.torso;
			case "rightArm" -> kf.rightArm;
			case "leftArm" -> kf.leftArm;
			case "rightLeg" -> kf.rightLeg;
			case "leftLeg" -> kf.leftLeg;
			default -> null;
		};
	}
}
