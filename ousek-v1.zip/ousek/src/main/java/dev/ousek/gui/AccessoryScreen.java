package dev.ousek.gui;

import dev.ousek.accessory.Catalog;
import dev.ousek.config.Config;
import dev.ousek.module.impl.WindowModules;
import dev.ousek.setting.Setting;
import net.minecraft.client.gui.DrawContext;
import net.minecraft.client.gui.screen.Screen;
import net.minecraft.text.Text;
import net.minecraft.util.math.MathHelper;
import org.lwjgl.glfw.GLFW;

import java.util.List;

/** Window to pick wings, masks, capes, bandanas and halos for your character. */
public class AccessoryScreen extends Screen {
	private static final int W = 424, H = 290, CW = 98, CH = 36, GAP = 4;
	private static final int[] PALETTE = {
			0xC81E2D, 0x6E0A19, 0xFF7882, 0x286EE6, 0x0F328C, 0x82BEFF, 0x1EAA50, 0x0A5A28, 0x82E696,
			0x963CDC, 0x50198A, 0xD296FF, 0xFAFAFA, 0x19191E, 0xF5C832, 0x78788A, 0xC8C8D2, 0xF0E6C8,
			0xFF96C8, 0x50E6F0, 0xFA8C1E};
	private static Catalog.Cat tab = Catalog.Cat.WINGS;
	private final Screen parent;
	private boolean pl = true;
	private float scroll, scrollT;

	public AccessoryScreen(Screen parent) {
		super(Text.literal("Accessories"));
		this.parent = parent;
	}

	@Override
	protected void init() {
		pl = GLFW.glfwGetMouseButton(Ui.handle(), 0) == GLFW.GLFW_PRESS;
	}

	@Override
	public boolean shouldPause() {
		return false;
	}

	@Override
	public void renderBackground(DrawContext ctx, int mouseX, int mouseY, float delta) {
	}

	@Override
	public void close() {
		Config.save();
		if (client != null) client.setScreen(parent);
	}

	@Override
	public boolean mouseScrolled(double mx, double my, double hAmount, double vAmount) {
		scrollT -= (float) vAmount * 24f;
		return true;
	}

	private static int col(int idx) {
		return 0xFF000000 | PALETTE[Math.max(0, Math.min(PALETTE.length - 1, idx))];
	}

	@Override
	public void render(DrawContext ctx, int mx, int my, float delta) {
		boolean l = GLFW.glfwGetMouseButton(Ui.handle(), 0) == GLFW.GLFW_PRESS;
		boolean click = l && !pl;
		pl = l;
		int acc = Theme.accent();
		WindowModules.Wardrobe cfg = WindowModules.wardrobe();
		if (cfg == null) return;

		ctx.fill(0, 0, width, height, 0x88000000);
		int x = (width - W) / 2, y = (height - H) / 2;
		Ui.window(ctx, textRenderer, x, y, W, H, "Accessories  (" + Catalog.ALL.size() + ")", null, acc);

		boolean hc = Theme.in(mx, my, x + W - 18, y + 3, 14, 14);
		Ui.iconButton(ctx, x + W - 18, y + 3, 14, 14, "08_new_gui_icons/newclose", hc, false, acc);
		if (hc && click) {
			close();
			return;
		}

		// tabs
		int tx = x + 8;
		for (Catalog.Cat c : Catalog.Cat.values()) {
			int w = textRenderer.getWidth(c.label) + 14;
			boolean hv = Theme.in(mx, my, tx, y + 25, w, 15);
			Ui.button(ctx, textRenderer, tx, y + 25, w, 15, c.label, hv, c == tab, acc);
			if (hv && click && c != tab) {
				tab = c;
				scroll = scrollT = 0;
			}
			tx += w + 4;
		}

		// grid: first cell is "None"
		Setting.Mode mode = cfg.mode(tab);
		List<Catalog.Item> items = Catalog.of(tab);
		int gx0 = x + 8, gy0 = y + 46, gx1 = x + W - 8, gy1 = y + H - 22;
		int cols = Math.max(1, (gx1 - gx0 + GAP) / (CW + GAP));
		int count = items.size() + 1;
		int rows = (count + cols - 1) / cols;
		float total = rows * (CH + GAP);
		scrollT = MathHelper.clamp(scrollT, 0f, Math.max(0f, total - (gy1 - gy0)));
		scroll += (scrollT - scroll) * 0.35f;

		ctx.enableScissor(gx0, gy0, gx1, gy1);
		for (int i = 0; i < count; i++) {
			int cx = gx0 + (i % cols) * (CW + GAP);
			int cy = gy0 + (i / cols) * (CH + GAP) - Math.round(scroll);
			if (cy + CH < gy0 || cy > gy1) continue;
			boolean on = mode.index() == i;
			boolean hv = Theme.in(mx, my, cx, cy, CW, CH) && my >= gy0 && my < gy1;
			Theme.rrect(ctx, cx, cy, CW, CH, 4, on ? acc : 0xFF1A1A20);
			Theme.rrect(ctx, cx + 1, cy + 1, CW - 2, CH - 2, 4, hv ? 0xFF24242C : 0xFF16161A);
			String name;
			if (i == 0) {
				name = "None";
				ctx.drawText(textRenderer, "-", cx + 8, cy + 8, 0xFF8A8A94, false);
			} else {
				Catalog.Item it = items.get(i - 1);
				name = it.name;
				ctx.fill(cx + 6, cy + 6, cx + 16, cy + 16, col(it.c1));
				ctx.fill(cx + 18, cy + 6, cx + 28, cy + 16, col(it.c2));
				ctx.fill(cx + 30, cy + 6, cx + 40, cy + 16, col(it.c3));
			}
			ctx.drawText(textRenderer, textRenderer.trimToWidth(name, CW - 10), cx + 6, cy + 22, on ? acc : 0xFFFFFFFF, false);
			if (hv && click) mode.setIndex(i);
		}
		ctx.disableScissor();

		String hint = "Only you see your accessories. Needs third person (F5) to look at them.";
		ctx.drawText(textRenderer, textRenderer.trimToWidth(hint, W - 16), x + 8, y + H - 14, 0xFF8A8A94, false);
	}
}
