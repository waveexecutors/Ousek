package dev.ousek.gui;

import net.minecraft.client.gl.RenderPipelines;
import net.minecraft.client.gui.DrawContext;
import net.minecraft.util.Identifier;

import javax.imageio.ImageIO;
import java.io.InputStream;
import java.util.HashMap;
import java.util.Map;

/** Draws the PNGs bundled in assets/ousek/textures/gui and /emotes. Never throws. */
public final class Tex {
	private static final Map<String, int[]> SIZES = new HashMap<>();
	private static final int[] NONE = new int[]{0, 0};

	private Tex() {
	}

	/** path like "01_category_icons/combat" (gui) or "emotes/miku" */
	private static String resource(String path) {
		return path.startsWith("emotes/") ? "textures/" + path + ".png" : "textures/gui/" + path + ".png";
	}

	public static Identifier id(String path) {
		return Identifier.of("ousek", resource(path));
	}

	public static int[] size(String path) {
		int[] s = SIZES.get(path);
		if (s != null) return s;
		try (InputStream in = Tex.class.getResourceAsStream("/assets/ousek/" + resource(path))) {
			if (in == null) {
				s = NONE;
			} else {
				var img = ImageIO.read(in);
				s = img == null ? NONE : new int[]{img.getWidth(), img.getHeight()};
			}
		} catch (Throwable t) {
			s = NONE;
		}
		SIZES.put(path, s);
		return s;
	}

	public static boolean has(String path) {
		return size(path)[0] > 0;
	}

	/** Draw stretched to w x h. */
	public static void draw(DrawContext c, String path, int x, int y, int w, int h, int argb) {
		int[] s = size(path);
		if (s[0] <= 0 || w <= 0 || h <= 0) return;
		try {
			c.drawTexture(RenderPipelines.GUI_TEXTURED, id(path), x, y, 0f, 0f, w, h, s[0], s[1], s[0], s[1], argb);
		} catch (Throwable ignored) {
		}
	}

	/** Draw keeping the aspect ratio, centered inside a box x,y,bw,bh. */
	public static void fit(DrawContext c, String path, int x, int y, int bw, int bh, int argb) {
		int[] s = size(path);
		if (s[0] <= 0) return;
		float k = Math.min(bw / (float) s[0], bh / (float) s[1]);
		int w = Math.max(1, Math.round(s[0] * k)), h = Math.max(1, Math.round(s[1] * k));
		draw(c, path, x + (bw - w) / 2, y + (bh - h) / 2, w, h, argb);
	}
}
