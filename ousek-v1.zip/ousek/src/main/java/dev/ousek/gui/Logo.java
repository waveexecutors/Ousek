package dev.ousek.gui;

import dev.ousek.module.ModuleManager;
import dev.ousek.module.impl.LogoModule;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.gui.DrawContext;

/** The Ousek logo, drawn from text (Proxima) plus an optional icon (assetsio font), fully customisable in the Logo module. */
public final class Logo {
	private Logo() {
	}

	/** Draws the logo at x,y (GUI px) and returns its width. alpha 0..1. */
	public static int draw(DrawContext c, int x, int y, float scale, float alpha) {
		return render(c, x, y, scale, alpha, true);
	}

	/** Width in GUI px without drawing. */
	public static int width(float scale) {
		return render(null, 0, 0, scale, 1f, false);
	}

	private static int render(DrawContext c, int x, int y, float scale, float alpha, boolean paint) {
		MinecraftClient mc = MinecraftClient.getInstance();
		LogoModule m = ModuleManager.get(LogoModule.class);
		String txt = m == null ? "OUSEK" : m.text();
		String mark = m == null ? "" : m.mark();
		float size = (float) (m == null ? 1.0 : m.size.get());
		int spacing = m == null ? 1 : (int) m.spacing.get();
		boolean shadow = m == null || m.shadow.on();
		boolean bold = m == null || m.bold.on();
		boolean v1 = m == null || m.showV1.on();
		float s = scale * size;
		int acc = Theme.accent();
		if (paint) {
			c.getMatrices().pushMatrix();
			c.getMatrices().translate((float) x, (float) y);
			c.getMatrices().scale(s, s);
		}
		int cx = 0;
		try {
			if (!mark.isEmpty()) {
				var t = Fonts.text(mark, Fonts.ICONS);
				if (paint) c.drawText(mc.textRenderer, t, 0, 0, Theme.fade(acc, alpha), shadow);
				cx += mc.textRenderer.getWidth(t) + 3;
			}
			int n = txt.length();
			for (int i = 0; i < n; i++) {
				String ch = String.valueOf(txt.charAt(i));
				var t = bold ? Fonts.bold(ch, Fonts.PROXIMA) : Fonts.text(ch, Fonts.PROXIMA);
				int col = m == null ? acc : m.color(i, n, acc);
				if (paint) c.drawText(mc.textRenderer, t, cx, 0, Theme.fade(col, alpha), shadow);
				cx += mc.textRenderer.getWidth(t) + spacing;
			}
			if (v1) {
				var t = Fonts.text(" v1", Fonts.PROXIMA);
				if (paint) c.drawText(mc.textRenderer, t, cx, 0, Theme.fade(0xFF8A8A94, alpha), false);
				cx += mc.textRenderer.getWidth(t);
			}
		} finally {
			if (paint) c.getMatrices().popMatrix();
		}
		return Math.round(cx * s);
	}
}
