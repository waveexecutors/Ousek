package dev.ousek.gui;

import dev.ousek.module.ModuleManager;
import dev.ousek.module.impl.LogoModule;
import net.minecraft.client.gui.DrawContext;

/** The Acid logo image. */
public final class Logo {
	private static final String TEX = "acid_logo";
	private static final int BASE_H = 10;

	private Logo() {
	}

	private static float size(float scale) {
		LogoModule m = ModuleManager.get(LogoModule.class);
		return scale * (m == null ? 1f : (float) m.size.get());
	}

	public static int height(float scale) {
		return Math.round(BASE_H * size(scale));
	}

	public static int width(float scale) {
		int[] s = Tex.size(TEX);
		return s[0] <= 0 ? 0 : Math.round(height(scale) * s[0] / (float) s[1]);
	}

	/** Draws the logo with its top-left corner at x,y and returns its width. */
	public static int draw(DrawContext c, int x, int y, float scale, float alpha) {
		int w = width(scale), h = height(scale);
		LogoModule m = ModuleManager.get(LogoModule.class);
		int col = m != null && m.tint.on() ? Theme.fade(Theme.accent(), alpha) : Theme.fade(0xFFFFFFFF, alpha);
		Tex.draw(c, TEX, x, y, w, h, col);
		return w;
	}
}
