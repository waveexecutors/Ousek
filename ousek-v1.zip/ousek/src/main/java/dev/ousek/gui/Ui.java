package dev.ousek.gui;

import net.minecraft.client.MinecraftClient;
import net.minecraft.client.gui.DrawContext;
import net.minecraft.client.font.TextRenderer;

/** Small drawing helpers shared by the Emote and Music windows (same look as the ClickGUI). */
public final class Ui {
	private Ui() {
	}

	public static void window(DrawContext c, TextRenderer tr, int x, int y, int w, int h, String title, String icon, int acc) {
		Theme.rrect(c, x - 1, y - 1, w + 2, h + 2, 6, Theme.alpha(acc, 0x50));
		Theme.rrect(c, x, y, w, h, 5, 0xFF0F0F12);
		c.fill(x + 5, y + 19, x + w - 5, y + 20, acc);
		int tx = x + 8;
		if (icon != null && Tex.has(icon)) {
			Tex.fit(c, icon, x + 6, y + 3, 14, 14, 0xFFFFFFFF);
			tx = x + 24;
		}
		c.drawText(tr, title, tx, y + 6, acc, false);
	}

	public static void button(DrawContext c, TextRenderer tr, int x, int y, int w, int h, String label, boolean hover, boolean active, int acc) {
		int bg = active ? Theme.alpha(acc, 0xE0) : (hover ? 0xFF2A2A32 : 0xFF1B1B21);
		Theme.rrect(c, x, y, w, h, 3, bg);
		int tw = tr.getWidth(label);
		c.drawText(tr, label, x + (w - tw) / 2, y + (h - 8) / 2, 0xFFFFFFFF, false);
	}

	public static void iconButton(DrawContext c, int x, int y, int w, int h, String icon, boolean hover, boolean active, int acc) {
		int bg = active ? Theme.alpha(acc, 0xE0) : (hover ? 0xFF2A2A32 : 0xFF1B1B21);
		Theme.rrect(c, x, y, w, h, 3, bg);
		Tex.fit(c, icon, x + 3, y + 3, w - 6, h - 6, 0xFFFFFFFF);
	}

	public static void toggle(DrawContext c, TextRenderer tr, int x, int y, String label, boolean on, boolean hover, int acc) {
		c.drawText(tr, label, x, y + 1, hover ? 0xFFFFFFFF : 0xFFB4B4BC, false);
		int bx = x + tr.getWidth(label) + 6;
		Theme.rrect(c, bx, y, 18, 8, 4, on ? acc : 0xFF2A2A31);
		Theme.rrect(c, bx + (on ? 11 : 1), y + 1, 6, 6, 3, 0xFFFFFFFF);
	}

	public static int toggleWidth(TextRenderer tr, String label) {
		return tr.getWidth(label) + 6 + 18;
	}

	public static void slider(DrawContext c, int x, int y, int w, float pct, int acc) {
		pct = Math.max(0f, Math.min(1f, pct));
		c.fill(x, y, x + w, y + 3, 0xFF2A2A31);
		int fw = Math.round(w * pct);
		c.fill(x, y, x + fw, y + 3, acc);
		c.fill(x + fw - 1, y - 1, x + fw + 2, y + 4, 0xFFFFFFFF);
	}

	public static long handle() {
		return MinecraftClient.getInstance().getWindow().getHandle();
	}
}
