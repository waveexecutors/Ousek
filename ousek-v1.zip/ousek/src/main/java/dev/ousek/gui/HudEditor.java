package dev.ousek.gui;

import dev.ousek.config.Config;
import dev.ousek.hud.HudElement;
import dev.ousek.module.Module;
import dev.ousek.module.ModuleManager;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.gui.DrawContext;
import net.minecraft.client.gui.screen.Screen;
import net.minecraft.text.Text;
import org.lwjgl.glfw.GLFW;

public class HudEditor extends Screen {
	private boolean pl = true;
	private HudElement drag;
	private int offX, offY;

	public HudEditor() {
		super(Text.literal("HUD Editor"));
	}

	@Override
	public boolean shouldPause() {
		return false;
	}

	@Override
	public void renderBackground(DrawContext ctx, int mouseX, int mouseY, float delta) {
	}

	@Override
	public void removed() {
		Config.save();
	}

	@Override
	public void render(DrawContext ctx, int mx, int my, float delta) {
		long h = MinecraftClient.getInstance().getWindow().getHandle();
		boolean l = GLFW.glfwGetMouseButton(h, 0) == GLFW.GLFW_PRESS;
		boolean le = l && !pl;
		pl = l;
		int acc = Theme.accent();

		ctx.fill(0, 0, width, height, 0x70000000);
		String t = "HUD Editor - drag elements to move them";
		Fonts.draw(ctx, textRenderer, t, width / 2 - Fonts.width(textRenderer, t) / 2, 8, 0xFFFFFFFF, true);
		String t2 = "Toggle elements and change colors/scale in ClickGUI > HUD";
		Fonts.draw(ctx, textRenderer, t2, width / 2 - Fonts.width(textRenderer, t2) / 2, 20, 0xFF9A9AA6, false);

		HudElement top = null;
		for (Module m : ModuleManager.modules) {
			if (m instanceof HudElement e && e.enabled) {
				int bx = e.boundsX(), by = e.y, bw = Math.max(8, e.boundsW()), bh = Math.max(8, e.boundsH());
				boolean hv = Theme.in(mx, my, bx, by, bw, bh);
				int c = (e == drag || hv) ? acc : Theme.alpha(acc, 0x80);
				ctx.fill(bx - 1, by - 1, bx + bw + 1, by, c);
				ctx.fill(bx - 1, by + bh, bx + bw + 1, by + bh + 1, c);
				ctx.fill(bx - 1, by, bx, by + bh, c);
				ctx.fill(bx + bw, by, bx + bw + 1, by + bh, c);
				Fonts.draw(ctx, textRenderer, e.name, bx, by - 10, c, true);
				if (hv) top = e;
			}
		}

		int bw = 90, by = height - 22;
		int bx1 = width / 2 - bw - 4, bx2 = width / 2 + 4;
		button(ctx, bx1, by, bw, "Reset layout", mx, my);
		button(ctx, bx2, by, bw, "Done", mx, my);
		boolean onButtons = my >= by;

		if (le && !onButtons && top != null) {
			drag = top;
			offX = mx - top.boundsX();
			offY = my - top.y;
		}
		if (le && Theme.in(mx, my, bx1, by, bw, 16)) {
			for (Module m : ModuleManager.modules) {
				if (m instanceof HudElement e) {
					e.reset();
					if (e.x < 0) e.x = width + e.x;
					if (e.y < 0) e.y = height + e.y;
				}
			}
		}
		if (le && Theme.in(mx, my, bx2, by, bw, 16)) {
			close();
			return;
		}
		if (drag != null) {
			if (l) {
				int nx = mx - offX;
				int ny = my - offY;
				drag.x = drag.right ? nx + drag.boundsW() : nx;
				drag.y = Math.max(0, ny);
			} else {
				drag = null;
			}
		}
	}

	private void button(DrawContext ctx, int x, int y, int w, String label, int mx, int my) {
		boolean hv = Theme.in(mx, my, x, y, w, 16);
		Theme.rrect(ctx, x, y, w, 16, 4, hv ? 0xFF24242C : 0xFF17171D);
		ctx.fill(x + 5, y + 15, x + w - 5, y + 16, Theme.accent());
		Fonts.draw(ctx, textRenderer, label, x + (w - Fonts.width(textRenderer, label)) / 2, y + 4, 0xFFFFFFFF, false);
	}
}
