package dev.ousek.gui;

import net.minecraft.text.MutableText;
import net.minecraft.text.Style;
import net.minecraft.text.Text;
import net.minecraft.util.Identifier;

import java.lang.reflect.Method;
import java.util.HashMap;
import java.util.Map;

/** Custom fonts (assets/ousek/font/*.json). The Style font setter changed between versions, so it is found by parameter type. */
public final class Fonts {
	public static final Identifier PROXIMA = Identifier.of("ousek", "proxima");
	public static final Identifier ICONS = Identifier.of("ousek", "icons");
	private static final Map<Identifier, Style> CACHE = new HashMap<>();

	private Fonts() {
	}

	public static Style style(Identifier font) {
		Style s = CACHE.get(font);
		if (s != null) return s;
		s = Style.EMPTY;
		try {
			for (Method m : Style.class.getMethods()) {
				if (m.getParameterCount() != 1 || m.getReturnType() != Style.class) continue;
				Class<?> pt = m.getParameterTypes()[0];
				Object arg = null;
				if (pt == Identifier.class) {
					arg = font;
				} else if (pt.isInterface()) {
					Class<?>[] subs = pt.getPermittedSubclasses() != null ? pt.getPermittedSubclasses() : pt.getDeclaredClasses();
					for (Class<?> cl : subs) {
						try {
							arg = cl.getConstructor(Identifier.class).newInstance(font);
							break;
						} catch (Throwable ignored) {
						}
					}
				}
				if (arg != null) {
					s = (Style) m.invoke(Style.EMPTY, arg);
					break;
				}
			}
		} catch (Throwable ignored) {
		}
		CACHE.put(font, s);
		return s;
	}

	public static MutableText text(String s, Identifier font) {
		return Text.literal(s).setStyle(style(font));
	}

	public static MutableText bold(String s, Identifier font) {
		return Text.literal(s).setStyle(style(font).withBold(true));
	}
}
