package dev.ousek.gui;

import dev.ousek.module.ModuleManager;
import dev.ousek.module.impl.ClickGuiModule;
import net.minecraft.client.gui.DrawContext;

import java.awt.Color;

public final class Theme {
	public static final String[] NAMES = {"Emerald", "Teal", "Violet", "Crimson", "Azure", "Gold", "Rose", "Custom"};
	private static final int[] PRESETS = {0x2BDB6A, 0x2EE6A6, 0x9B6BFF, 0xFF3B52, 0x3AA0FF, 0xFFC14A, 0xFF6BB5};
	private static ClickGuiModule cfg;

	private Theme() {
	}

	public static int accent() {
		if (cfg == null) cfg = ModuleManager.get(ClickGuiModule.class);
		if (cfg == null) return 0xFF2BDB6A;
		String t = cfg.theme.value;
		for (int i = 0; i < PRESETS.length; i++) {
			if (NAMES[i].equals(t)) return 0xFF000000 | PRESETS[i];
		}
		return 0xFF000000 | (cfg.red.i() << 16) | (cfg.green.i() << 8) | cfg.blue.i();
	}

	public static int rainbow(int offset) {
		float hue = ((System.currentTimeMillis() / 18 + offset * 14L) % 360) / 360f;
		return 0xFF000000 | (Color.HSBtoRGB(hue, 0.65f, 1f) & 0xFFFFFF);
	}

	public static int alpha(int color, int a) {
		return (a << 24) | (color & 0xFFFFFF);
	}

	public static int fade(int color, float f) {
		f = Math.max(0f, Math.min(1f, f));
		int a = (int) ((color >>> 24) * f);
		return (a << 24) | (color & 0xFFFFFF);
	}

	public static int lerp(int c1, int c2, float t) {
		t = Math.max(0f, Math.min(1f, t));
		int a = (int) (((c1 >>> 24) & 0xFF) + (((c2 >>> 24) & 0xFF) - ((c1 >>> 24) & 0xFF)) * t);
		int r = (int) (((c1 >> 16) & 0xFF) + (((c2 >> 16) & 0xFF) - ((c1 >> 16) & 0xFF)) * t);
		int g = (int) (((c1 >> 8) & 0xFF) + (((c2 >> 8) & 0xFF) - ((c1 >> 8) & 0xFF)) * t);
		int b = (int) ((c1 & 0xFF) + ((c2 & 0xFF) - (c1 & 0xFF)) * t);
		return (a << 24) | (r << 16) | (g << 8) | b;
	}

	public static float ease(float t) {
		t = Math.max(0f, Math.min(1f, t));
		return t * t * (3f - 2f * t);
	}

	public static boolean in(int mx, int my, int x, int y, int w, int h) {
		return mx >= x && mx < x + w && my >= y && my < y + h;
	}

	public static void rrect(DrawContext c, int x, int y, int w, int h, int r, int col) {
		rrect(c, x, y, w, h, r, col, true, true, true, true);
	}

	/**
	 * Smooth rounded rectangle: drawn in real framebuffer pixels with anti-aliased corner edges (no GUI-pixel stair steps).
	 * The flags pick which corners are rounded, so a header and a body can share one panel outline.
	 */
	public static void rrect(DrawContext c, int x, int y, int w, int h, int r, int col, boolean tl, boolean tr, boolean bl, boolean br) {
		if (w <= 0 || h <= 0) return;
		r = Math.min(r * 2 + 1, Math.min(w, h) / 2); // rounder than the raw radius
		double gs = 1.0;
		try {
			gs = Math.max(1.0, net.minecraft.client.MinecraftClient.getInstance().getWindow().getScaleFactor());
		} catch (Throwable ignored) {
		}
		if (r <= 0) {
			c.fill(x, y, x + w, y + h, col);
			return;
		}
		int X = (int) Math.round(x * gs), Y = (int) Math.round(y * gs), W = (int) Math.round(w * gs), H = (int) Math.round(h * gs);
		int R = (int) Math.round(r * gs);
		R = Math.min(R, Math.min(W, H) / 2);
		int alpha = col >>> 24;
		c.getMatrices().pushMatrix();
		c.getMatrices().scale((float) (1.0 / gs), (float) (1.0 / gs));
		try {
			if (H - 2 * R > 0) c.fill(X, Y + R, X + W, Y + H - R, col);
			int[][] prof = profile(R);
			for (int i = 0; i < R; i++) {
				int solid = prof[0][i];
				double cover = prof[1][i] / 1000.0; // coverage of the edge pixel
				int aa = cover <= 0.001 ? 0 : (int) Math.round(alpha * cover);
				for (int side = 0; side < 2; side++) {
					boolean top = side == 0;
					int yy = top ? Y + i : Y + H - 1 - i;
					boolean lr = top ? tl : bl, rr = top ? tr : br;
					int l = lr ? solid : 0, rgt = rr ? solid : 0;
					if (X + l < X + W - rgt) c.fill(X + l, yy, X + W - rgt, yy + 1, col);
					if (aa > 0) {
						int ac = (aa << 24) | (col & 0xFFFFFF);
						if (lr) c.fill(X + solid - 1, yy, X + solid, yy + 1, ac);
						if (rr) c.fill(X + W - solid, yy, X + W - solid + 1, yy + 1, ac);
					}
				}
			}
		} finally {
			c.getMatrices().popMatrix();
		}
	}

	private static final java.util.Map<Integer, int[][]> PROFILES = new java.util.HashMap<>();

	/** Corner shape for a radius in real pixels, computed once: [0] = solid pixels cut per row, [1] = edge coverage x1000. */
	private static int[][] profile(int R) {
		int[][] p = PROFILES.get(R);
		if (p != null) return p;
		p = new int[2][R];
		for (int i = 0; i < R; i++) {
			double edge = 0;
			for (int k = 0; k < 4; k++) {
				double dy = R - (i + (k + 0.5) / 4.0);
				edge += R - Math.sqrt(Math.max(0, (double) R * R - dy * dy));
			}
			edge /= 4.0;
			p[0][i] = (int) Math.ceil(edge);
			double frac = edge - Math.floor(edge);
			p[1][i] = frac <= 0.001 ? 0 : (int) Math.round(1000.0 * (1.0 - frac));
		}
		PROFILES.put(R, p);
		return p;
	}
}
