package dev.ousek.gui;

import dev.ousek.module.ModuleManager;
import dev.ousek.module.impl.ClickGuiModule;
import net.minecraft.client.gui.DrawContext;

import java.awt.Color;

public final class Theme {
	public static final String[] NAMES = {"Teal", "Violet", "Crimson", "Azure", "Gold", "Rose", "Custom"};
	private static final int[] PRESETS = {0x2EE6A6, 0x9B6BFF, 0xFF3B52, 0x3AA0FF, 0xFFC14A, 0xFF6BB5};
	private static ClickGuiModule cfg;

	private Theme() {
	}

	public static int accent() {
		if (cfg == null) cfg = ModuleManager.get(ClickGuiModule.class);
		if (cfg == null) return 0xFF2EE6A6;
		String t = cfg.theme.value;
		for (int i = 0; i < PRESETS.length; i++) {
			if (NAMES[i].equals(t)) return 0xFF000000 | PRESETS[i];
		}
		return 0xFF000000 | (cfg.red.i() << 16) | (cfg.green.i() << 8) | cfg.blue.i();
	}

	public static int rainbow(int offset) {
		float hue = ((System.currentTimeMillis() / 18 + offset * 14L) % 360) / 360f;
		return 0xFF000000 | (Color.HSBtoRGB(hue, 0.65f, 1f) & 0xFFFFFF);
	}

	public static int alpha(int color, int a) {
		return (a << 24) | (color & 0xFFFFFF);
	}

	public static boolean in(int mx, int my, int x, int y, int w, int h) {
		return mx >= x && mx < x + w && my >= y && my < y + h;
	}

	public static void rrect(DrawContext c, int x, int y, int w, int h, int r, int col) {
		if (w <= 0 || h <= 0) return;
		r = Math.min(r, Math.min(w, h) / 2);
		if (r <= 0) {
			c.fill(x, y, x + w, y + h, col);
			return;
		}
		c.fill(x, y + r, x + w, y + h - r, col);
		for (int i = 0; i < r; i++) {
			double dy = r - i - 0.5;
			int inset = r - (int) Math.round(Math.sqrt(r * r - dy * dy));
			c.fill(x + inset, y + i, x + w - inset, y + i + 1, col);
			c.fill(x + inset, y + h - i - 1, x + w - inset, y + h - i, col);
		}
	}
}
