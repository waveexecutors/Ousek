package dev.ousek.gui;

import dev.ousek.alt.AltScreen;
import dev.ousek.config.Config;
import dev.ousek.module.Category;
import dev.ousek.module.Module;
import dev.ousek.module.ModuleManager;
import dev.ousek.setting.Setting;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.gui.DrawContext;
import net.minecraft.client.gui.screen.Screen;
import net.minecraft.client.util.InputUtil;
import net.minecraft.text.Text;
import net.minecraft.util.math.MathHelper;
import org.lwjgl.glfw.GLFW;

import java.util.ArrayList;
import java.util.List;
import java.util.Locale;

public class ClickGui extends Screen {
	static final int PW = 124, HH = 20, MH = 18, SH = 16, MW = 106;
	static final List<Panel> PANELS = new ArrayList<>();
	static final List<Panel> DRAW = new ArrayList<>();
	static float menuX = 6, menuY = 6, menuH = 100;
	static final float[] menuHover = new float[24];

	static String icon(Category c) {
		return switch (c) {
			case COMBAT -> "01_category_icons/combat";
			case MOVEMENT -> "01_category_icons/utility";
			case PLAYER -> "01_category_icons/profiles";
			case RENDER -> "01_category_icons/render";
			case WORLD -> "01_category_icons/world";
			case MISC -> "01_category_icons/other";
			case AUTH -> "01_category_icons/friends";
			case HUD -> "01_category_icons/gui";
			case CLIENT -> "01_category_icons/settings";
		};
	}

	static class Panel {
		final Category cat;
		final List<Module> mods;
		float x, y, tx, ty, vis, open = 1f, scroll, scrollT, h;
		boolean visible, collapsed, pinned;

		Panel(Category cat) {
			this.cat = cat;
			this.mods = ModuleManager.in(cat);
		}
	}

	private float dt = 0.016f, openA;
	private long lastNs;
	private boolean pl = true, pr = true;
	private final boolean[] keyPrev = new boolean[GLFW.GLFW_KEY_LAST + 1];
	private Panel dragPanel;
	private boolean dragMenu, moved;
	private float dragDx, dragDy;
	private int startX, startY;
	private Setting<?> sliding;
	private int slideX, slideW;
	private Module binding;
	private Object topHit;
	private Module hoveredModule;

	public ClickGui() {
		super(Text.literal("Ousek"));
	}

	@Override
	protected void init() {
		if (PANELS.isEmpty()) {
			for (Category c : Category.values()) {
				Panel p = new Panel(c);
				PANELS.add(p);
				DRAW.add(p);
			}
			int fit = Math.max(1, (int) ((width - (menuX + MW + 8)) / (PW + 6)));
			for (int i = 0; i < PANELS.size() && i < fit; i++) PANELS.get(i).visible = true;
		}
		openA = 0f;
		lastNs = 0;
		MinecraftClient mc = MinecraftClient.getInstance();
		long h = mc.getWindow().getHandle();
		pl = GLFW.glfwGetMouseButton(h, 0) == GLFW.GLFW_PRESS;
		pr = GLFW.glfwGetMouseButton(h, 1) == GLFW.GLFW_PRESS;
	}

	@Override
	public boolean shouldPause() {
		return false;
	}

	@Override
	public boolean shouldCloseOnEsc() {
		return binding == null;
	}

	@Override
	public void renderBackground(DrawContext ctx, int mouseX, int mouseY, float delta) {
	}

	@Override
	public void removed() {
		Config.save();
	}

	private float ap(float cur, float target, float speed) {
		return cur + (target - cur) * (1f - (float) Math.exp(-speed * dt));
	}

	private String keyName(int key) {
		if (key <= 0) return "NONE";
		try {
			return InputUtil.Type.KEYSYM.createFromCode(key).getLocalizedText().getString().toUpperCase(Locale.ROOT);
		} catch (Throwable t) {
			return "KEY " + key;
		}
	}

	@Override
	public boolean mouseScrolled(double mx, double my, double hAmount, double vAmount) {
		for (int i = DRAW.size() - 1; i >= 0; i--) {
			Panel p = DRAW.get(i);
			if (p.visible && Theme.in((int) mx, (int) my, Math.round(p.x), Math.round(p.y), PW, Math.round(p.h))) {
				p.scrollT -= (float) vAmount * 16f;
				return true;
			}
		}
		return false;
	}

	@Override
	public void render(DrawContext ctx, int mx, int my, float delta) {
		MinecraftClient mc = MinecraftClient.getInstance();
		long ns = System.nanoTime();
		dt = lastNs == 0 ? 0.016f : Math.min(0.1f, (ns - lastNs) / 1e9f);
		lastNs = ns;
		openA = ap(openA, 1f, 10f);

		long h = mc.getWindow().getHandle();
		boolean l = GLFW.glfwGetMouseButton(h, 0) == GLFW.GLFW_PRESS;
		boolean r = GLFW.glfwGetMouseButton(h, 1) == GLFW.GLFW_PRESS;
		boolean le = l && !pl, re = r && !pr;
		pl = l;
		pr = r;

		for (int k = 32; k <= GLFW.GLFW_KEY_LAST; k++) {
			boolean down = GLFW.glfwGetKey(h, k) == GLFW.GLFW_PRESS;
			if (binding != null && down && !keyPrev[k]) {
				binding.key = (k == GLFW.GLFW_KEY_ESCAPE || k == GLFW.GLFW_KEY_DELETE || k == GLFW.GLFW_KEY_BACKSPACE) ? -1 : k;
				binding = null;
			}
			keyPrev[k] = down;
		}

		int acc = Theme.accent();
		ctx.fill(0, 0, width, height, Theme.fade(0xA6000000, openA));

		// horizontal layout of visible panels, next to the category window
		float layoutX = menuX + MW + 8;
		int idx = 0;
		for (Panel p : PANELS) {
			p.vis = ap(p.vis, p.visible ? 1f : 0f, 12f);
			if (!p.visible || p.pinned) continue;
			p.tx = layoutX + idx * (PW + 6);
			p.ty = menuY;
			idx++;
			if (p.vis < 0.05f) {
				p.x = p.tx;
				p.y = p.ty;
			} else {
				p.x = ap(p.x, p.tx, 14f);
				p.y = ap(p.y, p.ty, 14f);
			}
		}

		// who is on top under the cursor (uses last frame's rectangles)
		topHit = null;
		if (Theme.in(mx, my, Math.round(menuX), Math.round(menuY), MW, Math.round(menuH))) topHit = "menu";
		else {
			for (int i = DRAW.size() - 1; i >= 0; i--) {
				Panel p = DRAW.get(i);
				if (p.visible && Theme.in(mx, my, Math.round(p.x), Math.round(p.y), PW, Math.round(p.h))) {
					topHit = p;
					break;
				}
			}
		}

		hoveredModule = null;
		Panel front = null;
		for (Panel p : new ArrayList<>(DRAW)) {
			if (p.vis < 0.02f && !p.visible) continue;
			if (drawPanel(ctx, p, mx, my, le, re, l, acc)) front = p;
		}
		if (front != null) {
			DRAW.remove(front);
			DRAW.add(front);
		}

		if (sliding != null) {
			if (l) {
				double pct = MathHelper.clamp((mx - slideX) / (double) Math.max(1, slideW), 0.0, 1.0);
				if (sliding instanceof Setting.Num n) n.set(n.min + (n.max - n.min) * pct);
				else if (sliding instanceof Setting.Mode md) md.setIndex((int) Math.round(pct * (md.modes.length - 1)));
			} else {
				sliding = null;
			}
		}

		if (dragPanel != null) {
			if (l) {
				if (Math.abs(mx - startX) + Math.abs(my - startY) > 3) moved = true;
				if (moved) {
					dragPanel.pinned = true;
					dragPanel.x = MathHelper.clamp(mx - dragDx, 0, Math.max(0, width - PW));
					dragPanel.y = MathHelper.clamp(my - dragDy, 0, Math.max(0, height - HH));
				}
			} else {
				if (!moved) dragPanel.collapsed = !dragPanel.collapsed;
				dragPanel = null;
			}
		}
		if (dragMenu) {
			if (l) {
				menuX = MathHelper.clamp(mx - dragDx, 0, Math.max(0, width - MW));
				menuY = MathHelper.clamp(my - dragDy, 0, Math.max(0, height - HH));
			} else {
				dragMenu = false;
			}
		}

		drawMenu(ctx, mx, my, le, acc);

		if (hoveredModule != null && binding == null) {
			String d = hoveredModule.desc;
			int tw = textRenderer.getWidth(d) + 10;
			int tx = Math.min(mx + 10, width - tw - 2);
			Theme.rrect(ctx, tx, my + 12, tw, 15, 3, Theme.fade(0xF0101014, openA));
			ctx.fill(tx, my + 12, tx + 2, my + 27, acc);
			ctx.drawText(textRenderer, d, tx + 6, my + 16, 0xFFE8E8EE, false);
		}
	}

	// ---------- category window ----------

	private void drawMenu(DrawContext ctx, int mx, int my, boolean le, int acc) {
		float a = openA;
		if (a < 0.04f) return;
		int x = Math.round(menuX), y = Math.round(menuY);
		Category[] cats = Category.values();
		int rowsTop = y + HH + 4;
		menuH = HH + 4 + cats.length * 16 + 8 + 4 * 16 + 6;
		boolean can = "menu".equals(topHit);

		Theme.rrect(ctx, x, y, MW, Math.round(menuH), 5, Theme.fade(0xFF0F0F12, a));
		ctx.fill(x + 5, y + HH - 1, x + MW - 5, y + HH, Theme.fade(acc, a));
		ctx.drawText(textRenderer, "OUSEK", x + 8, y + 6, Theme.fade(acc, a), false);
		ctx.drawText(textRenderer, "v1", x + 8 + textRenderer.getWidth("OUSEK "), y + 6, Theme.fade(0xFF8A8A94, a), false);
		if (can && le && Theme.in(mx, my, x, y, MW, HH)) {
			dragMenu = true;
			dragDx = mx - menuX;
			dragDy = my - menuY;
		}

		for (int i = 0; i < cats.length; i++) {
			Panel p = PANELS.get(i);
			int ry = rowsTop + i * 16;
			boolean hv = can && Theme.in(mx, my, x + 3, ry, MW - 6, 15);
			menuHover[i] = ap(menuHover[i], hv ? 1f : 0f, 14f);
			if (p.vis > 0.01f) Theme.rrect(ctx, x + 3, ry, MW - 6, 15, 3, Theme.fade(acc, a * 0.88f * p.vis));
			if (menuHover[i] > 0.01f) Theme.rrect(ctx, x + 3, ry, MW - 6, 15, 3, Theme.fade(0xFFFFFFFF, a * 0.08f * menuHover[i]));
			int tc = Theme.lerp(0xFFB4B4BC, 0xFFFFFFFF, Math.max(p.vis, menuHover[i] * 0.6f));
			Tex.fit(ctx, icon(cats[i]), x + 6, ry + 2, 11, 11, Theme.fade(0xFFFFFFFF, a));
			ctx.drawText(textRenderer, cats[i].label, x + 21, ry + 4, Theme.fade(tc, a), false);
			String n = String.valueOf(p.mods.size());
			ctx.drawText(textRenderer, n, x + MW - 9 - textRenderer.getWidth(n), ry + 4, Theme.fade(0xFF8A8A94, a), false);
			if (hv && le) {
				p.visible = !p.visible;
				if (p.visible) p.pinned = false;
			}
		}

		int by = rowsTop + cats.length * 16 + 8;
		menuButton(ctx, x + 3, by, "HUD Editor", mx, my, can, a, acc, 20);
		menuButton(ctx, x + 3, by + 16, "Alt Manager", mx, my, can, a, acc, 21);
		menuButton(ctx, x + 3, by + 32, "Emotes", mx, my, can, a, acc, 22);
		menuButton(ctx, x + 3, by + 48, "Music", mx, my, can, a, acc, 23);
		MinecraftClient mc = MinecraftClient.getInstance();
		if (can && le && Theme.in(mx, my, x + 3, by + 32, MW - 6, 15)) mc.setScreen(new EmoteScreen(this));
		else if (can && le && Theme.in(mx, my, x + 3, by + 48, MW - 6, 15)) mc.setScreen(new MusicScreen(this));
		else
		if (can && le && Theme.in(mx, my, x + 3, by, MW - 6, 15)) mc.setScreen(new HudEditor());
		else if (can && le && Theme.in(mx, my, x + 3, by + 16, MW - 6, 15)) mc.setScreen(new AltScreen(this));
	}

	private void menuButton(DrawContext ctx, int x, int y, String label, int mx, int my, boolean can, float a, int acc, int hi) {
		boolean hv = can && Theme.in(mx, my, x, y, MW - 6, 15);
		menuHover[hi] = ap(menuHover[hi], hv ? 1f : 0f, 14f);
		Theme.rrect(ctx, x, y, MW - 6, 15, 3, Theme.fade(Theme.lerp(0xFF17171C, 0xFF24242C, menuHover[hi]), a));
		ctx.fill(x + 5, y + 14, x + MW - 11, y + 15, Theme.fade(acc, a * (0.4f + 0.6f * menuHover[hi])));
		ctx.drawText(textRenderer, label, x + (MW - 6 - textRenderer.getWidth(label)) / 2, y + 4, Theme.fade(0xFFFFFFFF, a), false);
	}

	// ---------- panels ----------

	/** Returns true if this panel was grabbed this frame (so it gets brought to the front). */
	private boolean drawPanel(DrawContext ctx, Panel p, int mx, int my, boolean le, boolean re, boolean l, int acc) {
		float vis = Theme.ease(p.vis);
		float a = vis * openA;
		if (a < 0.04f) {
			p.h = 0;
			return false;
		}
		boolean grabbed = false;
		boolean can = p == topHit && a > 0.8f;

		int px = Math.round(p.x);
		int py = Math.round(p.y) + Math.round((1f - vis) * -10f);
		int top = py + HH;

		// header
		Theme.rrect(ctx, px, py, PW, HH, 4, Theme.fade(0xFF0F0F12, a));
		ctx.fill(px + 4, py + HH - 1, px + PW - 4, py + HH, Theme.fade(acc, a));
		Tex.fit(ctx, icon(p.cat), px + 6, py + 4, 12, 12, Theme.fade(0xFFFFFFFF, a));
		ctx.drawText(textRenderer, p.cat.label, px + 22, py + 6, Theme.fade(0xFFFFFFFF, a), false);
		int on = 0;
		for (Module m : p.mods) if (m.enabled) on++;
		String cnt = on + "/" + p.mods.size();
		ctx.drawText(textRenderer, cnt, px + PW - 8 - textRenderer.getWidth(cnt), py + 6, Theme.fade(0xFF8A8A94, a), false);
		if (can && le && dragPanel == null && Theme.in(mx, my, px, py, PW, HH)) {
			dragPanel = p;
			dragDx = mx - p.x;
			dragDy = my - p.y;
			startX = mx;
			startY = my;
			moved = false;
			grabbed = true;
		}

		// animated sizes
		float total = 0;
		for (Module m : p.mods) {
			m.aExpand = ap(m.aExpand, m.expanded ? 1f : 0f, 14f);
			total += MH + m.aExpand * (m.settings.size() + 1) * SH;
		}
		p.open = ap(p.open, p.collapsed ? 0f : 1f, 14f);
		float maxH = Math.max(MH, height - top - 36);
		float avail = Math.min(total, maxH);
		float shown = avail * Theme.ease(p.open);
		p.h = HH + shown;
		p.scrollT = MathHelper.clamp(p.scrollT, 0f, Math.max(0f, total - avail));
		p.scroll = ap(p.scroll, p.scrollT, 16f);
		if (shown < 1f) return grabbed;

		int bodyH = Math.round(shown);
		ctx.fill(px, top, px + PW, top + bodyH, Theme.fade(0xFF121216, a));
		ctx.enableScissor(px, top, px + PW, top + bodyH);

		float cy = top - p.scroll;
		for (Module m : p.mods) {
			float extra = m.aExpand * (m.settings.size() + 1) * SH;
			float rowH = MH + extra;
			if (cy + rowH > top && cy < top + bodyH) {
				int iy = Math.round(cy);
				boolean inArea = my >= top && my < top + bodyH;
				boolean rowHover = can && inArea && Theme.in(mx, my, px, iy, PW, MH);
				boolean arrowHover = rowHover && mx >= px + PW - 18;

				m.aHover = ap(m.aHover, rowHover ? 1f : 0f, 14f);
				m.aEnable = ap(m.aEnable, m.enabled ? 1f : 0f, 12f);

				ctx.fill(px, iy, px + PW, iy + MH, Theme.fade(0xFF161619, a));
				if (m.aEnable > 0.01f) ctx.fill(px, iy, px + PW, iy + MH, Theme.fade(acc, a * 0.92f * m.aEnable));
				if (m.aHover > 0.01f) ctx.fill(px, iy, px + PW, iy + MH, Theme.fade(0xFFFFFFFF, a * 0.07f * m.aHover));

				int tc = Theme.lerp(0xFFB4B4BC, 0xFFFFFFFF, Math.max(m.aEnable, m.aHover * 0.5f));
				int nx = px + 8 + Math.round(m.aHover * 2f);
				ctx.drawText(textRenderer, m.name, nx, iy + 5, Theme.fade(tc, a), false);
				String right = m.expanded ? "^" : "v";
				int rcol = Theme.lerp(0xFF6C6C76, 0xFFFFFFFF, Math.max(m.aEnable, m.aExpand));
				ctx.drawText(textRenderer, right, px + PW - 11, iy + 5, Theme.fade(rcol, a), false);
				if (m.key > 0) {
					String kn = "[" + keyName(m.key) + "]";
					ctx.drawText(textRenderer, kn, px + PW - 16 - textRenderer.getWidth(kn), iy + 5,
							Theme.fade(Theme.lerp(0xFF6C6C76, 0xFFE0E0E8, m.aEnable), a), false);
				}

				if (rowHover) {
					hoveredModule = m;
					if (le) {
						if (arrowHover) m.expanded = !m.expanded;
						else m.toggle();
					}
					if (re) m.expanded = !m.expanded;
				}

				if (m.aExpand > 0.02f) {
					int sy0 = iy + MH;
					int sh = Math.round(extra);
					ctx.enableScissor(px, sy0, px + PW, sy0 + sh);
					ctx.fill(px, sy0, px + PW, sy0 + sh, Theme.fade(0xFF0C0C0F, a));
					float ea = a * m.aExpand;
					int lo = Math.max(top, sy0), hi = Math.min(top + bodyH, sy0 + sh);
					int sy = sy0;
					for (Setting<?> s : m.settings) {
						boolean sh2 = can && my >= lo && my < hi && Theme.in(mx, my, px, sy, PW, SH);
						drawSetting(ctx, s, px, sy, sh2, le, re, ea, acc);
						sy += SH;
					}
					boolean bh = can && my >= lo && my < hi && Theme.in(mx, my, px, sy, PW, SH);
					ctx.drawText(textRenderer, "Bind", px + 10, sy + 4, Theme.fade(0xFFB4B4BC, ea), false);
					String kn = binding == m ? "press a key..." : keyName(m.key);
					ctx.drawText(textRenderer, kn, px + PW - 8 - textRenderer.getWidth(kn), sy + 4,
							Theme.fade(binding == m ? 0xFFFFFFFF : acc, ea), false);
					if (bh && le) binding = m;
					ctx.disableScissor();
				}
			}
			cy += rowH;
		}
		ctx.disableScissor();
		return grabbed;
	}

	private void drawSetting(DrawContext ctx, Setting<?> s, int px, int sy, boolean hov, boolean le, boolean re, float a, int acc) {
		int dim = Theme.fade(0xFFB4B4BC, a);
		int white = Theme.fade(0xFFFFFFFF, a);
		s.hover = ap(s.hover, hov ? 1f : 0f, 14f);
		if (s.hover > 0.01f) ctx.fill(px, sy, px + PW, sy + SH, Theme.fade(0xFFFFFFFF, a * 0.04f * s.hover));

		if (s instanceof Setting.Bool b) {
			b.anim = ap(b.anim, b.on() ? 1f : 0f, 16f);
			ctx.drawText(textRenderer, b.name, px + 10, sy + 4, dim, false);
			int bx = px + PW - 26, by = sy + 4;
			Theme.rrect(ctx, bx, by, 18, 8, 4, Theme.fade(Theme.lerp(0xFF2A2A31, acc, b.anim), a));
			Theme.rrect(ctx, bx + 1 + Math.round(b.anim * 10f), by + 1, 6, 6, 3, white);
			if (hov && le) b.value = !b.value;
		} else if (s instanceof Setting.Num n) {
			float pct = (float) ((n.get() - n.min) / (n.max - n.min));
			n.anim = ap(n.anim, pct, 18f);
			String val = String.format(Locale.ROOT, n.step >= 1 ? "%.0f" : "%.2f", n.get());
			ctx.drawText(textRenderer, n.name, px + 10, sy + 2, dim, false);
			ctx.drawText(textRenderer, val, px + PW - 8 - textRenderer.getWidth(val), sy + 2, white, false);
			int tx = px + 8, tw = PW - 16, ty = sy + SH - 4;
			ctx.fill(tx, ty, tx + tw, ty + 2, Theme.fade(0xFF2A2A31, a));
			int fw = Math.round(tw * n.anim);
			ctx.fill(tx, ty, tx + fw, ty + 2, Theme.fade(acc, a));
			ctx.fill(tx + fw - 1, ty - 1, tx + fw + 2, ty + 3, white);
			if (hov && le) {
				sliding = n;
				slideX = tx;
				slideW = tw;
			}
		} else if (s instanceof Setting.Mode md) {
			if (md.modes.length > 8) {
				float pct = md.modes.length > 1 ? md.index() / (float) (md.modes.length - 1) : 0f;
				md.anim = ap(md.anim, pct, 18f);
				ctx.drawText(textRenderer, md.name, px + 10, sy + 2, dim, false);
				ctx.drawText(textRenderer, md.value, px + PW - 8 - textRenderer.getWidth(md.value), sy + 2, Theme.fade(acc, a), false);
				int tx = px + 8, tw = PW - 16, ty = sy + SH - 4;
				ctx.fill(tx, ty, tx + tw, ty + 2, Theme.fade(0xFF2A2A31, a));
				int fw = Math.round(tw * md.anim);
				ctx.fill(tx, ty, tx + fw, ty + 2, Theme.fade(acc, a));
				ctx.fill(tx + fw - 1, ty - 1, tx + fw + 2, ty + 3, white);
				if (hov && le) {
					sliding = md;
					slideX = tx;
					slideW = tw;
				}
			} else {
				ctx.drawText(textRenderer, md.name, px + 10, sy + 4, dim, false);
				ctx.drawText(textRenderer, md.value, px + PW - 8 - textRenderer.getWidth(md.value), sy + 4, Theme.fade(acc, a), false);
				if (hov && le) md.cycle();
				if (hov && re) md.prev();
			}
		}
	}
}
