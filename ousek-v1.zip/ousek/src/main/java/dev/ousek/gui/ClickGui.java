package dev.ousek.gui;

import dev.ousek.alt.AltScreen;
import dev.ousek.config.Config;
import dev.ousek.module.Category;
import dev.ousek.module.Module;
import dev.ousek.module.ModuleManager;
import dev.ousek.setting.Setting;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.gui.DrawContext;
import net.minecraft.client.gui.screen.Screen;
import net.minecraft.text.Text;
import net.minecraft.util.math.MathHelper;
import net.minecraft.client.util.InputUtil;
import org.lwjgl.glfw.GLFW;

import java.util.ArrayList;
import java.util.List;
import java.util.Locale;

public class ClickGui extends Screen {
	static final int PW = 120, HH = 18, MH = 16, SH = 14;
	static final List<Panel> PANELS = new ArrayList<>();

	static class Panel {
		final Category cat;
		final List<Module> mods;
		int x, y, scroll;
		boolean open;

		Panel(Category cat, int x, int y) {
			this.cat = cat;
			this.x = x;
			this.y = y;
			this.mods = ModuleManager.in(cat);
		}
	}

	private boolean pl = true, pr = true;
	private final boolean[] keyPrev = new boolean[GLFW.GLFW_KEY_LAST + 1];
	private Panel dragging;
	private int dragDx, dragDy, startX, startY;
	private boolean moved;
	private Setting.Num sliding;
	private int slideX;
	private Module binding;

	public ClickGui() {
		super(Text.literal("Ousek"));
	}

	@Override
	protected void init() {
		if (PANELS.isEmpty()) {
			int cols = Math.max(1, (width - 8) / (PW + 6));
			int i = 0;
			for (Category c : Category.values()) {
				int col = i % cols, row = i / cols;
				PANELS.add(new Panel(c, 6 + col * (PW + 6), 24 + row * (HH + 6)));
				i++;
			}
		}
		MinecraftClient mc = MinecraftClient.getInstance();
		long h = mc.getWindow().getHandle();
		pl = GLFW.glfwGetMouseButton(h, 0) == GLFW.GLFW_PRESS;
		pr = GLFW.glfwGetMouseButton(h, 1) == GLFW.GLFW_PRESS;
	}

	@Override
	public boolean shouldPause() {
		return false;
	}

	@Override
	public boolean shouldCloseOnEsc() {
		return binding == null;
	}

	@Override
	public void renderBackground(DrawContext ctx, int mouseX, int mouseY, float delta) {
	}

	@Override
	public void removed() {
		Config.save();
	}

	private int contentH(Panel p) {
		int h = 0;
		for (Module m : p.mods) {
			h += MH;
			if (m.expanded) h += (m.settings.size() + 1) * SH;
		}
		return h;
	}

	private String keyName(int key) {
		if (key <= 0) return "NONE";
		try {
			return InputUtil.Type.KEYSYM.createFromCode(key).getLocalizedText().getString().toUpperCase(Locale.ROOT);
		} catch (Throwable t) {
			return "KEY " + key;
		}
	}

	@Override
	public boolean mouseScrolled(double mx, double my, double hAmount, double vAmount) {
		for (Panel p : PANELS) {
			if (!p.open) continue;
			int top = p.y + HH;
			int avail = Math.min(contentH(p), Math.max(MH, height - top - 30));
			if (Theme.in((int) mx, (int) my, p.x, top, PW, avail)) {
				int max = Math.max(0, contentH(p) - avail);
				p.scroll = MathHelper.clamp(p.scroll - (int) (vAmount * 12), 0, max);
				return true;
			}
		}
		return false;
	}

	@Override
	public void render(DrawContext ctx, int mx, int my, float delta) {
		MinecraftClient mc = MinecraftClient.getInstance();
		long h = mc.getWindow().getHandle();
		boolean l = GLFW.glfwGetMouseButton(h, 0) == GLFW.GLFW_PRESS;
		boolean r = GLFW.glfwGetMouseButton(h, 1) == GLFW.GLFW_PRESS;
		boolean le = l && !pl, re = r && !pr;
		pl = l;
		pr = r;

		for (int k = 32; k <= GLFW.GLFW_KEY_LAST; k++) {
			boolean down = GLFW.glfwGetKey(h, k) == GLFW.GLFW_PRESS;
			if (binding != null && down && !keyPrev[k]) {
				binding.key = k == GLFW.GLFW_KEY_ESCAPE || k == GLFW.GLFW_KEY_DELETE || k == GLFW.GLFW_KEY_BACKSPACE ? -1 : k;
				binding = null;
			}
			keyPrev[k] = down;
		}

		int acc = Theme.accent();
		ctx.fill(0, 0, width, height, 0x99000000);
		ctx.drawText(textRenderer, "OUSEK", 8, 8, acc, true);
		ctx.drawText(textRenderer, "v1", 8 + textRenderer.getWidth("OUSEK ") , 8, 0xFF9A9AA6, true);
		String hint = "Tap header: open/close  |  drag header: move  |  arrow: settings  |  scroll: panel";
		ctx.drawText(textRenderer, hint, 60, 8, 0xFF70707C, false);

		Module hovered = null;

		for (Panel p : PANELS) {
			int x = p.x, y = p.y;
			boolean hh = Theme.in(mx, my, x, y, PW, HH);
			if (hh && le && dragging == null) {
				dragging = p;
				dragDx = mx - p.x;
				dragDy = my - p.y;
				startX = mx;
				startY = my;
				moved = false;
			}

			Theme.rrect(ctx, x, y, PW, HH, 4, 0xFF17171D);
			ctx.fill(x + 5, y + HH - 1, x + PW - 5, y + HH, acc);
			ctx.drawText(textRenderer, p.cat.label, x + 7, y + 5, 0xFFFFFFFF, false);
			ctx.drawText(textRenderer, p.open ? "-" : "+", x + PW - 11, y + 5, acc, false);
			if (!p.open) continue;

			int top = y + HH;
			int total = contentH(p);
			int avail = Math.min(total, Math.max(MH, height - top - 30));
			p.scroll = MathHelper.clamp(p.scroll, 0, Math.max(0, total - avail));
			ctx.fill(x, top, x + PW, top + avail, 0xEE0E0E13);
			ctx.enableScissor(x, top, x + PW, top + avail);

			int cy = top - p.scroll;
			for (Module m : p.mods) {
				boolean vis = cy + MH > top && cy < top + avail;
				boolean inArea = vis && my >= top && my < top + avail;
				boolean rowHover = inArea && Theme.in(mx, my, x, cy, PW, MH);
				boolean arrowHover = inArea && Theme.in(mx, my, x + PW - 16, cy, 16, MH);

				if (m.enabled) ctx.fill(x, cy, x + PW, cy + MH, Theme.alpha(acc, 0x30));
				if (rowHover) ctx.fill(x, cy, x + PW, cy + MH, 0x18FFFFFF);
				if (m.enabled) ctx.fill(x, cy, x + 2, cy + MH, acc);
				ctx.drawText(textRenderer, m.name, x + 7, cy + 4, m.enabled ? acc : 0xFFB8B8C4, false);
				ctx.drawText(textRenderer, m.expanded ? "^" : "v", x + PW - 11, cy + 4, 0xFF70707C, false);

				if (rowHover) hovered = m;
				if (rowHover && le) {
					if (arrowHover) m.expanded = !m.expanded;
					else m.toggle();
				}
				if (rowHover && re) m.expanded = !m.expanded;
				cy += MH;

				if (!m.expanded) continue;

				for (Setting<?> s : m.settings) {
					boolean sv = cy + SH > top && cy < top + avail;
					boolean sh = sv && my >= top && my < top + avail && Theme.in(mx, my, x, cy, PW, SH);
					ctx.fill(x, cy, x + PW, cy + SH, 0x30000000);
					if (s instanceof Setting.Bool b) {
						ctx.drawText(textRenderer, b.name, x + 10, cy + 3, 0xFFB8B8C4, false);
						int bx = x + PW - 22;
						Theme.rrect(ctx, bx, cy + 3, 14, 8, 4, b.on() ? acc : 0xFF2A2A33);
						int kx = b.on() ? bx + 8 : bx + 1;
						Theme.rrect(ctx, kx, cy + 4, 5, 6, 2, 0xFFFFFFFF);
						if (sh && le) b.value = !b.value;
					} else if (s instanceof Setting.Num n) {
						double pct = (n.get() - n.min) / (n.max - n.min);
						ctx.fill(x + 6, cy + SH - 3, x + PW - 6, cy + SH - 1, 0xFF2A2A33);
						ctx.fill(x + 6, cy + SH - 3, x + 6 + (int) ((PW - 12) * pct), cy + SH - 1, acc);
						String val = String.format(Locale.ROOT, n.step >= 1 ? "%.0f" : "%.2f", n.get());
						ctx.drawText(textRenderer, n.name, x + 10, cy + 1, 0xFFB8B8C4, false);
						ctx.drawText(textRenderer, val, x + PW - 8 - textRenderer.getWidth(val), cy + 1, 0xFFFFFFFF, false);
						if (sh && le) {
							sliding = n;
							slideX = x + 6;
						}
					} else if (s instanceof Setting.Mode md) {
						ctx.drawText(textRenderer, md.name, x + 10, cy + 3, 0xFFB8B8C4, false);
						ctx.drawText(textRenderer, md.value, x + PW - 8 - textRenderer.getWidth(md.value), cy + 3, acc, false);
						if (sh && le) md.cycle();
					}
					cy += SH;
				}

				boolean bv = cy + SH > top && cy < top + avail;
				boolean bh = bv && my >= top && my < top + avail && Theme.in(mx, my, x, cy, PW, SH);
				ctx.fill(x, cy, x + PW, cy + SH, 0x30000000);
				ctx.drawText(textRenderer, "Bind", x + 10, cy + 3, 0xFFB8B8C4, false);
				String kn = binding == m ? "press a key..." : keyName(m.key);
				ctx.drawText(textRenderer, kn, x + PW - 8 - textRenderer.getWidth(kn), cy + 3, binding == m ? 0xFFFFFFFF : acc, false);
				if (bh && le) binding = m;
				cy += SH;
			}
			ctx.disableScissor();
		}

		if (sliding != null) {
			if (l) {
				double pct = MathHelper.clamp((mx - slideX) / (double) (PW - 12), 0, 1);
				sliding.set(sliding.min + (sliding.max - sliding.min) * pct);
			} else {
				sliding = null;
			}
		}

		if (dragging != null) {
			if (l) {
				if (Math.abs(mx - startX) + Math.abs(my - startY) > 3) moved = true;
				if (moved) {
					dragging.x = MathHelper.clamp(mx - dragDx, 0, Math.max(0, width - PW));
					dragging.y = MathHelper.clamp(my - dragDy, 0, Math.max(0, height - HH));
				}
			} else {
				if (!moved) dragging.open = !dragging.open;
				dragging = null;
			}
		}

		int bw = 90, by = height - 22;
		int bx1 = width / 2 - bw - 4, bx2 = width / 2 + 4;
		button(ctx, bx1, by, bw, "HUD Editor", mx, my);
		button(ctx, bx2, by, bw, "Alt Manager", mx, my);
		if (le && Theme.in(mx, my, bx1, by, bw, 16)) {
			mc.setScreen(new HudEditor());
		} else if (le && Theme.in(mx, my, bx2, by, bw, 16)) {
			mc.setScreen(new AltScreen(this));
		}

		if (hovered != null && binding == null) {
			String d = hovered.desc;
			int tw = textRenderer.getWidth(d) + 8;
			int tx = Math.min(mx + 10, width - tw - 2);
			Theme.rrect(ctx, tx, my + 10, tw, 14, 3, 0xF0101014);
			ctx.drawText(textRenderer, d, tx + 4, my + 13, 0xFFE8E8EE, false);
		}
	}

	private void button(DrawContext ctx, int x, int y, int w, String label, int mx, int my) {
		boolean hv = Theme.in(mx, my, x, y, w, 16);
		Theme.rrect(ctx, x, y, w, 16, 4, hv ? 0xFF24242C : 0xFF17171D);
		ctx.fill(x + 5, y + 15, x + w - 5, y + 16, Theme.accent());
		ctx.drawText(textRenderer, label, x + (w - textRenderer.getWidth(label)) / 2, y + 4, 0xFFFFFFFF, false);
	}
}
