package dev.ousek.gui;

import dev.ousek.alt.AltScreen;
import net.minecraft.client.gui.DrawContext;
import net.minecraft.client.gui.screen.Screen;
import net.minecraft.client.gui.screen.multiplayer.MultiplayerScreen;
import net.minecraft.client.gui.screen.option.OptionsScreen;
import net.minecraft.client.gui.screen.world.SelectWorldScreen;
import net.minecraft.text.Text;
import org.lwjgl.glfw.GLFW;

/** Ousek main menu (replaces the vanilla title screen). */
public class OusekMenu extends Screen {
	private static final String[] LABELS = {"Singleplayer", "Multiplayer", "Ousek Client", "Alt Manager", "Options", "Quit Game"};
	private final float[] hover = new float[LABELS.length];
	private boolean pl = true;
	private final long born = System.currentTimeMillis();

	public OusekMenu() {
		super(Text.literal("Ousek"));
	}

	@Override
	protected void init() {
		pl = GLFW.glfwGetMouseButton(Ui.handle(), 0) == GLFW.GLFW_PRESS;
	}

	@Override
	public boolean shouldCloseOnEsc() {
		return false;
	}

	@Override
	public boolean shouldPause() {
		return false;
	}

	@Override
	public void renderBackground(DrawContext ctx, int mouseX, int mouseY, float delta) {
	}

	@Override
	public void render(DrawContext ctx, int mx, int my, float delta) {
		boolean l = GLFW.glfwGetMouseButton(Ui.handle(), 0) == GLFW.GLFW_PRESS;
		boolean click = l && !pl;
		pl = l;
		int acc = Theme.accent();
		float t = Math.min(1f, (System.currentTimeMillis() - born) / 500f);

		// background: dark gradient tinted by the theme, with a slow moving glow
		int bands = 48;
		for (int i = 0; i < bands; i++) {
			float k = i / (float) (bands - 1);
			int c = Theme.lerp(0xFF07070B, Theme.lerp(0xFF0D0D14, acc, 0.22f), k * k);
			ctx.fill(0, i * height / bands, width, (i + 1) * height / bands + 1, c);
		}
		double ph = (System.currentTimeMillis() % 12000L) / 12000.0 * Math.PI * 2;
		int gx = (int) (width * (0.5 + 0.18 * Math.sin(ph))), gy = (int) (height * 0.62);
		for (int r = 6; r >= 1; r--) {
			int rad = r * Math.max(width, height) / 14;
			Theme.rrect(ctx, gx - rad, gy - rad / 2, rad * 2, rad, rad / 2, Theme.fade(acc, 0.035f));
		}

		// logo
		float ls = Math.max(2f, Math.min(5f, width / 150f));
		int lw = Logo.width(ls);
		Logo.draw(ctx, (width - lw) / 2, (int) (height * 0.16f - (1f - t) * 8), ls, t);
		String sub = "Minecraft 1.21.11  -  Fabric";
		ctx.drawText(textRenderer, sub, (width - textRenderer.getWidth(sub)) / 2, (int) (height * 0.16f + ls * 11), Theme.fade(0xFF8A8A94, t), false);

		// buttons
		int bw = Math.min(180, width - 40), bh = 22, gap = 6;
		int total = LABELS.length * (bh + gap) - gap;
		int bx = (width - bw) / 2, by = Math.max((int) (height * 0.16f + ls * 11 + 18), (height - total) / 2 + 14);
		for (int i = 0; i < LABELS.length; i++) {
			int y = by + i * (bh + gap);
			boolean hv = Theme.in(mx, my, bx, y, bw, bh);
			hover[i] += ((hv ? 1f : 0f) - hover[i]) * 0.25f;
			float h = hover[i];
			Theme.rrect(ctx, bx, y, bw, bh, 4, Theme.fade(Theme.lerp(0xFF14141A, 0xFF1E1E27, h), t));
			if (h > 0.02f) Theme.rrect(ctx, bx, y, 3 + Math.round(h * (bw - 3) * 0.0f), bh, 4, Theme.fade(acc, h * t));
			int tc = Theme.lerp(0xFFB4B4BC, 0xFFFFFFFF, h);
			ctx.drawText(textRenderer, LABELS[i], bx + (bw - textRenderer.getWidth(LABELS[i])) / 2, y + (bh - 8) / 2, Theme.fade(tc, t), false);
			if (hv && click) {
				press(i);
				return;
			}
		}

		String who = client.getSession().getUsername();
		ctx.drawText(textRenderer, who, 8, height - 12, Theme.fade(0xFF8A8A94, t), false);
		String r = "Ousek Client";
		ctx.drawText(textRenderer, r, width - 8 - textRenderer.getWidth(r), height - 12, Theme.fade(acc, t), false);
	}

	private void press(int i) {
		switch (i) {
			case 0 -> client.setScreen(new SelectWorldScreen(this));
			case 1 -> client.setScreen(new MultiplayerScreen(this));
			case 2 -> client.setScreen(new ClickGui());
			case 3 -> client.setScreen(new AltScreen(this));
			case 4 -> client.setScreen(new OptionsScreen(this, client.options));
			default -> client.scheduleStop();
		}
	}
}
