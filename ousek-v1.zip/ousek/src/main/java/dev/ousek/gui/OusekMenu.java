package dev.ousek.gui;

import dev.ousek.alt.AltScreen;
import net.minecraft.client.gui.DrawContext;
import net.minecraft.client.gui.screen.Screen;
import net.minecraft.client.gui.screen.multiplayer.MultiplayerScreen;
import net.minecraft.client.gui.screen.option.OptionsScreen;
import net.minecraft.client.gui.screen.world.SelectWorldScreen;
import net.minecraft.text.Text;
import org.lwjgl.glfw.GLFW;

/** Ousek main menu (replaces the vanilla title screen). */
public class OusekMenu extends Screen {
	private static final String[] LABELS = {"Singleplayer", "Multiplayer", "Acid Client", "Alt Manager", "Options", "Quit Game"};
	private final float[] hover = new float[LABELS.length];
	private boolean pl = true;
	private final long born = System.currentTimeMillis();

	public OusekMenu() {
		super(Text.literal("Acid"));
	}

	@Override
	protected void init() {
		pl = GLFW.glfwGetMouseButton(Ui.handle(), 0) == GLFW.GLFW_PRESS;
	}

	@Override
	public boolean shouldCloseOnEsc() {
		return false;
	}

	@Override
	public boolean shouldPause() {
		return false;
	}

	@Override
	public void renderBackground(DrawContext ctx, int mouseX, int mouseY, float delta) {
	}

	@Override
	public void render(DrawContext ctx, int mx, int my, float delta) {
		boolean l = GLFW.glfwGetMouseButton(Ui.handle(), 0) == GLFW.GLFW_PRESS;
		boolean click = l && !pl;
		pl = l;
		int acc = Theme.accent();
		float t = Math.min(1f, (System.currentTimeMillis() - born) / 500f);

		// plain dark background, only a faint tint towards the bottom
		for (int i = 0; i < 10; i++) {
			ctx.fill(0, i * height / 10, width, (i + 1) * height / 10 + 1, Theme.lerp(0xFF0A0A0E, Theme.lerp(0xFF0A0A0E, acc, 0.16f), i / 9f));
		}

		float ls = Math.max(2f, Math.min(4f, width / 190f));
		int lw = Logo.width(ls);
		int lh = Logo.height(ls);
		int bw = 150, bh = 20, gap = 4;
		int total = LABELS.length * (bh + gap) - gap;
		int top = (height - (lh + 22 + total)) / 2;
		Logo.draw(ctx, (width - lw) / 2, top, ls, t);

		int bx = (width - bw) / 2, by = top + lh + 22;
		for (int i = 0; i < LABELS.length; i++) {
			int y = by + i * (bh + gap);
			boolean hv = Theme.in(mx, my, bx, y, bw, bh);
			hover[i] += ((hv ? 1f : 0f) - hover[i]) * 0.3f;
			float h = hover[i];
			Theme.rrect(ctx, bx, y, bw, bh, 1, Theme.fade(Theme.lerp(0xFF14141A, 0xFF22222C, h), t));
			int tc = Theme.lerp(0xFFB4B4BC, 0xFFFFFFFF, h);
			ctx.drawText(textRenderer, LABELS[i], bx + (bw - textRenderer.getWidth(LABELS[i])) / 2, y + (bh - 8) / 2, Theme.fade(tc, t), false);
			if (hv && click) {
				press(i);
				return;
			}
		}

		String who = client.getSession().getUsername();
		ctx.drawText(textRenderer, who, 8, height - 12, Theme.fade(0xFF8A8A94, t), false);
	}

	private void press(int i) {
		switch (i) {
			case 0 -> client.setScreen(new SelectWorldScreen(this));
			case 1 -> client.setScreen(new MultiplayerScreen(this));
			case 2 -> client.setScreen(new ClickGui());
			case 3 -> client.setScreen(new AltScreen(this));
			case 4 -> client.setScreen(new OptionsScreen(this, client.options));
			default -> client.scheduleStop();
		}
	}
}
