package dev.ousek.gui;

import dev.ousek.config.Config;
import dev.ousek.module.impl.WindowModules;
import dev.ousek.music.MusicPlayer;
import net.minecraft.client.gui.DrawContext;
import net.minecraft.client.gui.screen.Screen;
import net.minecraft.client.gui.widget.TextFieldWidget;
import net.minecraft.text.Text;
import net.minecraft.util.math.MathHelper;
import org.lwjgl.glfw.GLFW;

import java.util.List;

/** Music window: search + play from free key-less APIs. */
public class MusicScreen extends Screen {
	private static final int W = 440, H = 304, ROW = 17;
	private static final String[][] BROWSE = {{"Trending", "@trending"}, {"Top Charts", "@charts"}, {"TikTok Viral", "@tiktok"},
			{"Hits", "@hits"}, {"Phonk Viral", "@phonk"}};
	private static final String[] PRESETS = {"Alan Walker", "NCS", "Funk BR", "Phonk", "Lofi", "Marshmello", "Slowed"};
	private static String lastQuery = "";
	private final Screen parent;
	private TextFieldWidget field;
	private boolean pl = true, enterPrev, dragVol;
	private float scroll, scrollT;

	public MusicScreen(Screen parent) {
		super(Text.literal("Music"));
		this.parent = parent;
	}

	@Override
	protected void init() {
		pl = GLFW.glfwGetMouseButton(Ui.handle(), 0) == GLFW.GLFW_PRESS;
		String old = field == null ? lastQuery : field.getText();
		int x = (width - W) / 2, y = (height - H) / 2;
		field = new TextFieldWidget(textRenderer, x + 8, y + 26, W - 16 - 66, 16, Text.literal("Search"));
		field.setMaxLength(80);
		field.setPlaceholder(Text.literal("Search songs, artists, NCS, funk..."));
		field.setText(old);
		addDrawableChild(field);
		setInitialFocus(field);
	}

	@Override
	public boolean shouldPause() {
		return false;
	}

	@Override
	public void renderBackground(DrawContext ctx, int mouseX, int mouseY, float delta) {
	}

	@Override
	public void close() {
		lastQuery = field == null ? lastQuery : field.getText();
		Config.save();
		if (client != null) client.setScreen(parent);
	}

	@Override
	public boolean mouseScrolled(double mx, double my, double hAmount, double vAmount) {
		scrollT -= (float) vAmount * ROW * 2;
		return true;
	}

	private void doSearch() {
		lastQuery = field.getText();
		WindowModules.Music m = WindowModules.music();
		MusicPlayer.search(field.getText(), m == null ? "Auto" : m.source.value);
		scroll = scrollT = 0;
	}

	private static String time(long ms) {
		long s = Math.max(0, ms / 1000);
		return (s / 60) + ":" + String.format("%02d", s % 60);
	}

	@Override
	public void render(DrawContext ctx, int mx, int my, float delta) {
		long hnd = Ui.handle();
		boolean l = GLFW.glfwGetMouseButton(hnd, 0) == GLFW.GLFW_PRESS;
		boolean click = l && !pl;
		pl = l;
		boolean enter = GLFW.glfwGetKey(hnd, GLFW.GLFW_KEY_ENTER) == GLFW.GLFW_PRESS
				|| GLFW.glfwGetKey(hnd, GLFW.GLFW_KEY_KP_ENTER) == GLFW.GLFW_PRESS;
		if (enter && !enterPrev && field.isFocused()) doSearch();
		enterPrev = enter;

		int acc = Theme.accent();
		WindowModules.Music cfg = WindowModules.music();
		ctx.fill(0, 0, width, height, 0x88000000);
		int x = (width - W) / 2, y = (height - H) / 2;
		Ui.window(ctx, textRenderer, x, y, W, H, "Music", "08_new_gui_icons/newnext", acc);

		boolean hc = Theme.in(mx, my, x + W - 18, y + 3, 14, 14);
		Ui.iconButton(ctx, x + W - 18, y + 3, 14, 14, "08_new_gui_icons/newclose", hc, false, acc);
		if (hc && click) {
			close();
			return;
		}

		// search button + source
		boolean hs = Theme.in(mx, my, x + W - 66 - 8 + 4, y + 25, 62, 18);
		Ui.button(ctx, textRenderer, x + W - 66 - 8 + 4, y + 25, 62, 18, "Search", hs, MusicPlayer.searching, acc);
		if (hs && click) doSearch();

		// presets + source
		int py = y + 48;
		int px = x + 8;
		for (String p : PRESETS) {
			int w = textRenderer.getWidth(p) + 10;
			boolean hv = Theme.in(mx, my, px, py, w, 13);
			Ui.button(ctx, textRenderer, px, py, w, 13, p, hv, false, acc);
			if (hv && click) {
				field.setText(p);
				doSearch();
			}
			px += w + 4;
		}
		int bx = x + 8, byy = py + 17;
		for (String[] b : BROWSE) {
			int w = textRenderer.getWidth(b[0]) + 10;
			boolean hv = Theme.in(mx, my, bx, byy, w, 13);
			Ui.button(ctx, textRenderer, bx, byy, w, 13, b[0], hv, true, acc);
			if (hv && click) {
				field.setText(b[1]);
				doSearch();
			}
			bx += w + 4;
		}
		if (cfg != null) {
			String src = "Source: " + cfg.source.value.split(" ")[0];
			int w = textRenderer.getWidth(src) + 10;
			int sx = x + W - 8 - w;
			int sy = py + 17;
			boolean hv = Theme.in(mx, my, sx, sy, w, 13);
			Ui.button(ctx, textRenderer, sx, sy, w, 13, src, hv, false, acc);
			if (hv && click) cfg.source.cycle();
		}

		// results
		int ly0 = y + 84, ly1 = y + H - 66;
		ctx.fill(x + 8, ly0 - 2, x + W - 8, ly1, 0xFF121216);
		List<MusicPlayer.Track> res = MusicPlayer.results;
		float total = res.size() * ROW;
		scrollT = MathHelper.clamp(scrollT, 0f, Math.max(0f, total - (ly1 - ly0)));
		scroll += (scrollT - scroll) * 0.35f;
		ctx.enableScissor(x + 8, ly0 - 2, x + W - 8, ly1);
		for (int i = 0; i < res.size(); i++) {
			int ry = ly0 + i * ROW - Math.round(scroll);
			if (ry + ROW < ly0 || ry > ly1) continue;
			MusicPlayer.Track t = res.get(i);
			boolean cur = i == MusicPlayer.currentIndex && MusicPlayer.current != null;
			boolean hv = Theme.in(mx, my, x + 8, ry, W - 16, ROW) && my >= ly0 && my < ly1;
			if (cur) ctx.fill(x + 8, ry, x + W - 8, ry + ROW, Theme.alpha(acc, 0x66));
			else if (hv) ctx.fill(x + 8, ry, x + W - 8, ry + ROW, 0xFF1E1E25);
			String num = String.valueOf(i + 1);
			ctx.drawText(textRenderer, num, x + 12, ry + 4, 0xFF6C6C76, false);
			String title = textRenderer.trimToWidth(t.title(), 190);
			ctx.drawText(textRenderer, title, x + 32, ry + 4, 0xFFFFFFFF, false);
			String art = textRenderer.trimToWidth(t.artist(), 90);
			ctx.drawText(textRenderer, art, x + 228, ry + 4, 0xFFB4B4BC, false);
			String info = t.source().startsWith("Deezer") ? "30s" : time(t.seconds() * 1000L);
			ctx.drawText(textRenderer, info, x + W - 12 - textRenderer.getWidth(info), ry + 4, 0xFF8A8A94, false);
			if (hv && click) MusicPlayer.play(i);
		}
		ctx.disableScissor();
		if (res.isEmpty()) {
			String s = MusicPlayer.searching ? "Searching..." : "Search for a song, or tap a preset above";
			ctx.drawText(textRenderer, s, x + W / 2 - textRenderer.getWidth(s) / 2, ly0 + 30, 0xFF6C6C76, false);
		}

		// player bar
		int by = y + H - 58;
		MusicPlayer.Track cur = MusicPlayer.current;
		String now = cur == null ? "Nothing playing" : cur.title() + " - " + cur.artist();
		ctx.drawText(textRenderer, textRenderer.trimToWidth(now, W - 130), x + 8, by, cur == null ? 0xFF8A8A94 : acc, false);
		String tm = time(MusicPlayer.posMs) + " / " + time(MusicPlayer.totalMs);
		ctx.drawText(textRenderer, tm, x + W - 8 - textRenderer.getWidth(tm), by, 0xFFB4B4BC, false);
		float pct = MusicPlayer.totalMs <= 0 ? 0f : MusicPlayer.posMs / (float) MusicPlayer.totalMs;
		ctx.fill(x + 8, by + 13, x + W - 8, by + 15, 0xFF2A2A31);
		ctx.fill(x + 8, by + 13, x + 8 + Math.round((W - 16) * Math.min(1f, pct)), by + 15, acc);

		int cy = by + 22;
		int bx = x + 8;
		bx = ctl(ctx, bx, cy, "08_new_gui_icons/newrearrange", "<<", mx, my, click, false, acc, MusicPlayer::prev);
		boolean playingNow = cur != null && !MusicPlayer.paused;
		bx = ctl(ctx, bx, cy, null, playingNow ? "Pause" : "Play", mx, my, click, playingNow, acc, () -> {
			if (MusicPlayer.current == null) MusicPlayer.play(Math.max(0, MusicPlayer.currentIndex));
			else MusicPlayer.togglePause();
		});
		bx = ctl(ctx, bx, cy, null, ">>", mx, my, click, false, acc, MusicPlayer::next);
		ctl(ctx, bx, cy, null, "Stop", mx, my, click, false, acc, MusicPlayer::stop);

		if (cfg != null) {
			String vl = "Vol " + cfg.volume.i() + "%";
			int vw = 110, vx = x + W - 8 - vw, vy = cy + 6;
			ctx.drawText(textRenderer, vl, vx - textRenderer.getWidth(vl) - 8, cy + 3, 0xFFB4B4BC, false);
			Ui.slider(ctx, vx, vy, vw, (float) (cfg.volume.get() / 100.0), acc);
			if (click && Theme.in(mx, my, vx - 3, vy - 5, vw + 6, 13)) dragVol = true;
			if (!l) dragVol = false;
			if (dragVol) cfg.volume.set(100.0 * MathHelper.clamp((mx - vx) / (double) vw, 0.0, 1.0));
		}

		String st = MusicPlayer.status;
		ctx.drawText(textRenderer, textRenderer.trimToWidth(st, W - 16), x + 8, y + H - 13, 0xFF8A8A94, false);

		super.render(ctx, mx, my, delta); // draws the search field
	}

	private int ctl(DrawContext ctx, int bx, int cy, String icon, String label, int mx, int my, boolean click,
					boolean active, int acc, Runnable r) {
		int w = Math.max(30, textRenderer.getWidth(label) + 12);
		boolean hv = Theme.in(mx, my, bx, cy, w, 14);
		Ui.button(ctx, textRenderer, bx, cy, w, 14, label, hv, active, acc);
		if (hv && click) r.run();
		return bx + w + 4;
	}
}
