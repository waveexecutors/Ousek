package dev.ousek.gui;

import dev.ousek.emote.EmoteData;
import dev.ousek.emote.EmoteManager;
import net.minecraft.client.gui.DrawContext;
import net.minecraft.client.gui.screen.Screen;
import net.minecraft.text.Text;

/**
 * Window to pick and play JSON emotes on the local player with loop / allow-movement toggles.
 */
public class EmoteScreen extends Screen {
	private static final int W = 280, ROW = 36, PAD = 10;
	private final Screen parent;
	private int scroll;

	public EmoteScreen(Screen parent) {
		super(Text.literal("Emotes"));
		this.parent = parent;
	}

	@Override
	protected void init() {
		EmoteManager.ensureLoaded();
	}

	@Override
	public void render(DrawContext ctx, int mouseX, int mouseY, float delta) {
		this.renderBackground(ctx, mouseX, mouseY, delta);
		int left = (width - W) / 2;
		int top = 40;
		int listCount = Math.max(1, EmoteManager.EMOTES.size());
		int h = Math.min(height - 80, 28 + listCount * ROW + 70);

		Theme.rrect(ctx, left, top, W, h, 6, 0xE012141C);
		ctx.fill(left, top, left + W, top + 22, Theme.accent());
		ctx.drawText(textRenderer, "Ousek Emotes", left + 10, top + 7, 0xFFFFFFFF, false);

		int ty = top + h - 52;
		drawToggle(ctx, left + PAD, ty, "Loop", EmoteManager.loop, mouseX, mouseY);
		drawToggle(ctx, left + PAD + 90, ty, "While moving", EmoteManager.allowMove, mouseX, mouseY);
		if (EmoteManager.playing != null) {
			ctx.drawText(textRenderer, "Playing: " + EmoteManager.playing.name, left + PAD, ty + 20, 0xFFAAAAAA, false);
			boolean stopHover = Theme.in(mouseX, mouseY, left + W - 70, ty + 16, 56, 16);
			Theme.rrect(ctx, left + W - 70, ty + 16, 56, 16, 3, stopHover ? 0xFFFF3B52 : 0xFF333844);
			ctx.drawText(textRenderer, "Stop", left + W - 54, ty + 20, 0xFFFFFFFF, false);
		}

		int y = top + 28 - scroll;
		int i = 0;
		for (EmoteData e : EmoteManager.EMOTES) {
			int ry = y + i * ROW;
			if (ry + ROW < top + 24 || ry > top + h - 56) {
				i++;
				continue;
			}
			boolean hover = Theme.in(mouseX, mouseY, left + 4, ry, W - 8, ROW - 2);
			boolean active = EmoteManager.playing == e;
			int bg = active ? Theme.alpha(Theme.accent(), 0x55) : hover ? 0xFF1C2030 : 0xFF161820;
			Theme.rrect(ctx, left + 4, ry, W - 8, ROW - 2, 4, bg);

			// icon placeholder with initial
			int accent = Theme.accent();
			Theme.rrect(ctx, left + 10, ry + 5, 26, 26, 4, Theme.alpha(accent, 0xAA));
			String letter = e.name.isEmpty() ? "?" : e.name.substring(0, 1).toUpperCase();
			int lw = textRenderer.getWidth(letter);
			ctx.drawText(textRenderer, letter, left + 10 + (26 - lw) / 2, ry + 13, 0xFFFFFFFF, false);

			ctx.drawText(textRenderer, e.name, left + 44, ry + 8, 0xFFFFFFFF, false);
			String sub = e.author.isEmpty() ? e.description : e.author;
			if (sub.length() > 28) sub = sub.substring(0, 28) + "…";
			ctx.drawText(textRenderer, sub, left + 44, ry + 19, 0xFF888899, false);
			i++;
		}

		super.render(ctx, mouseX, mouseY, delta);
	}

	void drawToggle(DrawContext ctx, int x, int y, String label, boolean on, int mx, int my) {
		boolean hover = Theme.in(mx, my, x, y, 80, 16);
		int col = on ? Theme.accent() : (hover ? 0xFF3A3F50 : 0xFF2A2E3A);
		Theme.rrect(ctx, x, y, 80, 16, 3, col);
		ctx.drawText(textRenderer, label, x + 6, y + 4, 0xFFFFFFFF, false);
	}

	@Override
	public boolean mouseClicked(double mouseX, double mouseY, int button) {
		int left = (width - W) / 2;
		int top = 40;
		int listCount = Math.max(1, EmoteManager.EMOTES.size());
		int h = Math.min(height - 80, 28 + listCount * ROW + 70);
		int ty = top + h - 52;

		if (Theme.in((int) mouseX, (int) mouseY, left + PAD, ty, 80, 16)) {
			EmoteManager.loop = !EmoteManager.loop;
			return true;
		}
		if (Theme.in((int) mouseX, (int) mouseY, left + PAD + 90, ty, 100, 16)) {
			EmoteManager.allowMove = !EmoteManager.allowMove;
			return true;
		}
		if (EmoteManager.playing != null && Theme.in((int) mouseX, (int) mouseY, left + W - 70, ty + 16, 56, 16)) {
			EmoteManager.stop();
			return true;
		}

		int y = top + 28 - scroll;
		int i = 0;
		for (EmoteData e : EmoteManager.EMOTES) {
			int ry = y + i * ROW;
			if (Theme.in((int) mouseX, (int) mouseY, left + 4, ry, W - 8, ROW - 2)) {
				EmoteManager.play(e);
				return true;
			}
			i++;
		}
		return super.mouseClicked(mouseX, mouseY, button);
	}

	@Override
	public boolean mouseScrolled(double mouseX, double mouseY, double horizontalAmount, double verticalAmount) {
		scroll = (int) Math.max(0, scroll - verticalAmount * 12);
		return true;
	}

	@Override
	public void close() {
		if (client != null) client.setScreen(parent);
	}

	@Override
	public boolean shouldPause() {
		return false;
	}
}
