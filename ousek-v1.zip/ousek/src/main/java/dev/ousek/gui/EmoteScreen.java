package dev.ousek.gui;

import dev.ousek.config.Config;
import dev.ousek.emote.Emote;
import dev.ousek.emote.EmoteManager;
import dev.ousek.module.impl.WindowModules;
import dev.ousek.setting.Setting;
import net.minecraft.client.gui.DrawContext;
import net.minecraft.client.gui.screen.Screen;
import net.minecraft.text.Text;
import net.minecraft.util.math.MathHelper;
import org.lwjgl.glfw.GLFW;

import java.util.List;

/** Window that plays the JSON emotes on your character. */
public class EmoteScreen extends Screen {
	private static final int W = 400, H = 286, CW = 58, CH = 70, GAP = 4;
	private final Screen parent;
	private boolean pl = true;
	private boolean dragSpeed;
	private float scroll, scrollT;
	private int gx0, gy0, gx1, gy1;

	public EmoteScreen(Screen parent) {
		super(Text.literal("Emotes"));
		this.parent = parent;
	}

	@Override
	protected void init() {
		pl = GLFW.glfwGetMouseButton(Ui.handle(), 0) == GLFW.GLFW_PRESS;
	}

	@Override
	public boolean shouldPause() {
		return false;
	}

	@Override
	public void renderBackground(DrawContext ctx, int mouseX, int mouseY, float delta) {
	}

	@Override
	public void close() {
		Config.save();
		if (client != null) client.setScreen(parent);
	}

	@Override
	public boolean mouseScrolled(double mx, double my, double hAmount, double vAmount) {
		scrollT -= (float) vAmount * 24f;
		return true;
	}

	@Override
	public void render(DrawContext ctx, int mx, int my, float delta) {
		boolean l = GLFW.glfwGetMouseButton(Ui.handle(), 0) == GLFW.GLFW_PRESS;
		boolean click = l && !pl;
		pl = l;
		int acc = Theme.accent();
		WindowModules.Emotes cfg = WindowModules.emotes();
		List<Emote> list = EmoteManager.ALL;

		ctx.fill(0, 0, width, height, 0x88000000);
		int x = (width - W) / 2, y = (height - H) / 2;
		Ui.window(ctx, textRenderer, x, y, W, H, "Emotes  (" + list.size() + ")", "09_ui_elements/animations", acc);

		// close
		boolean hc = Theme.in(mx, my, x + W - 18, y + 3, 14, 14);
		Ui.iconButton(ctx, x + W - 18, y + 3, 14, 14, "08_new_gui_icons/newclose", hc, false, acc);
		if (hc && click) {
			close();
			return;
		}

		// grid
		gx0 = x + 8;
		gy0 = y + 26;
		gx1 = x + W - 8;
		gy1 = y + H - 74;
		int cols = Math.max(1, (gx1 - gx0 + GAP) / (CW + GAP));
		int rows = (list.size() + cols - 1) / cols;
		float total = rows * (CH + GAP);
		float vis = gy1 - gy0;
		scrollT = MathHelper.clamp(scrollT, 0f, Math.max(0f, total - vis));
		scroll += (scrollT - scroll) * 0.35f;

		ctx.enableScissor(gx0, gy0, gx1, gy1);
		for (int i = 0; i < list.size(); i++) {
			Emote e = list.get(i);
			int cx = gx0 + (i % cols) * (CW + GAP);
			int cy = gy0 + (i / cols) * (CH + GAP) - Math.round(scroll);
			if (cy + CH < gy0 || cy > gy1) continue;
			boolean hv = Theme.in(mx, my, cx, cy, CW, CH) && my >= gy0 && my < gy1;
			boolean on = EmoteManager.isPlaying(e);
			Theme.rrect(ctx, cx, cy, CW, CH, 4, on ? Theme.alpha(acc, 0xFF) : 0xFF1A1A20);
			Theme.rrect(ctx, cx + 1, cy + 1, CW - 2, CH - 2, 4, hv ? 0xFF24242C : 0xFF16161A);
			if (on) ctx.fill(cx + 4, cy + CH - 2, cx + CW - 4, cy + CH - 1, acc);
			if (e.icon != null && Tex.has(e.icon)) {
				Tex.fit(ctx, e.icon, cx + 5, cy + 5, CW - 10, CW - 10, 0xFFFFFFFF);
			} else {
				Theme.rrect(ctx, cx + 5, cy + 5, CW - 10, CW - 10, 3, 0xFF202028);
				String ch = e.name.isEmpty() ? "?" : e.name.substring(0, 1).toUpperCase();
				Fonts.draw(ctx, textRenderer, ch, cx + CW / 2 - Fonts.width(textRenderer, ch) / 2, cy + 22, acc, false);
			}
			String nm = textRenderer.trimToWidth(e.name, CW - 4);
			Fonts.draw(ctx, textRenderer, nm, cx + CW / 2 - Fonts.width(textRenderer, nm) / 2, cy + CW - 2, 0xFFFFFFFF, false);
			if (hv && click) {
				if (on) EmoteManager.stop();
				else EmoteManager.play(e);
			}
		}
		ctx.disableScissor();
		if (list.isEmpty()) {
			String s = "No emotes found. Put Emotecraft .json files in <game dir>/ousek/emotes";
			Fonts.draw(ctx, textRenderer, s, x + W / 2 - Fonts.width(textRenderer, s) / 2, y + 60, 0xFF8A8A94, false);
		}

		// footer
		int fy = y + H - 66;
		ctx.fill(x + 8, fy - 4, x + W - 8, fy - 3, 0xFF26262E);
		Emote cur = EmoteManager.current;
		String now = cur == null ? "Nothing playing" : "Playing: " + cur.name + (cur.author.isEmpty() ? "" : "  by " + cur.author);
		Fonts.draw(ctx, textRenderer, textRenderer.trimToWidth(now, W - 100), x + 8, fy, cur == null ? 0xFF8A8A94 : acc, false);

		boolean hs = Theme.in(mx, my, x + W - 62, fy - 3, 54, 14);
		Ui.button(ctx, textRenderer, x + W - 62, fy - 3, 54, 14, "Stop", hs, false, acc);
		if (hs && click) EmoteManager.stop();

		if (cfg != null) {
			int ty = fy + 18;
			int tx = x + 8;
			tx = toggleAt(ctx, cfg.loop, "Loop", tx, ty, mx, my, click, acc) + 14;
			tx = toggleAt(ctx, cfg.whileMoving, "Play while moving", tx, ty, mx, my, click, acc) + 14;
			toggleAt(ctx, cfg.thirdPerson, "Auto 3rd person", tx, ty, mx, my, click, acc);

			int sy = fy + 38;
			String lab = "Speed";
			Fonts.draw(ctx, textRenderer, lab, x + 8, sy - 2, 0xFFB4B4BC, false);
			int sx = x + 52, sw = W - 52 - 70;
			Setting.Num sp = cfg.speed;
			Ui.slider(ctx, sx, sy, sw, (float) ((sp.get() - sp.min) / (sp.max - sp.min)), acc);
			String val = String.format(java.util.Locale.ROOT, "%.2fx", sp.get());
			Fonts.draw(ctx, textRenderer, val, x + W - 8 - Fonts.width(textRenderer, val), sy - 2, 0xFFFFFFFF, false);
			if (click && Theme.in(mx, my, sx - 3, sy - 5, sw + 6, 13)) dragSpeed = true;
			if (!l) dragSpeed = false;
			if (dragSpeed) sp.set(sp.min + (sp.max - sp.min) * MathHelper.clamp((mx - sx) / (double) sw, 0.0, 1.0));
		}
	}

	private int toggleAt(DrawContext ctx, Setting.Bool b, String label, int tx, int ty, int mx, int my, boolean click, int acc) {
		int w = Ui.toggleWidth(textRenderer, label);
		boolean hv = Theme.in(mx, my, tx, ty - 2, w, 12);
		Ui.toggle(ctx, textRenderer, tx, ty, label, b.on(), hv, acc);
		if (hv && click) b.value = !b.value;
		return tx + w;
	}
}
