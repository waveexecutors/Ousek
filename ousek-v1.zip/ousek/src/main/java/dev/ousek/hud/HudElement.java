package dev.ousek.hud;

import dev.ousek.gui.Theme;
import dev.ousek.module.Category;
import dev.ousek.module.Module;
import dev.ousek.setting.Setting;
import net.minecraft.client.gui.DrawContext;

public abstract class HudElement extends Module {
	public int x, y, w = 60, h = 12;
	public final int defX, defY;
	public final boolean right;

	protected final Setting.Bool background = bool("Background", true);
	protected final Setting.Bool shadow = bool("Text shadow", true);
	protected final Setting.Mode color = mode("Color", "Accent", "Accent", "Rainbow", "White");
	protected final Setting.Num scale = num("Scale", 1.0, 0.5, 2.0, 0.1);

	protected HudElement(String name, String desc, int x, int y, boolean right, boolean on) {
		super(name, desc, Category.HUD);
		this.x = this.defX = x;
		this.y = this.defY = y;
		this.right = right;
		this.enabled = on;
	}

	public void reset() {
		x = defX;
		y = defY;
	}

	public final int boundsX() {
		return right ? Math.round(x - w * scale.f()) : x;
	}

	public final int boundsW() {
		return Math.round(w * scale.f());
	}

	public final int boundsH() {
		return Math.round(h * scale.f());
	}

	public final void draw(DrawContext ctx) {
		if (x < 0) x = ctx.getScaledWindowWidth() + x;
		if (y < 0) y = ctx.getScaledWindowHeight() + y;
		float s = scale.f();
		ctx.getMatrices().pushMatrix();
		ctx.getMatrices().translate((float) boundsX(), (float) y);
		ctx.getMatrices().scale(s, s);
		try {
			render(ctx);
		} finally {
			ctx.getMatrices().popMatrix();
		}
	}

	protected abstract void render(DrawContext ctx);

	protected int col(int index) {
		if (color.is("Rainbow")) return Theme.rainbow(index);
		if (color.is("White")) return 0xFFFFFFFF;
		return Theme.accent();
	}

	protected void text(DrawContext c, String s, int px, int py, int col) {
		c.drawText(mc.textRenderer, s, px, py, col, shadow.on());
	}

	protected int tw(String s) {
		return mc.textRenderer.getWidth(s);
	}

	protected void box(DrawContext c, int px, int py, int pw, int ph) {
		if (background.on()) Theme.rrect(c, px, py, pw, ph, 3, 0xA0101014);
	}
}
