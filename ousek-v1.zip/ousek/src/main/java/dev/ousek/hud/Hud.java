package dev.ousek.hud;

import dev.ousek.gui.Theme;
import dev.ousek.module.Module;
import dev.ousek.module.ModuleManager;
import dev.ousek.module.impl.ClickGuiModule;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.gui.DrawContext;

import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;

public final class Hud {
	private static final List<Object[]> notes = new ArrayList<>();

	private Hud() {
	}

	public static void notify(String text, boolean good) {
		ClickGuiModule g = ModuleManager.get(ClickGuiModule.class);
		if (g != null && !g.notifications.on()) return;
		notes.add(new Object[]{text, good, System.currentTimeMillis()});
		if (notes.size() > 6) notes.remove(0);
	}

	private static String banName = "";
	private static long banAt;

	/** Centre-screen warning shown whenever a Blatant module is toggled. */
	public static void bannable(String name, boolean on) {
		banName = name + (on ? " enabled" : " disabled");
		banAt = System.currentTimeMillis();
	}

	private static void drawBan(DrawContext ctx, MinecraftClient mc) {
		long age = System.currentTimeMillis() - banAt;
		if (banAt == 0 || age > 3500) return;
		float a = age < 200 ? age / 200f : age > 3000 ? Math.max(0f, 1f - (age - 3000) / 500f) : 1f;
		int w = ctx.getScaledWindowWidth(), h = ctx.getScaledWindowHeight();
		String l1 = "BANNABLE";
		String l2 = banName + " - this can get you banned";
		int bw = Math.max(mc.textRenderer.getWidth(l2), mc.textRenderer.getWidth(l1) * 2) + 24, bh = 40;
		int x = w / 2 - bw / 2, y = h / 2 - 60;
		dev.ousek.gui.Theme.rrect(ctx, x, y, bw, bh, 3, dev.ousek.gui.Theme.fade(0xE6140808, a));
		dev.ousek.gui.Theme.rrect(ctx, x, y, bw, 2, 1, dev.ousek.gui.Theme.fade(0xFFFF3B3B, a));
		ctx.getMatrices().pushMatrix();
		ctx.getMatrices().translate(w / 2f, y + 6f);
		ctx.getMatrices().scale(2f, 2f);
		ctx.drawText(mc.textRenderer, l1, -mc.textRenderer.getWidth(l1) / 2, 0, dev.ousek.gui.Theme.fade(0xFFFF4444, a), false);
		ctx.getMatrices().popMatrix();
		ctx.drawText(mc.textRenderer, l2, w / 2 - mc.textRenderer.getWidth(l2) / 2, y + 27, dev.ousek.gui.Theme.fade(0xFFFFFFFF, a), false);
	}

	public static void render(DrawContext ctx) {
		MinecraftClient mc = MinecraftClient.getInstance();
		if (mc.player == null || mc.options.hudHidden) return;
		try {
			drawBan(ctx, mc);
		} catch (Throwable ignored) {
		}

		for (Module m : ModuleManager.modules) {
			if (m.enabled && !(m instanceof HudElement)) {
				try {
					m.onHud(ctx);
				} catch (Throwable ignored) {
				}
			}
		}

		for (Module m : ModuleManager.modules) {
			if (m instanceof HudElement e && e.enabled) {
				try {
					e.draw(ctx);
				} catch (Throwable ignored) {
				}
			}
		}

		long now = System.currentTimeMillis();
		Iterator<Object[]> it = notes.iterator();
		while (it.hasNext()) if (now - (Long) it.next()[2] > 2400L) it.remove();
		int y = ctx.getScaledWindowHeight() - 40;
		for (int i = notes.size() - 1; i >= 0; i--) {
			Object[] n = notes.get(i);
			long age = now - (Long) n[2];
			float in = Theme.ease(Math.min(1f, age / 220f));
			float out = Theme.ease(Math.min(1f, (2400L - age) / 220f));
			float f = Math.min(in, out);
			String s = (String) n[0];
			int w = mc.textRenderer.getWidth(s) + 26;
			int x = ctx.getScaledWindowWidth() - w - 6 + (int) ((1f - f) * (w + 10));
			int dot = ((Boolean) n[1]) ? 0xFF4BE08A : 0xFFFF5A6A;
			Theme.rrect(ctx, x, y, w, 16, 4, Theme.fade(0xC0101014, f));
			ctx.fill(x + 3, y + 4, x + 5, y + 12, Theme.fade(dot, f));
			dev.ousek.gui.Tex.fit(ctx, ((Boolean) n[1]) ? "03_notifications/noti_online" : "03_notifications/noti_warning",
					x + 8, y + 2, 12, 12, Theme.fade(0xFFFFFFFF, f));
			if (f > 0.1f) ctx.drawText(mc.textRenderer, s, x + 23, y + 4, Theme.fade(0xFFFFFFFF, f), false);
			y -= 19;
		}
	}
}
