package dev.ousek.hud;

import dev.ousek.gui.Theme;
import dev.ousek.module.Module;
import dev.ousek.module.ModuleManager;
import dev.ousek.module.impl.ClickGuiModule;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.gui.DrawContext;

import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;

public final class Hud {
	private static final List<Object[]> notes = new ArrayList<>();

	private Hud() {
	}

	public static void notify(String text, boolean good) {
		ClickGuiModule g = ModuleManager.get(ClickGuiModule.class);
		if (g != null && !g.notifications.on()) return;
		notes.add(new Object[]{text, good, System.currentTimeMillis() + 2200L});
		if (notes.size() > 6) notes.remove(0);
	}

	public static void render(DrawContext ctx) {
		MinecraftClient mc = MinecraftClient.getInstance();
		if (mc.player == null || mc.options.hudHidden) return;

		for (Module m : ModuleManager.modules) {
			if (m instanceof HudElement e && e.enabled) {
				try {
					e.draw(ctx);
				} catch (Throwable ignored) {
				}
			}
		}

		long now = System.currentTimeMillis();
		Iterator<Object[]> it = notes.iterator();
		while (it.hasNext()) if ((Long) it.next()[2] < now) it.remove();
		int y = ctx.getScaledWindowHeight() - 40;
		for (int i = notes.size() - 1; i >= 0; i--) {
			Object[] n = notes.get(i);
			String s = (String) n[0];
			int w = mc.textRenderer.getWidth(s) + 14;
			int x = ctx.getScaledWindowWidth() - w - 6;
			int dot = ((Boolean) n[1]) ? 0xFF4BE08A : 0xFFFF5A6A;
			Theme.rrect(ctx, x, y, w, 16, 4, 0xC0101014);
			ctx.fill(x + 3, y + 4, x + 5, y + 12, dot);
			ctx.drawText(mc.textRenderer, s, x + 9, y + 4, 0xFFFFFFFF, false);
			y -= 19;
		}
	}
}
