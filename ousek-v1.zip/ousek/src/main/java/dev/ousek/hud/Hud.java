package dev.ousek.hud;

import dev.ousek.gui.Theme;
import dev.ousek.module.Module;
import dev.ousek.module.ModuleManager;
import dev.ousek.module.impl.ClickGuiModule;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.gui.DrawContext;

import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;

public final class Hud {
	private static final List<Object[]> notes = new ArrayList<>();

	private Hud() {
	}

	public static void notify(String text, boolean good) {
		ClickGuiModule g = ModuleManager.get(ClickGuiModule.class);
		if (g != null && !g.notifications.on()) return;
		notes.add(new Object[]{text, good, System.currentTimeMillis()});
		if (notes.size() > 6) notes.remove(0);
	}

	public static void render(DrawContext ctx) {
		MinecraftClient mc = MinecraftClient.getInstance();
		if (mc.player == null || mc.options.hudHidden) return;

		for (Module m : ModuleManager.modules) {
			if (m.enabled && !(m instanceof HudElement)) {
				try {
					m.onHud(ctx);
				} catch (Throwable ignored) {
				}
			}
		}

		for (Module m : ModuleManager.modules) {
			if (m instanceof HudElement e && e.enabled) {
				try {
					e.draw(ctx);
				} catch (Throwable ignored) {
				}
			}
		}

		long now = System.currentTimeMillis();
		Iterator<Object[]> it = notes.iterator();
		while (it.hasNext()) if (now - (Long) it.next()[2] > 2400L) it.remove();
		int y = ctx.getScaledWindowHeight() - 40;
		for (int i = notes.size() - 1; i >= 0; i--) {
			Object[] n = notes.get(i);
			long age = now - (Long) n[2];
			float in = Theme.ease(Math.min(1f, age / 220f));
			float out = Theme.ease(Math.min(1f, (2400L - age) / 220f));
			float f = Math.min(in, out);
			String s = (String) n[0];
			int w = mc.textRenderer.getWidth(s) + 26;
			int x = ctx.getScaledWindowWidth() - w - 6 + (int) ((1f - f) * (w + 10));
			int dot = ((Boolean) n[1]) ? 0xFF4BE08A : 0xFFFF5A6A;
			Theme.rrect(ctx, x, y, w, 16, 4, Theme.fade(0xC0101014, f));
			ctx.fill(x + 3, y + 4, x + 5, y + 12, Theme.fade(dot, f));
			dev.ousek.gui.Tex.fit(ctx, ((Boolean) n[1]) ? "03_notifications/noti_online" : "03_notifications/noti_warning",
					x + 8, y + 2, 12, 12, Theme.fade(0xFFFFFFFF, f));
			if (f > 0.1f) ctx.drawText(mc.textRenderer, s, x + 23, y + 4, Theme.fade(0xFFFFFFFF, f), false);
			y -= 19;
		}
	}
}
