package dev.ousek;

import dev.ousek.alt.AltScreen;
import dev.ousek.config.Config;
import dev.ousek.gui.Theme;
import dev.ousek.hud.Hud;
import dev.ousek.module.ModuleManager;
import net.fabricmc.api.ClientModInitializer;
import net.fabricmc.fabric.api.client.event.lifecycle.v1.ClientLifecycleEvents;
import net.fabricmc.fabric.api.client.event.lifecycle.v1.ClientTickEvents;
import net.fabricmc.fabric.api.client.message.v1.ClientReceiveMessageEvents;
import net.fabricmc.fabric.api.client.rendering.v1.HudRenderCallback;
import net.fabricmc.fabric.api.client.screen.v1.ScreenEvents;
import net.fabricmc.fabric.api.client.screen.v1.Screens;
import net.minecraft.client.gui.screen.TitleScreen;
import net.minecraft.client.gui.widget.ButtonWidget;
import net.minecraft.text.Text;

public class Ousek implements ClientModInitializer {
	public static final String NAME = "Ousek";
	public static final String VERSION = "v1";

	@Override
	public void onInitializeClient() {
		ModuleManager.init();
		dev.ousek.emote.EmoteManager.load();
		Config.load();

		ClientTickEvents.END_CLIENT_TICK.register(client -> {
			ModuleManager.tick();
			dev.ousek.accessory.AccessoryFeature.tick();
		});
		HudRenderCallback.EVENT.register((ctx, tickCounter) -> Hud.render(ctx));
		ClientReceiveMessageEvents.GAME.register((message, overlay) -> ModuleManager.chat(message.getString()));
		ClientLifecycleEvents.CLIENT_STOPPING.register(client -> Config.save());

		ScreenEvents.AFTER_INIT.register((client, screen, w, h) -> {
			if (!(screen instanceof TitleScreen)) return;
			Screens.getButtons(screen).add(ButtonWidget.builder(Text.literal("Alt Manager"),
					b -> client.setScreen(new AltScreen(screen))).dimensions(6, 6, 100, 20).build());
			ScreenEvents.afterRender(screen).register((s, ctx, mx, my, delta) -> {
				var tr = client.textRenderer;
				String user = client.getSession().getUsername();
				ctx.drawText(tr, "Logged in as " + user, 6, 30, 0xFFFFFFFF, true);
				ctx.drawText(tr, NAME + " " + VERSION, 6, 42, Theme.accent(), true);
			});
		});
	}
}
