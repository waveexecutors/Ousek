package dev.ousek.setting;

public abstract class Setting<T> {
	public final String name;
	public T value;

	protected Setting(String name, T value) {
		this.name = name;
		this.value = value;
	}

	public abstract String save();

	public abstract void load(String raw);

	public static class Bool extends Setting<Boolean> {
		public Bool(String name, boolean def) {
			super(name, def);
		}

		public boolean on() {
			return value;
		}

		@Override
		public String save() {
			return Boolean.toString(value);
		}

		@Override
		public void load(String raw) {
			value = Boolean.parseBoolean(raw);
		}
	}

	public static class Num extends Setting<Double> {
		public final double min, max, step;

		public Num(String name, double def, double min, double max, double step) {
			super(name, def);
			this.min = min;
			this.max = max;
			this.step = step;
		}

		public double get() {
			return value;
		}

		public int i() {
			return (int) Math.round(value);
		}

		public float f() {
			return value.floatValue();
		}

		public void set(double v) {
			v = Math.max(min, Math.min(max, v));
			if (step > 0) v = Math.round(v / step) * step;
			value = v;
		}

		@Override
		public String save() {
			return Double.toString(value);
		}

		@Override
		public void load(String raw) {
			try {
				set(Double.parseDouble(raw));
			} catch (NumberFormatException ignored) {
			}
		}
	}

	public static class Mode extends Setting<String> {
		public final String[] modes;

		public Mode(String name, String def, String... modes) {
			super(name, def);
			this.modes = modes;
		}

		public boolean is(String m) {
			return value.equalsIgnoreCase(m);
		}

		public void cycle() {
			for (int i = 0; i < modes.length; i++) {
				if (modes[i].equals(value)) {
					value = modes[(i + 1) % modes.length];
					return;
				}
			}
			value = modes[0];
		}

		@Override
		public String save() {
			return value;
		}

		@Override
		public void load(String raw) {
			for (String m : modes) {
				if (m.equals(raw)) {
					value = m;
					return;
				}
			}
		}
	}
}
