package dev.ousek.setting;

public abstract class Setting<T> {
	public final String name;
	public T value;
	public float anim;
	public float hover;

	protected Setting(String name, T value) {
		this.name = name;
		this.value = value;
	}

	public abstract String save();

	public abstract void load(String raw);

	public static class Bool extends Setting<Boolean> {
		public Bool(String name, boolean def) {
			super(name, def);
			anim = def ? 1f : 0f;
		}

		public boolean on() {
			return value;
		}

		@Override
		public String save() {
			return Boolean.toString(value);
		}

		@Override
		public void load(String raw) {
			value = Boolean.parseBoolean(raw);
			anim = value ? 1f : 0f;
		}
	}

	public static class Num extends Setting<Double> {
		public final double min, max, step;

		public Num(String name, double def, double min, double max, double step) {
			super(name, def);
			this.min = min;
			this.max = max;
			this.step = step;
			anim = (float) ((def - min) / (max - min));
		}

		public double get() {
			return value;
		}

		public int i() {
			return (int) Math.round(value);
		}

		public float f() {
			return value.floatValue();
		}

		public void set(double v) {
			v = Math.max(min, Math.min(max, v));
			if (step > 0) v = Math.round(v / step) * step;
			value = v;
		}

		@Override
		public String save() {
			return Double.toString(value);
		}

		@Override
		public void load(String raw) {
			try {
				set(Double.parseDouble(raw));
				anim = (float) ((value - min) / (max - min));
			} catch (NumberFormatException ignored) {
			}
		}
	}

	public static class Mode extends Setting<String> {
		public final String[] modes;

		public Mode(String name, String def, String... modes) {
			super(name, def);
			this.modes = modes;
			anim = modes.length > 1 ? index() / (float) (modes.length - 1) : 0f;
		}

		public boolean is(String m) {
			return value.equalsIgnoreCase(m);
		}

		public int index() {
			for (int i = 0; i < modes.length; i++) if (modes[i].equals(value)) return i;
			return 0;
		}

		public void setIndex(int i) {
			value = modes[Math.max(0, Math.min(modes.length - 1, i))];
		}

		public void cycle() {
			setIndex((index() + 1) % modes.length);
		}

		public void prev() {
			setIndex((index() - 1 + modes.length) % modes.length);
		}

		@Override
		public String save() {
			return value;
		}

		@Override
		public void load(String raw) {
			for (String m : modes) {
				if (m.equals(raw)) {
					value = m;
					anim = modes.length > 1 ? index() / (float) (modes.length - 1) : 0f;
					return;
				}
			}
		}
	}
}
