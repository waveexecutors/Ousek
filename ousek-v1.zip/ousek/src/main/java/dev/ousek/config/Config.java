package dev.ousek.config;

import com.google.gson.Gson;
import com.google.gson.GsonBuilder;
import com.google.gson.JsonArray;
import com.google.gson.JsonElement;
import com.google.gson.JsonObject;
import dev.ousek.alt.AltManager;
import dev.ousek.hud.HudElement;
import dev.ousek.module.Module;
import dev.ousek.module.ModuleManager;
import dev.ousek.setting.Setting;
import net.fabricmc.loader.api.FabricLoader;

import java.nio.charset.StandardCharsets;
import java.nio.file.Files;
import java.nio.file.Path;

public final class Config {
	private static final Gson GSON = new GsonBuilder().setPrettyPrinting().create();

	private Config() {
	}

	private static Path file() {
		return FabricLoader.getInstance().getConfigDir().resolve("ousek.json");
	}

	public static void save() {
		try {
			JsonObject root = new JsonObject();
			JsonObject mods = new JsonObject();
			for (Module m : ModuleManager.modules) {
				JsonObject o = new JsonObject();
				o.addProperty("key", m.key);
				if (m instanceof HudElement e) {
					o.addProperty("enabled", e.enabled);
					o.addProperty("x", e.x);
					o.addProperty("y", e.y);
				}
				JsonObject st = new JsonObject();
				for (Setting<?> s : m.settings) st.addProperty(s.name, s.save());
				o.add("settings", st);
				mods.add(m.name, o);
			}
			root.add("modules", mods);

			JsonArray alts = new JsonArray();
			for (AltManager.Alt a : AltManager.alts) {
				JsonObject o = new JsonObject();
				o.addProperty("name", a.name);
				o.addProperty("password", a.password);
				alts.add(o);
			}
			root.add("alts", alts);
			Files.writeString(file(), GSON.toJson(root), StandardCharsets.UTF_8);
		} catch (Exception ignored) {
		}
	}

	public static void load() {
		try {
			Path f = file();
			if (!Files.exists(f)) return;
			JsonObject root = GSON.fromJson(Files.readString(f, StandardCharsets.UTF_8), JsonObject.class);
			if (root == null) return;

			JsonObject mods = root.has("modules") ? root.getAsJsonObject("modules") : new JsonObject();
			for (Module m : ModuleManager.modules) {
				if (!mods.has(m.name)) continue;
				JsonObject o = mods.getAsJsonObject(m.name);
				if (o.has("key")) m.key = o.get("key").getAsInt();
				if (m instanceof HudElement e) {
					if (o.has("enabled")) e.enabled = o.get("enabled").getAsBoolean();
					if (o.has("x")) e.x = o.get("x").getAsInt();
					if (o.has("y")) e.y = o.get("y").getAsInt();
				}
				if (o.has("settings")) {
					JsonObject st = o.getAsJsonObject("settings");
					for (Setting<?> s : m.settings) {
						JsonElement v = st.get(s.name);
						if (v != null) s.load(v.getAsString());
					}
				}
			}

			AltManager.alts.clear();
			if (root.has("alts")) {
				for (JsonElement el : root.getAsJsonArray("alts")) {
					JsonObject o = el.getAsJsonObject();
					AltManager.alts.add(new AltManager.Alt(o.get("name").getAsString(),
							o.has("password") ? o.get("password").getAsString() : ""));
				}
			}
		} catch (Exception ignored) {
		}
	}
}
