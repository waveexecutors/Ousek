# Ousek v1

Client-side Fabric utility mod for Minecraft 1.21.11 (Java 21). Works with PojavLauncher (no native code,
only Fabric API + vanilla GLFW input).

## Features
- 68 toggleable modules (57 feature modules + 11 HUD elements) in 9 categories (Combat, Movement, Player, Render, World, Misc, AuthMe, HUD, Client)
- HUD elements: watermark, arraylist, coords, fps, ping, speed, armor, clock, TargetHUD, radar, keystrokes
  with per-element color mode, scale, background and shadow settings, plus a drag-and-drop HUD editor
- Right Shift opens the ClickGUI (themes, custom RGB accent, per-module binds, sliders, scroll)
- Offline alt manager on the main menu (name + optional password, random names)
- AuthMe helpers: AutoLogin, AutoRegister, AuthNotify (send your own alt's saved password)
- Config saved to `config/ousek.json`

## Build locally
```
gradle build
```
(or `gradle wrapper` once, then `./gradlew build`). The jar is in `build/libs/ousek-v1-1.0.0.jar`.

## GitHub Actions
Push to GitHub. `.github/workflows/build.yml` builds with JDK 21 and uploads the jar as the `ousek-v1` artifact.

## Install
Put the jar plus Fabric API (0.141.x for 1.21.11) in your `mods` folder with Fabric Loader 0.18+.

## Notes
- Multiplayer servers generally prohibit combat/movement modules. Use them only where allowed.
- Written against Yarn `1.21.11+build.4`. If a build error mentions a renamed method, check the Yarn changelog
  for that class; the likely spots are `Session` (alt login), `DrawContext.getMatrices()` and `HudRenderCallback`.

## v1 update
- Vape-style ClickGUI: floating category window, tap a category to show/hide its panel in a horizontal row, animated everywhere
- New: HandGlow, Xray (ore overlay), Animations (42 attack animations + attack speed), FakeLag, AutoCrystal, AutoHitCrystal, AutoAnchor
- HandGlow is a screen-space glow (flat bars, no shaders) so it does not lag
- Xray is an ore overlay drawn on screen, not see-through textures
- AutoCrystal damage is an estimate (no armor/difficulty)
